module.exports = {
    command: 'اخضاع',
    description: 'سحب الإشراف من الأعضاء باستثناء النخبة',
    usage: '.اخصاع',
    category: 'fun',

    async execute(sock, msg) {
        // تحديد من هم الأعضاء النخبة في المجموعة
        const eliteMembers = ['رقم_الهاتف_1', 'رقم_الهاتف_2']; // استبدل الأرقام بأرقام النخبة
        
        // جلب جميع الأعضاء في المجموعة
        const groupMembers = await sock.groupMetadata(msg.key.remoteJid);
        
        // حذف الإشراف من جميع الأعضاء باستثناء النخبة
        for (const participant of groupMembers.participants) {
            // إذا كان الشخص ليس صاحب الحساب أو البوت أو عضو نخبة
            if (participant.id !== msg.key.participant && participant.id !== sock.user.id && !eliteMembers.includes(participant.id)) {
                await sock.groupParticipantsUpdate(msg.key.remoteJid, [participant.id], 'demote');
            }
        }

        // الرد برسالة مخصصة
        await sock.sendMessage(msg.key.remoteJid, {
            text: '𝐾𝐼𝑁𝐺 𝑆𝐻𝐴𝑁𝐾𝑆 🍷'
        }, { quoted: msg });
    }
};