module.exports = {
  command: 'تصويت',
  description: 'بدء تصويت لطرد أو العفو عن شخص',
  usage: '.تصويت @العضو',
  category: 'إداري',

  async execute(sock, msg, args) {
    const from = msg.key.remoteJid;
    if (!msg.key.participant) return;
    if (!msg.message.extendedTextMessage?.contextInfo?.mentionedJid) {
      return sock.sendMessage(from, { text: '❌ يجب منشن الشخص المراد التصويت عليه.' });
    }

    const target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
    const groupJid = from;

    let voteData = {
      guilty: [],
      innocent: [],
      voted: [],
      listener: null
    };

    await sock.sendMessage(groupJid, { 
      text: `📢 بدأ التصويت على: @${target.split('@')[0]}\n\nاكتب "مذنب" للطرد أو "برئ" للعفو.\n\nأول من يصل إلى صوتين يفوز.`,
      mentions: [target]
    });

    const messageListener = async ({ messages }) => {
      try {
        const message = messages[0];
        if (!message.message) return;

        const voter = message.key.participant || message.key.remoteJid;
        const body =
          message.message?.conversation ||
          message.message?.extendedTextMessage?.text ||
          '';

        if (from !== groupJid || voter === target || voteData.voted.includes(voter)) return;

        const text = body.trim().toLowerCase();

        if (text === 'مذنب') {
          voteData.guilty.push(voter);
          voteData.voted.push(voter);

          await sock.sendMessage(groupJid, {
            text: `❌ تم تسجيل صوت "مذنب"\nالإجمالي الآن: ${voteData.guilty.length}\nفاضل: ${2 - voteData.guilty.length} ليتم الطرد.`,
          });

          if (voteData.guilty.length >= 2) {
            await sock.groupParticipantsUpdate(groupJid, [target], 'remove');
            await sock.sendMessage(groupJid, { text: `🚫 تم طرد @${target.split('@')[0]} بناءً على التصويت.`, mentions: [target] });
            sock.ev.off('messages.upsert', messageListener);
          }
        } else if (text === 'برئ' || text === 'بريء' || text === 'بريئ') {
          voteData.innocent.push(voter);
          voteData.voted.push(voter);

          await sock.sendMessage(groupJid, {
            text: `✅ تم تسجيل صوت "برئ"\nالإجمالي الآن: ${voteData.innocent.length}\nفاضل: ${2 - voteData.innocent.length} ليتم العفو.`,
          });

          if (voteData.innocent.length >= 2) {
            await sock.sendMessage(groupJid, { text: `🎉 تم العفو عن @${target.split('@')[0]} بناءً على التصويت.`, mentions: [target] });
            sock.ev.off('messages.upsert', messageListener);
          }
        }
      } catch (err) {
        console.log('خطأ أثناء التصويت:', err);
      }
    };

    voteData.listener = messageListener;
    sock.ev.on('messages.upsert', messageListener);
  },
};