const questions = [
  { question: "ما هي عاصمة اليابان؟", options: ["كيوتو", "طوكيو", "أوساكا", "هيروشيما"], answer: 2 },
  { question: "ما هو الكوكب الأقرب إلى الشمس؟", options: ["الزهرة", "الأرض", "عطارد", "المريخ"], answer: 3 },
  { question: "من هو مؤسس شركة أبل؟", options: ["بيل غيتس", "ستيف جوبز", "مارك زوكربيرغ", "إيلون ماسك"], answer: 2 },
  { question: "ما هي عاصمة فرنسا؟", options: ["باريس", "ليون", "مارسيليا", "نيس"], answer: 1 },
  { question: "من هو كاتب رواية 'الأبله'؟", options: ["دوستويفسكي", "تولستوي", "شكسبير", "كامو"], answer: 1 },
  { question: "ما اسم أطول نهر في أفريقيا؟", options: ["الكونغو", "النيل", "النيجر", "زامبيزي"], answer: 2 },
  { question: "من هو أول من صعد إلى الفضاء؟", options: ["نيل أرمسترونغ", "يوري غاغارين", "باز ألدرن", "جون غلين"], answer: 2 },
  { question: "كم عدد أركان الإسلام؟", options: ["5", "6", "4", "7"], answer: 1 },
  { question: "ما هي اللغة التي نزل بها القرآن الكريم؟", options: ["العربية", "الإنجليزية", "الفرنسية", "العبرية"], answer: 1 },
  { question: "من هو النبي الذي ابتلعه الحوت؟", options: ["يونس", "نوح", "موسى", "إبراهيم"], answer: 1 },
  { question: "من هو الصحابي الذي جمع القرآن الكريم؟", options: ["عثمان بن عفان", "علي بن أبي طالب", "أبو بكر", "عمر بن الخطاب"], answer: 1 },
  { question: "ما اسم السورة التي تبدأ بـ (ألم)؟", options: ["البقرة", "الأنفال", "الكهف", "النساء"], answer: 1 },
  { question: "من هو مخترع المصباح الكهربائي؟", options: ["توماس إديسون", "نيكولا تسلا", "أينشتاين", "بيل غيتس"], answer: 1 },
  { question: "ما اسم أضخم كوكب في النظام الشمسي؟", options: ["زحل", "المشتري", "أورانوس", "نبتون"], answer: 2 },
  { question: "من هو مكتشف قانون الجاذبية؟", options: ["نيوتن", "تسلا", "أينشتاين", "جاليليو"], answer: 1 },
  { question: "في أي قارة تقع مصر؟", options: ["أفريقيا", "آسيا", "أوروبا", "أمريكا"], answer: 1 },
  { question: "ما اسم الجبل الذي كلم الله عليه موسى؟", options: ["جبل الطور", "جبل عرفة", "جبل أحد", "جبل النور"], answer: 1 },
  { question: "ما اسم أول مسجد بني في الإسلام؟", options: ["المسجد الحرام", "المسجد النبوي", "مسجد قباء", "المسجد الأقصى"], answer: 3 },
  { question: "كم عدد ركعات صلاة العشاء؟", options: ["2", "3", "4", "5"], answer: 3 },
  { question: "من هو زعيم الأكاتسوكي؟", options: ["إيتاشي", "باين", "توبي", "كيسامي"], answer: 2 },
  { question: "من هو بطل أنمي 'ون بيس'؟", options: ["لوفي", "زورو", "سانجي", "نامي"], answer: 1 },
  { question: "من هو مؤلف أنمي 'ديث نوت'؟", options: ["تسوجومي أوبا", "أودا", "كيشيموتو", "كوبو"], answer: 1 },
  { question: "من هو غوكو؟", options: ["نينجا", "سايان", "شينيغامي", "تايتان"], answer: 2 },
  { question: "كم عدد أجنحة جبريل؟", options: ["2", "4", "6", "600"], answer: 4 },
  { question: "ما اسم القائد الإسلامي الذي فتح الأندلس؟", options: ["عمرو بن العاص", "خالد بن الوليد", "طارق بن زياد", "صلاح الدين"], answer: 3 },
  { question: "في أي سنة نزل القرآن الكريم؟", options: ["610", "622", "632", "600"], answer: 1 },
  { question: "ما اسم أطول سورة في القرآن؟", options: ["النساء", "البقرة", "الأنفال", "العمران"], answer: 2 },
  { question: "من هو النبي الذي تحدث مع النمل؟", options: ["سليمان", "داوود", "عيسى", "يوسف"], answer: 1 },
  { question: "ما هي الدولة التي استضافت أولمبياد 2020؟", options: ["الصين", "أمريكا", "اليابان", "البرازيل"], answer: 3 },
  { question: "ما هي عاصمة المغرب؟", options: ["فاس", "الرباط", "الدار البيضاء", "طنجة"], answer: 2 },
  { question: "ما اسم البحر الذي يفصل آسيا عن أفريقيا؟", options: ["الأحمر", "المتوسط", "الميت", "البلطيق"], answer: 1 },
  { question: "من هو أول إنسان خلقه الله؟", options: ["آدم", "إبراهيم", "نوح", "عيسى"], answer: 1 },
  { question: "ما اسم أول جامعة إسلامية؟", options: ["الأزهر", "القرويين", "دمشق", "بغداد"], answer: 2 },
  { question: "من هو النبي الذي بنى الكعبة؟", options: ["إبراهيم", "محمد", "موسى", "نوح"], answer: 1 },
  { question: "ما اسم الفتاة التي تملك قوة الماء في أنمي أفاتار؟", options: ["توف", "كاتارا", "ماي", "أزولا"], answer: 2 },
  { question: "من هو العدو الرئيسي في هجوم العمالقة؟", options: ["ليفاي", "العملاق الضخم", "إيرين", "ميكاسا"], answer: 2 },
  { question: "من هو مخترع الإنترنت؟", options: ["تيم برنرز لي", "إيلون ماسك", "زوكربيرغ", "جاك دورسي"], answer: 1 },
  { question: "ما اسم أصغر قارة؟", options: ["أوروبا", "أستراليا", "آسيا", "أمريكا الجنوبية"], answer: 2 },
  { question: "ما هي عاصمة العراق؟", options: ["الموصل", "البصرة", "بغداد", "النجف"], answer: 3 },
  { question: "كم عدد سور القرآن؟", options: ["112", "113", "114", "115"], answer: 3 },
  { question: "من هو النبي الذي عاش 950 سنة؟", options: ["نوح", "إبراهيم", "آدم", "موسى"], answer: 1 },
  { question: "ما هي لغة اليابان؟", options: ["الكورية", "الصينية", "اليابانية", "الفيتنامية"], answer: 3 },
  { question: "ما اسم الدولة الوحيدة التي على علمها تنين؟", options: ["الصين", "فيتنام", "بوتان", "تايلاند"], answer: 3 },
  { question: "من هو مكتشف أمريكا؟", options: ["ماجلان", "كريستوفر كولومبوس", "دافنشي", "ابن بطوطة"], answer: 2 },
  { question: "من هو النبي الذي كسر الأصنام؟", options: ["عيسى", "محمد", "إبراهيم", "موسى"], answer: 3 },
  { question: "ما هي عاصمة الجزائر؟", options: ["الجزائر", "وهران", "قسنطينة", "عنابة"], answer: 1 },
  { question: "ما اسم الفتى الذي يملك مذكرة الموت؟", options: ["لايت", "إل", "رايوك", "مات"], answer: 1 },
  { question: "من هو زعيم قراصنة الشعر الأحمر؟", options: ["لوفي", "كايدو", "شانكس", "بيغ مام"], answer: 3 },
  { question: "ما هي الصلاة التي تقام عند شروق الشمس؟", options: ["الظهر", "الفجر", "العصر", "المغرب"], answer: 2 },
  { question: "ما اسم أغنية الافتتاح في أنمي ناروتو شيبودن الشهيرة؟", options: ["Blue Bird", "Sign", "Hero", "Fighting Dreamers"], answer: 1 },
  { question: "ما اسم النبي الذي أُعطي الإنجيل؟", options: ["محمد", "عيسى", "موسى", "يونس"], answer: 2 },
  { question: "من هو قائد فرقة الهجوم في جوجوتسو كايسن؟", options: ["يوجي", "ميغومي", "غوجو", "نانامي"], answer: 3 },
  { question: "كم عدد حروف اللغة العربية؟", options: ["28", "29", "30", "27"], answer: 1 },
  { question: "من هو كاتب رواية البؤساء؟", options: ["فيكتور هوغو", "ديكنز", "بلزاك", "دوما"], answer: 1 },
  { question: "ما اسم عاصمة فلسطين؟", options: ["غزة", "نابلس", "القدس", "رام الله"], answer: 3 },
  { question: "من هو الصحابي الذي بشره الرسول بالجنة؟", options: ["بلال", "عثمان", "أبو بكر", "كل ما سبق"], answer: 4 },
  { question: "ما اسم المعركة التي وقعت في السنة الثانية للهجرة؟", options: ["بدر", "أحد", "الخندق", "اليرموك"], answer: 1 },
  { question: "من هو أول رئيس للولايات المتحدة؟", options: ["لينكولن", "روزفلت", "جورج واشنطن", "آدمز"], answer: 3 },
  { question: "ما هو اسم البحر الذي يفصل أوروبا عن أفريقيا؟", options: ["البحر الأبيض المتوسط", "البحر الأحمر", "البحر الأسود", "الخليج العربي"], answer: 1 }
];

// حفظ الجلسات
const sessions = {};

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
  command: ['مختلط'],
  description: 'لعبة أسئلة ثقافية عشوائية',
usage: '.مختلط',
  category: 'games',
  
  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;

    // تحقق من وجود جلسة سابقة
    if (sessions[chatId]) {
      await sock.sendMessage(chatId, { text: "🛑 هناك لعبة ثقافة تعمل حاليًا، اكتب 'وقف' لإيقافها." });
      return;
    }

    let current = 0;
    let active = true;
    const scores = {};

    sessions[chatId] = true;

    await sock.sendMessage(chatId, { text: `🎮 بدء لعبة الثقافة! لديك 15 ثانية لكل سؤال.\n✋ اكتب "وقف" لإيقاف اللعبة في أي وقت.` });

    while (current < questions.length && active) {
      const q = questions[current];
      const questionText = `🧠 *السؤال ${current + 1}*\n${q.question}\n\n1️⃣ ${q.options[0]}\n2️⃣ ${q.options[1]}\n3️⃣ ${q.options[2]}\n4️⃣ ${q.options[3]}`;
      
      await sock.sendMessage(chatId, { text: questionText });

      let answered = false;

      const collector = async (responseMsg) => {
        const sender = responseMsg.key.participant || responseMsg.key.remoteJid;
        const body = responseMsg.message?.conversation || '';

        if (!active) return;

        if (body.toLowerCase() === "وقف") {
          active = false;
          await sock.sendMessage(chatId, { text: "🛑 تم إيقاف اللعبة." });
          return;
        }

        const selected = parseInt(body);
        if (!answered && selected >= 1 && selected <= 4) {
          answered = true;
          if (selected === q.answer) {
            scores[sender] = (scores[sender] || 0) + 1;
            await sock.sendMessage(chatId, { text: `✅ إجابة صحيحة من @${sender.split('@')[0]}!`, mentions: [sender] });
          } else {
            await sock.sendMessage(chatId, { text: `❌ خطأ! الإجابة الصحيحة كانت: ${q.options[q.answer - 1]}` });
          }
        }
      };

      sock.ev.on('messages.upsert', async ({ messages }) => {
        for (const m of messages) {
          if (m.key.remoteJid === chatId && !m.key.fromMe) {
            await collector(m);
          }
        }
      });

      // انتظر 15 ثانية أو حتى تتم الإجابة
      for (let i = 0; i < 15; i++) {
        if (answered || !active) break;
        await sleep(1000);
      }

      if (!answered && active) {
        await sock.sendMessage(chatId, { text: `⌛ انتهى الوقت! الإجابة الصحيحة: ${q.options[q.answer - 1]}` });
      }

      current++;
    }

    delete sessions[chatId];

    // ترتيب النقاط
    let result = Object.entries(scores)
      .sort((a, b) => b[1] - a[1])
      .map(([user, score], index) => `${index + 1}. @${user.split('@')[0]} - ${score} نقطة`)
      .join('\n');

    await sock.sendMessage(chatId, {
      text: result ? `🏆 نتائج اللعبة:\n\n${result}` : "لم يتم تسجيل أي نقاط.",
      mentions: Object.keys(scores)
    });
  }
};