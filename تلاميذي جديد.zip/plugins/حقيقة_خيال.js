const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');

function loadPoints() {
  try {
    return JSON.parse(fs.readFileSync(pointsFile));
  } catch {
    return {};
  }
}

function savePoints(points) {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

module.exports = {
  command: 'حقيقة_خيال',
  category: 'games',
  description: 'فعالية حقيقة أم خيال - جاوب بسرعة على صحة المعلومة',
usage: '.حقيقة_خيال',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هـذا الأمـر يعـمـل فـي القـروبـات فقـط.*'
      }, { quoted: msg });
    }

    const questions = [
      { statement: "🍥 ناروتو هو ابن الهوكاجي الرابع.", answer: "حقيقة" },
      { statement: "🧊 ميكاسا من عائلة تايتشي.", answer: "خيال" },
      { statement: "👒 لوفي حلمه أن يصبح ملك القراصنة.", answer: "حقيقة" },
      { statement: "⚡ كيلوا يكره الشوكولاتة.", answer: "خيال" },
      { statement: "🔮 إيتاتشي قتل عشيرته لأجل المال.", answer: "خيال" },
      { statement: "💀 لايت يملك مذكرة الموت.", answer: "حقيقة" },
      { statement: "🎮 غوكو من كوكب نيميك.", answer: "خيال" },
      { statement: "🌊 تانجيرو فقد عائلته بسبب الشياطين.", answer: "حقيقة" },
      { statement: "🌀 إيرين انضم للإستطلاع بسبب ميكاسا.", answer: "خيال" },
      { statement: "🔥 ساسكي واجه أوروتشيمارو في الجزء الأول.", answer: "حقيقة" }
    ];

    const selected = questions[Math.floor(Math.random() * questions.length)];
    const correctAnswer = selected.answer.toLowerCase();
    let isAnswered = false;

    const message = `*فـعـالـيـة الـيـوم : ˼‏🌀˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🧠◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📝╹↵ اسـم الفـعـالـيـة ↯*\n*⧉┋※〔 حـقـيـقـة أم خـيـال 〕※*\n\n` +
      `*┃╻🌟╹↵ الـسـؤال ↯*\n*⧉┋※〔 ${selected.statement} 〕※*\n\n` +
      `*┃╻⏳╹↵ لـديـكـم 30 ثـانـيـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🧠◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
      `*٭ فعـالـيات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇 𝐸𝑅𝐸𝑁 ٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase()?.trim();
      if (!body) return;

      if (body === correctAnswer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = loadPoints();

        pointsData[number] = (pointsData[number] || 0) + 10;
        savePoints(pointsData);

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n` +
`*┃╻💐╹↵ الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*\n\n` +
`*تـم مـنـحـه الـنـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(async () => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        await sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n*❐ ↵ لم يجب أحد بشكل صحيح.\n┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};