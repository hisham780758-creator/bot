const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

const characters = [
  { name: 'إيتاتشي', answer: 'الأوتشيها' },
  { name: 'ساسكي', answer: 'الأوتشيها' },
  { name: 'مادارا', answer: 'الأوتشيها' },
  { name: 'كاكاشي', answer: 'الأنبو' },
  { name: 'باين', answer: 'الأكاتسكي' },
  { name: 'أوبيتو', answer: 'الأكاتسكي' },
  { name: 'زيتسو', answer: 'الأكاتسكي' },
  { name: 'دارهوي', answer: 'سحاب' },
  { name: 'غارا', answer: 'الرمل' },
  { name: 'إيرين', answer: 'الاستطلاع' },
  { name: 'ليفاي', answer: 'الاستطلاع' },
  { name: 'نيزوكو', answer: 'قاتل الشياطين' },
  { name: 'ريوك', answer: 'الشينيغامي' },
  { name: 'إل', answer: 'الشرطة' },
];

module.exports = {
  command: 'عشيرة',
  description: 'فعالية معرفة العشيرة أو المنظمة للشخصية',
usage: '.عشيرة',
  category: 'games',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    const selected = characters[Math.floor(Math.random() * characters.length)];
    const answer = selected.answer.toLowerCase();
    const question = selected.name;

    const message = 
`*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🎻◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
`*┃╻📜╹↵اسـم الفـعـالـية ↯*\n*⧉┋※〔عـشـيـرة〕※*\n\n` +
`*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔البوت يعطيك شخصية، والمطلوب معرفة من أي عشيرة أو منظمة هي〕※*\n\n` +
`*┃╻🎯╹↵الشخصـيـة ↯*\n*⧉┋※〔 ${question} 〕※*\n\n` +
`*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*⎔ ٠ ┈─ ━╼ • ◞🎻◜ • ╾━ ─┈‏ ٠ ⎔*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇 ASCANOR ٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    let isAnswered = false;

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase()?.trim();
      if (!body) return;

      if (body.includes(answer)) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = JSON.parse(fs.readFileSync(pointsFile, 'utf8'));
        pointsData[number] = (pointsData[number] || 0) + 10;
        fs.writeFileSync(pointsFile, JSON.stringify(pointsData, null, 2));

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n❐ ↵「 @${number} 」\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n❐ ↵「 ${answer} 」\n\n` +
`*تـم مـنـحـه 10 نـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(() => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        sock.sendMessage(groupJid, {
          text: `⌛ *انتهى الوقت!* الإجابة الصحيحة:\n*「 ${answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};