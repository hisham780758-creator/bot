const { isElite, extractPureNumber } = require('../haykala/elite.js');

module.exports = {
command: 'توجيه',
description: '📣 توجيه رسالة إلى كل الجروبات',
usage: '.توجيه',
category: 'admin',

async execute(sock, msg) {
const sender = msg.sender || msg.key.participant || msg.key.remoteJid;
if (!sender) return await sock.sendMessage(msg.key.remoteJid, {
text: '❌ تعذر معرفة المرسل.',
}, { quoted: msg });

if (!(isElite(sender) || extractPureNumber(sender) === '201028489465')) {  
  return await sock.sendMessage(msg.key.remoteJid, {  
    text: '🚫 هذا الأمر مخصص للنخبة فقط.',  
  }, { quoted: msg });  
}  

const context = msg.message?.extendedTextMessage?.contextInfo;  
const quotedMsg = context?.quotedMessage;  

if (!quotedMsg) {  
  return await sock.sendMessage(msg.key.remoteJid, {  
    text: '❌ يجب الرد على رسالة نصية لتوجيهها.',  
  }, { quoted: msg });  
}  

const text = quotedMsg?.conversation || quotedMsg?.extendedTextMessage?.text;  
if (!text) {  
  return await sock.sendMessage(msg.key.remoteJid, {  
    text: '⚠️ الرسالة التي تم الرد عليها لا تحتوي على نص.',  
  }, { quoted: msg });  
}  

const groupsMetadata = await sock.groupFetchAllParticipating();  
const groupJids = Object.keys(groupsMetadata).filter(gid => gid.endsWith('@g.us'));  

if (groupJids.length === 0) {  
  return await sock.sendMessage(msg.key.remoteJid, {  
    text: '❌ البوت ليس في أي جروب.',  
  }, { quoted: msg });  
}  

await sock.sendMessage(msg.key.remoteJid, {  
  text: `🔄 جاري توجيه الرسالة إلى ${groupJids.length} جروب مع منشن للكل...`,  
}, { quoted: msg });  

for (const group of groupJids) {  
  try {  
    const metadata = groupsMetadata[group];  
    const mentions = metadata.participants.map(p => p.id);  

    await sock.sendMessage(group, {  
      text: `📢 *رسالة موجهة من النخبة:*\n\n${text}`,  
      mentions  
    });  

    await new Promise(resolve => setTimeout(resolve, 1000));  
  } catch (err) {  
    console.log(`⚠️ فشل التوجيه إلى ${group}: ${err.message}`);  
  }  
}  

await sock.sendMessage(msg.key.remoteJid, {  
  text: '✅ تم توجيه الرسالة مع منشن للكل.',  
}, { quoted: msg });

}
};

