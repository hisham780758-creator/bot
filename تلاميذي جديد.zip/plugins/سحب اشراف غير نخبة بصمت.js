const fs = require('fs');
const { eliteNumbers } = require('../haykala/elite.js');

module.exports = {
  name: 'تخفيض الكل',
  command: ['همم'],
  category: 'إدارة²',
  description: 'يسحب الإشراف من غير النخبة فقط بدون إرسال رسائل',
usage: '.سحب اشراف غير نخبة بصمت',

  async execute(sock, msg) {
    const groupId = msg.key.remoteJid;
    if (!groupId.endsWith('@g.us')) return; // تأكد أنها مجموعة

    const metadata = await sock.groupMetadata(groupId);
    const participants = metadata.participants;

    // نحدد المشرفين فقط
    const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');

    for (const admin of admins) {
      const jid = admin.id || admin.jid;
      const number = jid.split('@')[0];

      if (!isEliteUser(number)) {
        try {
          await sock.groupParticipantsUpdate(groupId, [jid], 'demote');
        } catch (err) {
          // بصمت، تجاهل أي خطأ (مثل: محاولة سحب إشراف البوت نفسه أو خطأ في الصلاحيات)
        }
      }
    }
  }
};