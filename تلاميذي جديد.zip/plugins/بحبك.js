module.exports = {
    command: 'بحبك',
description: 'وصف بحبك',
usage: '.بحبك',
category: 'tools',
    async execute(sock, m) {
        const chatId = m.key.remoteJid;

        await sock.sendMessage(chatId, { text: ` وانا كمان بحبك بعشقك🫦` });
    }
};