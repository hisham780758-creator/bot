const fs = require('fs');
const path = require('path');
const { jidDecode } = require('@whiskeysockets/baileys');

const dataPath = path.join(__dirname, '..', 'data', 'spyPlayers.json');
if (!fs.existsSync(dataPath)) fs.writeFileSync(dataPath, '{}');

const decodeJid = (jid) => jidDecode(jid)?.user || jid.split('@')[0];

function loadData() {
  return JSON.parse(fs.readFileSync(dataPath));
}
function saveData(data) {
  fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

let games = {};

module.exports = {
  command: ['الجاسوس'],
  description: '🕵️‍♂️ لعبة الجاسوس الكاملة.',
usage: '.الجاسوس',
  category: 'games',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;
    const name = msg.pushName || 'مجهول';
    const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const args = body.trim().split(' ').slice(1);
    const text = args.join(' ');
    const groupId = chatId;

    const spyData = loadData();
    games[groupId] ??= {
      players: {},
      started: false,
      word: '',
      spy: '',
      phase: 0,
      votes: {},
      spyGuessing: false,
      lastGuess: ''
    };
    const game = games[groupId];

    if (!text) {
      return sock.sendMessage(chatId, {
        text: `🕵️‍♂️ *لعبة: من هو الجاسوس؟*

1. .الجاسوس تسجيل (لقبك)
2. .الجاسوس 1 ← بداية اللعبة وتوزيع الأدوار
3. .الجاسوس 2 ← بدء مرحلة التصويت
4. .الجاسوس اشك (لقب) ← التصويت على من هو الجاسوس
5. .الجاسوس 3 ← عرض من صوت على من
6. .الجاسوس 4 ← إعلان النتائج وبدء مرحلة تخمين الكلمة
7. .الجاسوس 5 ← عرض نتيجة التخمين
8. .الجاسوس حالة ← عرض حالة اللعبة
9. .الجاسوس انهاء ← إنهاء اللعبة`
      }, { quoted: msg });
    }

    if (text.startsWith('تسجيل')) {
      const nickname = args.slice(1).join(' ');
      if (!nickname) return sock.sendMessage(chatId, { text: '❌ اكتب لقبك: .الجاسوس تسجيل لقبك' }, { quoted: msg });
      if (game.started) return sock.sendMessage(chatId, { text: '❌ اللعبة بدأت بالفعل.' }, { quoted: msg });

      game.players[senderJid] = nickname;
      spyData[groupId] ??= {};
      spyData[groupId][senderJid] = nickname;
      saveData(spyData);

      return sock.sendMessage(chatId, { text: `✅ تم تسجيلك كلقب: *${nickname}*` }, { quoted: msg });
    }

    if (text === 'حالة') {
      const playersObj = spyData[groupId] || {};
      const players = Object.entries(playersObj);
      if (players.length === 0) {
        return sock.sendMessage(chatId, { text: '📭 لا يوجد لاعبين مسجلين حتى الآن.' }, { quoted: msg });
      }

      const list = players.map(([_, nick], i) => `${i + 1}. ${nick}`).join('\n');

      return sock.sendMessage(chatId, {
        text:
`🎮 *حالة لعبة الجاسوس:*

👥 اللاعبين (${players.length}):
${list}

🕵️‍♂️ تم اختيار الجاسوس؟ ✅ ${game.spy ? 'نعم' : 'لا'}
🚦 بدأت؟ ✅ ${game.started ? 'نعم' : 'لا'}
📊 عدد الأصوات: ${Object.keys(game.votes).length}
📌 *تم تعيين الموضوع.* (لن يتم عرضه)`
      }, { quoted: msg });
    }

    if (text === '1') {
      const filePlayers = spyData[groupId] || {};
      const playerJIDs = Object.keys(filePlayers);

      if (playerJIDs.length < 5)
        return sock.sendMessage(chatId, { text: '❌ تحتاج إلى 5 لاعبين على الأقل لبدء اللعبة.' }, { quoted: msg });

      game.players = filePlayers;
      const words = ['مطار', 'مدرسة', 'مطعم', 'سجن', 'مستشفى', 'شاطئ', 'مكتبة'];
      game.word = words[Math.floor(Math.random() * words.length)];
      game.spy = playerJIDs[Math.floor(Math.random() * playerJIDs.length)];
      game.started = true;
      game.phase = 1;

      for (let jid of playerJIDs) {
        const isSpy = jid === game.spy;
        const message = isSpy
          ? '🕵️‍♂️ *أنت الجاسوس!*\nحاول أن تكتشف الكلمة من خلال إجابات الآخرين دون أن تنكشف.'
          : `📌 *كلمتك السرية:* ${game.word}`;

        await sock.sendMessage(jid, {
          text: `🎮 *دورك في لعبة الجاسوس:*\n\n${message}`
        });
      }

      return sock.sendMessage(chatId, {
        text: `🎭 *تم توزيع الأدوار!*\n🕵️‍♂️ أحدكم هو الجاسوس...\nابدأوا بطرح الأسئلة لاكتشافه!`
      }, { quoted: msg });
    }

    if (text === '2') {
      const filePlayers = spyData[groupId] || {};
      const playerJIDs = Object.keys(filePlayers);

      if (playerJIDs.length < 5)
        return sock.sendMessage(chatId, { text: '❌ تحتاج إلى 5 لاعبين على الأقل للتصويت.' }, { quoted: msg });

      game.phase = 2;
      game.votes = {};
      return sock.sendMessage(chatId, { text: `🗳️ مرحلة التصويت بدأت!\nاكتب: .الجاسوس اشك (لقب من تتوقع أنه الجاسوس)` }, { quoted: msg });
    }

    if (text.startsWith('اشك')) {
      const filePlayers = spyData[groupId] || {};
      const playerJIDs = Object.keys(filePlayers);

      if (!filePlayers[senderJid]) {
        return sock.sendMessage(chatId, {
          text: '❌ لا يمكنك التصويت لأنك لم تسجل في اللعبة.'
        }, { quoted: msg });
      }

      const guessNick = args.slice(1).join(' ');
      const votedJid = Object.entries(filePlayers).find(([jid, nick]) => nick === guessNick)?.[0];

      if (!votedJid) {
        return sock.sendMessage(chatId, {
          text: '❌ هذا اللقب غير موجود بين اللاعبين.'
        }, { quoted: msg });
      }

      if (game.votes[senderJid]) {
        return sock.sendMessage(chatId, {
          text: '❌ لقد قمت بالتصويت بالفعل.'
        }, { quoted: msg });
      }

      game.votes[senderJid] = votedJid;

      await sock.sendMessage(chatId, {
        text: `✅ تم تسجيل صوتك على أن *${guessNick}* هو الجاسوس.`
      }, { quoted: msg });
      return;
    }

    if (text === '3') {
      if (Object.keys(game.votes).length === 0) {
        return sock.sendMessage(chatId, { text: '📭 لا يوجد تصويتات حتى الآن.' }, { quoted: msg });
      }

      const filePlayers = spyData[groupId] || {};
      const normalizedVotes = [];

      for (const [voterJidRaw, votedJidRaw] of Object.entries(game.votes)) {
        const voterNick = filePlayers[voterJidRaw] || '❓';
        const votedNick = filePlayers[votedJidRaw] || '❓';
        normalizedVotes.push(`- *${voterNick}* صوت على: *${votedNick}*`);
      }

      return sock.sendMessage(chatId, {
        text: `🗳️ *التصويتات الحالية:*\n\n${normalizedVotes.join('\n')}`
      }, { quoted: msg });
    }

    if (text === '4') {
      const realSpyJid = game.spy;
      const realSpyNick = game.players[realSpyJid];
      const results = [`🕵️‍♂️ *نتائج التصويت:*`, `\n🕵️‍♂️ الجاسوس الحقيقي هو: *${realSpyNick}*\n`];

      for (const [voterJid, voteJid] of Object.entries(game.votes)) {
        const voterNick = game.players[voterJid] || decodeJid(voterJid);
        const guessedNick = game.players[voteJid] || '❓';
        const correct = voteJid === realSpyJid ? '✅' : '❌';
        results.push(`${correct} *${voterNick}* ظن أن الجاسوس هو: *${guessedNick}*`);
      }

      game.spyGuessing = true;

      await sock.sendMessage(chatId, {
        text: results.join('\n') + `\n\n🕵️‍♂️ الآن، على الجاسوس أن يخمن الكلمة السرية.\n📩 أرسل الكلمة في الخاص إلى البوت الآن!`
      }, { quoted: msg });

      await sock.sendMessage(realSpyJid, {
        text: `🕵️‍♂️ لقد تم كشفك! لديك فرصة أخيرة لتخمين الكلمة السرية.\n📩 أرسل الكلمـة الآن في رسالة واحدة فقط.`
      });

      return;
    }

    if (text === '5') {
      if (!game || !game.spy || !game.word) {
        return sock.sendMessage(chatId, { text: '❌ لا توجد لعبة حالياً أو لم تكتمل البيانات.' }, { quoted: msg });
      }

      if (!game.lastGuess) {
        return sock.sendMessage(chatId, { text: '❌ الجاسوس لم يخمن الكلمة بعد.' }, { quoted: msg });
      }

      const isCorrect = game.lastGuess.toLowerCase() === game.word.toLowerCase();
      const realSpyNick = game.players[game.spy] || '❓';

      const result = isCorrect
        ? `🕵️‍♂️ الجاسوس *${realSpyNick}* خمن الكلمة بشكل صحيح ✅\n🏆 الجاسوس هو الفائز!`
        : `🕵️‍♂️ الجاسوس *${realSpyNick}* خمن الكلمة بشكل خاطئ ❌\n🏆 المدنيون هم الفائزون!\n🔑 الكلمة الصحيحة كانت: *${game.word}*`;

      delete games[groupId];
      delete spyData[groupId];
      saveData(spyData);

      return sock.sendMessage(chatId, { text: result }, { quoted: msg });
    }

    if (game.spyGuessing && senderJid === game.spy) {
      game.spyGuessing = false;
      game.lastGuess = body.trim();

      return sock.sendMessage(chatId, {
        text: `✅ تم استلام تخمين الجاسوس.\n✋ لعرض النتيجة، اكتب: .الجاسوس 5`
      }, { quoted: msg });
    }

    if (text === 'انهاء') {
      delete games[groupId];
      delete spyData[groupId];
      saveData(spyData);
      return sock.sendMessage(chatId, { text: '✅ تم إنهاء اللعبة وحذف كل البيانات.' }, { quoted: msg });
    }
  }
};