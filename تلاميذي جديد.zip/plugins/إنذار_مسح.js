const fs = require('fs');
const path = require('path');

const WARNINGS_FILE = path.join(__dirname, '../data/warnings.json');

// تحميل الإنذارات
function loadWarnings() {
  if (!fs.existsSync(WARNINGS_FILE)) {
    fs.writeFileSync(WARNINGS_FILE, JSON.stringify({}));
  }
  return JSON.parse(fs.readFileSync(WARNINGS_FILE));
}

// حفظ الإنذارات
function saveWarnings(data) {
  fs.writeFileSync(WARNINGS_FILE, JSON.stringify(data, null, 2));
}

module.exports = {
  command: 'مسح_انذار',
  category: 'admin',
  description: 'مسح عدد معين من إنذارات عضو في المجموعة (للمشرفين فقط).',
usage: '.إنذار_مسح',

  async execute(sock, msg, args = []) {
    const chatId = msg.key.remoteJid;

    // التفاعل بالإيموجي 🧼
    await sock.sendMessage(chatId, { react: { text: '🧼', key: msg.key } });

    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, {
        text: '❌ هذا الأمر يعمل فقط في المجموعات.'
      }, { quoted: msg });
    }

    // التحقق من أن المرسل مشرف
    let groupMetadata;
    try {
      groupMetadata = await sock.groupMetadata(chatId);
    } catch (e) {
      return sock.sendMessage(chatId, {
        text: '❌ لم أتمكن من جلب بيانات المجموعة.'
      }, { quoted: msg });
    }

    const sender = msg.key.participant || msg.participant || msg.key.remoteJid;
    const senderObj = groupMetadata.participants.find(p => p.id === sender);
    if (!senderObj || (senderObj.admin !== 'admin' && senderObj.admin !== 'superadmin')) {
      return sock.sendMessage(chatId, {
        text: '❌ يجب أن تكون مشرفًا لتنفيذ هذا الأمر.'
      }, { quoted: msg });
    }

    // الحصول على العضو والعدد
    let target;
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    const contextParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

    if (mentioned?.length > 0) {
      target = mentioned[0];
    } else if (contextParticipant) {
      target = contextParticipant;
    } else if (args.length > 0) {
      const number = args[0].replace(/[^0-9]/g, '');
      target = number + '@s.whatsapp.net';
    }

    const amount = parseInt(args[1]) || 1;

    if (!target || isNaN(amount)) {
      return sock.sendMessage(chatId, {
        text: '❗ يرجى منشن العضو أو كتابة رقمه مع عدد الإنذارات المراد حذفها.\nمثال: `.مسح_انذار @رقم 1`'
      }, { quoted: msg });
    }

    const warnings = loadWarnings();
    if (!warnings[chatId] || !warnings[chatId][target] || warnings[chatId][target] === 0) {
      return sock.sendMessage(chatId, {
        text: '✅ لا يوجد إنذارات لهذا العضو.'
      }, { quoted: msg });
    }

    warnings[chatId][target] = Math.max(0, warnings[chatId][target] - amount);
    saveWarnings(warnings);

    await sock.sendMessage(chatId, {
      text: `✅ تم خصم ${amount} إنذار من @${target.split('@')[0]}. عدد الإنذارات الجديد: ${warnings[chatId][target]}`,
      mentions: [target]
    }, { quoted: msg });
  }
};