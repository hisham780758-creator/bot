// plugins/حظر.js
const fs = require('fs');
const path = require('path');
const { isElite } = require('../akatsuki/elite.js');

const dataDir = path.join(__dirname, '..', 'akatsuki', 'data');
const bannedWordsPath = path.join(dataDir, 'bannedWords.json');

// التأكد من وجود المجلد والملف
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(bannedWordsPath)) fs.writeFileSync(bannedWordsPath, JSON.stringify([]));

module.exports = {
  command: "حظر",
  description: "📛 يضيف كلمة إلى قائمة الكلمات المحظورة.",
  usage: ".حظر [الكلمة]",
  category: 'نقابة',

  async execute(sock, msg) {
    try {
      const chatId = msg.key.remoteJid;
      const sender = msg.key.participant || chatId;
      const senderLid = sender.split('@')[0];

      if (!isElite(senderLid)) {
        return await sock.sendMessage(chatId, {
          text: '*❌ هذا الأمر مخصص للنخبة فقط!*'
        }, { quoted: msg });
      }

      const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
      const wordToBan = body.replace(/^[^\s]+\s*/, '').trim();

      if (!wordToBan) {
        return await sock.sendMessage(chatId, {
          text: '*❌ يرجى كتابة الكلمة التي تريد حظرها.*\nمثال: .حظر كلمة'
        }, { quoted: msg });
      }

      let bannedWords = JSON.parse(fs.readFileSync(bannedWordsPath, 'utf8'));

      if (bannedWords.includes(wordToBan)) {
        return await sock.sendMessage(chatId, {
          text: `⚠️ الكلمة "*${wordToBan}*" محظورة بالفعل!`
        }, { quoted: msg });
      }

      bannedWords.push(wordToBan);
      fs.writeFileSync(bannedWordsPath, JSON.stringify(bannedWords, null, 2), 'utf8');

      const replyText = `
*❍━━━══━━❪🛡️❫━━══━━━❍*
*｢🚫｣⇇تم حظر الكلمة بنجاح*

📌 الكلمة: *${wordToBan}*

> سيتم مراقبة استخدامها داخل المجموعة
*❍━━━══━━❪🛡️❫━━══━━━❍*
      `.trim();

      await sock.sendMessage(chatId, { text: replyText }, { quoted: msg });

    } catch (error) {
      console.error('✗ خطأ في أمر الحظر:', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};