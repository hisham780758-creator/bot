module.exports = {
  command: 'عملة',
  description: 'يعرض عملة الدولة المطلوبة ورمزها.',
usage: '.العملة',
  category: 'world',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    const fullText = msg.message?.conversation ||
                     msg.message?.extendedTextMessage?.text || '';

    const country = fullText.split(' ').slice(1).join(' ').trim();

    if (!country) {
      return sock.sendMessage(chatId, {
        text: '❗ يرجى كتابة اسم الدولة بعد الأمر.\nمثال: `.عملة اليابان`'
      }, { quoted: msg });
    }

    const currencies = {
      "اليابان": { currency: "الين الياباني", symbol: "¥", flag: "🇯🇵" },
      "مصر": { currency: "الجنيه المصري", symbol: "E£", flag: "🇪🇬" },
      "السعودية": { currency: "الريال السعودي", symbol: "﷼", flag: "🇸🇦" },
      "المغرب": { currency: "الدرهم المغربي", symbol: "MAD", flag: "🇲🇦" },
      "الجزائر": { currency: "الدينار الجزائري", symbol: "DZD", flag: "🇩🇿" },
      "تونس": { currency: "الدينار التونسي", symbol: "TND", flag: "🇹🇳" },
      "فلسطين": { currency: "الشيكل الإسرائيلي / الدينار الأردني", symbol: "₪ / JD", flag: "🇵🇸" },
      "أمريكا": { currency: "الدولار الأمريكي", symbol: "$", flag: "🇺🇸" },
      "كندا": { currency: "الدولار الكندي", symbol: "C$", flag: "🇨🇦" },
      "فرنسا": { currency: "اليورو", symbol: "€", flag: "🇫🇷" },
      "ألمانيا": { currency: "اليورو", symbol: "€", flag: "🇩🇪" },
      "إيطاليا": { currency: "اليورو", symbol: "€", flag: "🇮🇹" },
      "إسبانيا": { currency: "اليورو", symbol: "€", flag: "🇪🇸" },
      "تركيا": { currency: "الليرة التركية", symbol: "₺", flag: "🇹🇷" },
      "روسيا": { currency: "الروبل الروسي", symbol: "₽", flag: "🇷🇺" },
      "الهند": { currency: "الروبية الهندية", symbol: "₹", flag: "🇮🇳" },
      "الصين": { currency: "اليوان الصيني", symbol: "¥", flag: "🇨🇳" },
      "كوريا الجنوبية": { currency: "الوون الكوري", symbol: "₩", flag: "🇰🇷" },
      "باكستان": { currency: "الروبية الباكستانية", symbol: "₨", flag: "🇵🇰" },
      "إندونيسيا": { currency: "الروبية الإندونيسية", symbol: "Rp", flag: "🇮🇩" },
      "لبنان": { currency: "الليرة اللبنانية", symbol: "ل.ل", flag: "🇱🇧" },
      "الأردن": { currency: "الدينار الأردني", symbol: "JD", flag: "🇯🇴" },
      "العراق": { currency: "الدينار العراقي", symbol: "IQD", flag: "🇮🇶" },
      "نيجيريا": { currency: "النيرة النيجيرية", symbol: "₦", flag: "🇳🇬" },
      "الأرجنتين": { currency: "البيزو الأرجنتيني", symbol: "$", flag: "🇦🇷" },
      "البرازيل": { currency: "الريال البرازيلي", symbol: "R$", flag: "🇧🇷" }
    };

    const info = currencies[country];

    if (!info) {
      return sock.sendMessage(chatId, {
        text: `❌ لم يتم العثور على معلومات الدولة: *${country}*`
      }, { quoted: msg });
    }

    const form = `*𝐶𝑂𝑀𝑀𝐴𝑁𝐷 𝑊𝑂𝑅𝐿𝐷 🌍*\n\n` +
                 `*┃╻🧧╹↵ ※إسـم الـدولـة※↶*\n*「 ${country} 」*\n\n` +
                 `*┃╻💱╹↵ ※عـمـلـتـهـم※↶*\n*「 ${info.currency} 」*\n\n` +
                 `*┃╻💲╹↵ ※رمـز الـعـمـلـة※↶*\n*「 ${info.symbol} 」*\n\n` +
                 `*┃╻📯╹↵ ※رايـتـهـم※↶*\n*「 ${info.flag} 」*\n\n` +
                 `> *˼‏❖˹↵ لـيلـة سـعـيـدة 🍷*`;

    await sock.sendMessage(chatId, { text: form }, { quoted: msg });
  }
};