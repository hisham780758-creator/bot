const { jidDecode } = require('@whiskeysockets/baileys');
const { isElite } = require('../haykala/elite.js');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'حذف',
    description: 'حذف رسالة معينة في المجموعة (للنخبة فقط)',
    usage: '.حذف (بالرد على الرسالة)',
    category: 'tools',

    async execute(sock, msg) {
        // التوثيق الوهمي بـ ASCA
        const fakeOfficial = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "120363025246999999@g.us",
                id: "BAE5F7C88C7D8A3D3F1A3A",
            },
            message: {
                videoMessage: {
                    title: "𝑨 • S V2...",
                    seconds: "99999",
                    gifPlayback: true,
                    caption: "بّےــوُت𝒂𝒔𝒄𝒂𖤍",
                    jpegThumbnail: Buffer.alloc(0)
                }
            }
        };

        const chatId = msg.key.remoteJid;
        const sender = decode(msg.key.participant || chatId);
        const senderLid = sender.split('@')[0];

        // رد تفاعل أولاً
        await sock.sendMessage(chatId, {
            react: { text: "🔍", key: msg.key }
        });

        // التحقق من النخبة فقط
        if (!isElite(senderLid)) {
            await sock.sendMessage(chatId, {
                react: { text: "❌", key: msg.key }
            });
            
            return await sock.sendMessage(chatId, {
                text: '❌ *لا تملك صلاحية استخدام هذا الأمر.*\n\nهذا الأمر مخصص للنخبة فقط.'
            }, { quoted: fakeOfficial });
        }

        // التحقق من أن الأمر في مجموعة
        if (!chatId.endsWith('@g.us')) {
            return await sock.sendMessage(chatId, {
                text: '❌ هذا الأمر يعمل فقط داخل المجموعات.'
            }, { quoted: fakeOfficial });
        }

        // التحقق من وجود رد
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        if (!quoted || !quoted.stanzaId) {
            return await sock.sendMessage(chatId, {
                text: '❌ *رد على رسالة* لحذفها.\n\nاستخدم: `.حذف` (بالرد على الرسالة المطلوبة)'
            }, { quoted: fakeOfficial });
        }

        try {
            // التحقق من أن البوت مشرف
            const groupMetadata = await sock.groupMetadata(chatId);
            const botParticipant = groupMetadata.participants.find(p => p.id === decode(sock.user.id));
            const isBotAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, {
                    react: { text: "⚠️", key: msg.key }
                });
                
                return await sock.sendMessage(chatId, {
                    text: '❌ *أنا لست مشرفاً في المجموعة.*\n\nيجب أن أكون مشرفاً لحذف رسائل الآخرين.\n\n🔧 *الحل:* ارفعني مشرف في المجموعة.'
                }, { quoted: fakeOfficial });
            }

            // بدء الحذف
            await sock.sendMessage(chatId, {
                react: { text: "⏳", key: msg.key }
            });

            // محاولة حذف الرسالة المقتبسة
            const deleteResult = await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: false, // نفترض أنها ليست من البوت
                    id: quoted.stanzaId,
                    participant: quoted.participant || chatId
                }
            }).catch(err => {
                console.error('❌ خطأ في حذف الرسالة المقتبسة:', err.message);
                return { error: err.message };
            });

            // حذف رسالة الأمر نفسه (إذا كانت من البوت)
            if (msg.key.fromMe) {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: true,
                        id: msg.key.id
                    }
                }).catch(err => {
                    console.error('❌ خطأ في حذف رسالة الأمر:', err.message);
                });
            }

            // إذا كان فيه خطأ في الحذف
            if (deleteResult && deleteResult.error) {
                await sock.sendMessage(chatId, {
                    react: { text: "❌", key: msg.key }
                });
                
                const errorMsg = deleteResult.error;
                let userMsg = '❌ *فشل حذف الرسالة.*\n\n';
                
                if (errorMsg.includes('not an admin') || errorMsg.includes('not authorized')) {
                    userMsg += '⚠️ *مع أني مشرف، لكن قد تحتاج صلاحيات إضافية.*\n';
                    userMsg += '• تأكد أني أدمن بصلاحيات كاملة\n';
                    userMsg += '• جرب في مجموعة أخرى للتأكد';
                } else if (errorMsg.includes('Message not found') || errorMsg.includes('to delete not found')) {
                    userMsg += '⚠️ *الرسالة منتهية الصلاحية.*\n';
                    userMsg += '• واتساب يسمح بحذف الرسائل لفترة محددة فقط\n';
                    userMsg += '• حاول مع رسالة أحدث (أقل من ساعة)';
                } else {
                    userMsg += `🔧 *الخطأ:* ${errorMsg}`;
                }
                
                return await sock.sendMessage(chatId, {
                    text: userMsg
                }, { quoted: fakeOfficial });
            }

            // نجاح الحذف
            await sock.sendMessage(chatId, {
                react: { text: "✅", key: msg.key }
            });

            // تأكيد نجاح مؤقت
            const successMsg = await sock.sendMessage(chatId, {
                text: '✅ *تم حذف الرسالة بنجاح.*\n\n⏱️ *تنبيه:* الرسالة ستختفي بعد 3 ثواني'
            }, { quoted: fakeOfficial });

            // حذف رسالة التأكيد بعد 3 ثواني
            setTimeout(async () => {
                try {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: true,
                            id: successMsg.key.id
                        }
                    });
                } catch (e) {
                    console.log('⚠️ لا مشكلة: رسالة التأكيد اختفت تلقائياً');
                }
            }, 3000);

        } catch (err) {
            console.error('❌ خطأ عام في أمر الحذف:', err);
            
            await sock.sendMessage(chatId, {
                react: { text: "💥", key: msg.key }
            });
            
            await sock.sendMessage(chatId, {
                text: `❌ *حدث خطأ غير متوقع:*\n\n${err.message}\n\n🔧 *حاول:*\n1. تأكد أن البوت مشرف\n2. جرب مع رسالة أحدث\n3. أعد المحاولة`
            }, { quoted: fakeOfficial });
        }
    }
};