const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsFile));
    } catch {
        return {};
    }
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const animeQuestions = [
    { question: "من هو قائد قراصنة قبعة القش؟", answer: "لوفي" },
    { question: "ما اسم القطة في أنمي Sailor Moon؟", answer: "لونا" },
    { question: "من هو والد غوكو؟", answer: "باردوك" },
    { question: "ما اسم الشينيغامي في ديث نوت؟", answer: "ريوك" },
    { question: "كم عدد كرات التنين في دراغون بول؟", answer: "7" },
    { question: "من هو أول مستخدم لمانجيكيو شارينغان؟", answer: "إيتاتشي" },
    { question: "من هو أفضل صديق لـ ناروتو؟", answer: "ساسكي" },
    { question: "ما اسم أخ ليفاي بالتبني في هجوم العمالقة؟", answer: "كين" },
    { question: "من هو مؤسس طوكيو مانجي؟", answer: "ميكي" },
    { question: "من هو قاتل نيي في ون بيس؟", answer: "أكاينو" },
    { question: "ما اسم منظمة القتلة في القناص؟", answer: "العناكب" },
    { question: "من هو معلم غون في القناص؟", answer: "كايتو" },
    { question: "من هو ملك النمل في هنتر x هنتر؟", answer: "ميرويم" },
    { question: "من هو شقيق إدوارد إلريك؟", answer: "ألفونسو" },
    { question: "من هو أمير السايانز؟", answer: "فيجيتا" },
    { question: "من هو تلميذ كاكاشي الأقوى؟", answer: "ناروتو" },
    { question: "ما اسم حبيب ناروتو؟", answer: "هيناتا" },
    { question: "ما اسم القط في فيري تيل؟", answer: "هابي" },
    { question: "ما اسم سيف إيتشيغو؟", answer: "زنغتسو" },
    { question: "ما اسم من يستخدم عين الرينغان؟", answer: "ناغاتو" },
    { question: "من هو الكابتن في أنمي كوروكو؟", answer: "تيتسويا" },
    { question: "ما اسم أخ إيتاتشي؟", answer: "ساسكي" },
    { question: "من هو زعيم منظمة الأكاتسوكي؟", answer: "باين" },
    { question: "من هو أقوى شخصية في أنمي ون بنش مان؟", answer: "سايتاما" },
    { question: "ما اسم أنمي فيه دفتر يقتل الأشخاص؟", answer: "ديث نوت" },
    { question: "من هو قاتل والدي إيرين؟", answer: "زيك" },
    { question: "من هو عم لوفي؟", answer: "غارب" },
    { question: "ما اسم البطل في أنمي طوكيو غول؟", answer: "كانيكي" },
    { question: "ما اسم الفتاة التي تساعد إيرين؟", answer: "ميكاسا" },
    { question: "من هو ملك القراصنة؟", answer: "غول دي روجر" },
    { question: "ما اسم الأنمي الذي فيه سايتاما؟", answer: "ون بنش مان" },
    { question: "من هو صديق غون المفضل؟", answer: "كيلوا" },
    { question: "ما اسم الأنمي الذي فيه تانجيرو؟", answer: "قاتل الشياطين" },
    { question: "من هي أخت تانجيرو؟", answer: "نيزوكو" },
    { question: "من هو أقوى هاشيرا؟", answer: "يوتشييرو" },
    { question: "ما اسم الشيطان الذي يملك سيف في قاتل الشياطين؟", answer: "موزان" },
    { question: "ما اسم أول عملاق ظهر في هجوم العمالقة؟", answer: "العملاق المدرع" },
    { question: "ما اسم أنمي فيه نوتا بوك للقتل؟", answer: "ديث نوت" },
    { question: "من هو قائد فريق فيري تيل؟", answer: "ناتسو" },
    { question: "ما اسم شقيق زورو بالتدريب؟", answer: "كوزابورو" },
    { question: "ما اسم المنظمة التي يقودها دون كيهوتي؟", answer: "الدونكيهوتي" },
    { question: "ما اسم الفتاة التي تستخدم الجليد في فيري تيل؟", answer: "غراي" },
    { question: "من هو صاحب القبضة النارية في ون بيس؟", answer: "آيس" },
    { question: "ما اسم عملاق المطرقة؟", answer: "لارا تايبير" }
];

module.exports = {
    command: 'انمي',
    category: 'games',
    description: 'فعالية أسئلة أنمي',
usage: '.حل_انمي',

    async execute(sock, msg) {
        const groupJid = msg.key.remoteJid;
        if (!groupJid.endsWith('@g.us')) {
            return sock.sendMessage(groupJid, {
                text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبات.*'
            }, { quoted: msg });
        }

        const selected = animeQuestions[Math.floor(Math.random() * animeQuestions.length)];
        const question = selected.question;
        const answer = selected.answer.trim().toLowerCase();
        let isAnswered = false;

        const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
            `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔سؤال أنمي〕※*\n\n` +
            `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔سـيـتـم إعـطـاء سـؤال عـن الأنمـي، وعـليك مـعـرفـة الإجـابـة〕※*\n\n` +
            `*┃╻❓╹↵ الـسـؤال ↯*\n*⧉┋※〔 ${question} 〕※*\n\n` +
            `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
            `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝑨𝒔𝒄𝒂𝒏𝒐𝒓 𝑩𝒐𝒕 ٭*`;

        await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

        const listener = async (event) => {
            if (isAnswered) return;
            const m = event.messages[0];
            if (!m.message || m.key.remoteJid !== groupJid) return;
            const body = m.message?.conversation?.toLowerCase()?.trim();
            if (!body) return;

            if (body === answer) {
                isAnswered = true;
                sock.ev.off('messages.upsert', listener);

                const sender = m.key.participant;
                const number = extractPureNumber(sender);
                const pointsData = loadPoints();

                pointsData[number] = (pointsData[number] || 0) + 10;
                savePoints(pointsData);

                await sock.sendMessage(groupJid, {
                    text:
                        `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
                        `*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
                        `*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*\n\n` +
                        `*تـم مـنحـه الـنـقـاط* 🍁🪺`,
                    mentions: [sender]
                }, { quoted: m });
            }
        };

        sock.ev.on('messages.upsert', listener);

        setTimeout(async () => {
            sock.ev.off('messages.upsert', listener);
            if (!isAnswered) {
                await sock.sendMessage(groupJid, {
                    text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*`
                }, { quoted: msg });
            }
        }, 30000);
    }
};
