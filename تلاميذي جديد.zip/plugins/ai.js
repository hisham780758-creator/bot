const axios = require("axios");

module.exports = {
  command: ["بلتش"],
  description: "📖 مساعد يجيب معلومات من ويكيبيديا (عربي + إنجليزي)",
usage: '.ai',
  category: "ai",

  async execute(sock, msg) {
    const groupId = msg.key.remoteJid;

    const fullText =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption || "";

    const question = fullText.replace(/^[,،.]?بلتش\s*/i, "").trim();

    if (!question) {
      return await sock.sendMessage(groupId, {
        text: `🧠 اكتب سؤالك بعد كلمة "بلتش"\nمثال: .بلتش ليبيا`,
      }, { quoted: msg });
    }

    await sock.sendMessage(groupId, {
      text: "🔎 جاري البحث في ويكيبيديا...",
    }, { quoted: msg });

    // 🛠️ دالة تجيب نتيجة من ويكيبيديا
    async function getWikiResult(query, lang = "ar") {
      try {
        // 🔍 البحث عن أقرب عنوان
        const search = await axios.get(
          `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&utf8=&format=json`
        );

        const firstResult = search.data?.query?.search?.[0];
        if (!firstResult) return null;

        const pageTitle = firstResult.title;

        // 📖 جلب ملخص الصفحة
        const wiki = await axios.get(
          `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(pageTitle)}`
        );

        let reply = `📖 من ويكيبيديا (${lang === "ar" ? "العربية" : "English"}) - ${pageTitle}:\n\n${wiki.data.extract}`;

        return {
          text: reply,
          image: wiki.data.thumbnail?.source || null
        };
      } catch {
        return null;
      }
    }

    // ✅ جرب عربي
    let result = await getWikiResult(question, "ar");

    // ❌ لو ما لقاهاش جرب إنجليزي
    if (!result) {
      result = await getWikiResult(question, "en");
    }

    // ⛔ لو برضو ما لقاهاش
    if (!result) {
      return await sock.sendMessage(groupId, {
        text: `❌ لم أجد أي معلومة عن "${question}"`,
      }, { quoted: msg });
    }

    // ✅ لو لقى
    if (result.image) {
      return await sock.sendMessage(groupId, {
        image: { url: result.image },
        caption: result.text,
      }, { quoted: msg });
    } else {
      return await sock.sendMessage(groupId, {
        text: result.text,
      }, { quoted: msg });
    }
  },
};