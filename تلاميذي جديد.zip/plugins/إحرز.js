const fs = require('fs');
const path = require('path');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, JSON.stringify({}));

const { extractPureNumber } = require('../haykala/elite');

module.exports = {
  command: 'احزر',
  description: 'فعالية تخمين شخصية أنمي مع تلميحات',
usage: '.إحرز',
  category: 'games',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هذا الأمر يعمل فقط في القروبات.*'
      }, { quoted: msg });
    }

    const riddles = [
      { hint: 'شخص يحب أكل الرامن وعنده وحش مختوم داخله', emojiHint: '🍜🦊', answer: 'ناروتو' },
      { hint: 'شخصية عندها عين شارينقان وقتلت عشيرتها', emojiHint: '👁️🩸', answer: 'ايتاتشي' },
      { hint: 'أمير السايانز ويحب القتال', emojiHint: '🦾👑', answer: 'فيجيتا' },
      { hint: 'يقاتل بالكامي هامي ها ويدافع عن الأرض', emojiHint: '💥🛡️', answer: 'غوكو' },
      { hint: 'أبو ناروتو وكان الهوكاجي الرابع', emojiHint: '⚡👤', answer: 'ميناتو' },
      { hint: 'قائد الهجوم على العمالقة', emojiHint: '🗡️🌍', answer: 'إيرين' },
      { hint: 'تحمل وشاح أحمر وتقاتل العمالقة', emojiHint: '🧣⚔️', answer: 'ميكاسا' },
      { hint: 'يحمل دفتر يقتل الناس بكتابته فيه', emojiHint: '📓💀', answer: 'لايت' },
      { hint: 'يستخدم سيفين ويصرخ "سانتوريو"', emojiHint: '⚔️🗡️🦈', answer: 'زورو' },
      { hint: 'من الأنمي بليتش ويملك خطة ضخمة', emojiHint: '🧠👓', answer: 'أيزن' },
      { hint: 'الفتى من المحقق كونان وتحمل ذكاء عالي', emojiHint: '🔍🎀', answer: 'كونان' },
      { hint: 'من ديث نوت يساعد الشرطة ويحب الحلى', emojiHint: '🍰🧠', answer: 'إل' }
    ];

    const selected = riddles[Math.floor(Math.random() * riddles.length)];

    const question = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🎻◜ • ╾━ ─┈‏ ٠ ⎔*\n\n*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔إحـرز〕※*\n\n*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔الـبـوت يـرسـل صـفـة او معـلومة، وعلـى المشـاركيـن تخمين الشـخصـية〕※*\n\n*┃╻📜╹↵المـعـلومـة عـن الشـخـصـية↯*\n*⧉┋※〔 ${selected.hint} 〕※*\n*⧉┋※〔 ${selected.emojiHint} 〕※*\n\n*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*⎔ ٠ ┈─ ━╼ • ◞🎻◜ • ╾━ ─┈‏ ٠ ⎔*\n*٭ فـعـالـيـات بـوت أسكانور ٭*`;

    await sock.sendMessage(groupJid, { text: question }, { quoted: msg });

    const answer = selected.answer.toLowerCase().trim();
    let isAnswered = false;

    const listener = async (event) => {
      if (isAnswered) return;

      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;

      const body = m.message?.conversation?.toLowerCase().trim();
      if (!body) return;

      if (body.includes(answer)) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const winner = m.key.participant || m.key.remoteJid;
        const userNumber = extractPureNumber(winner);

        let data = JSON.parse(fs.readFileSync(pointsFile));
        data[userNumber] = (data[userNumber] || 0) + 10;
        fs.writeFileSync(pointsFile, JSON.stringify(data, null, 2));

        const result = `*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「@${userNumber}」*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「${selected.answer}」*\n\n*تـم مـنحـه الـنـقـاط*🍁🪺`;

        await sock.sendMessage(groupJid, {
          text: result,
          mentions: [winner]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(async () => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        await sock.sendMessage(groupJid, {
          text: `*⏰ انتهى الوقت!* لم يجب أحد.\n*✅ الإجابة هي : ${selected.answer}*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};
