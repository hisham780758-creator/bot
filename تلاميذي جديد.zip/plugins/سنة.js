const { addPoints } = require('../data/pointsHelper');

const questions = [
  {
    question: 'من هو خاتم الأنبياء؟',
    options: ['عيسى', 'محمد', 'موسى', 'نوح'],
    answer: 'محمد'
  },
  {
    question: 'كم عدد ركعات صلاة الفجر؟',
    options: ['2', '3', '4', '5'],
    answer: '2'
  },
  {
    question: 'ما هو أول كتاب سماوي نزل؟',
    options: ['الإنجيل', 'التوراة', 'الزبور', 'القرآن'],
    answer: 'التوراة'
  },
  {
    question: 'من هو النبي الذي ابتلعه الحوت؟',
    options: ['يونس', 'إبراهيم', 'صالح', 'نوح'],
    answer: 'يونس'
  },
  {
    question: 'في أي شهر يصوم المسلمون؟',
    options: ['محرم', 'رمضان', 'شعبان', 'ذو الحجة'],
    answer: 'رمضان'
  },
  {
    question: 'كم عدد أركان الإسلام؟',
    options: ['3', '4', '5', '6'],
    answer: '5'
  },
  {
    question: 'ما اسم أم النبي محمد ﷺ؟',
    options: ['آمنة', 'خديجة', 'فاطمة', 'عائشة'],
    answer: 'آمنة'
  },
  {
    question: 'من هو أول من أسلم من الصبيان؟',
    options: ['علي بن أبي طالب', 'عمر بن الخطاب', 'بلال بن رباح', 'أبو بكر'],
    answer: 'علي بن أبي طالب'
  },
  {
    question: 'أين وُلد النبي محمد ﷺ؟',
    options: ['المدينة', 'مكة', 'الطائف', 'بدر'],
    answer: 'مكة'
  },
  {
    question: 'من هو أول نبي؟',
    options: ['إدريس', 'نوح', 'آدم', 'إبراهيم'],
    answer: 'آدم'
  },
  {
    question: 'ما أول سورة في القرآن؟',
    options: ['الفاتحة', 'البقرة', 'الناس', 'الإخلاص'],
    answer: 'الفاتحة'
  },
  {
    question: 'كم عدد الصلوات المفروضة؟',
    options: ['3', '4', '5', '6'],
    answer: '5'
  },
  {
    question: 'من هو النبي الذي فُضّل بالكلام مع الله؟',
    options: ['موسى', 'عيسى', 'إبراهيم', 'نوح'],
    answer: 'موسى'
  },
  {
    question: 'ما هي القبلة الأولى للمسلمين؟',
    options: ['البيت الحرام', 'المسجد النبوي', 'بيت المقدس', 'الصفا والمروة'],
    answer: 'بيت المقدس'
  },
  {
    question: 'من هو أول خليفة للمسلمين؟',
    options: ['عمر بن الخطاب', 'علي بن أبي طالب', 'عثمان بن عفان', 'أبو بكر الصديق'],
    answer: 'أبو بكر الصديق'
  },
  {
    question: 'من هو مؤذن الرسول؟',
    options: ['بلال بن رباح', 'عبدالله بن أم مكتوم', 'سعد بن أبي وقاص', 'عمار بن ياسر'],
    answer: 'بلال بن رباح'
  },
  {
    question: 'كم مرة تُؤدى صلاة التراويح في رمضان؟',
    options: ['8', '10', '20', '30'],
    answer: '20'
  },
  {
    question: 'من هو النبي الذي بُعث لبني إسرائيل؟',
    options: ['عيسى', 'موسى', 'داوود', 'سليمان'],
    answer: 'موسى'
  },
  {
    question: 'من هو النبي الذي آمن به الجن؟',
    options: ['محمد', 'عيسى', 'نوح', 'إدريس'],
    answer: 'محمد'
  },
  {
    question: 'أين نزل الوحي لأول مرة؟',
    options: ['غار حراء', 'غار ثور', 'جبل أحد', 'البيت الحرام'],
    answer: 'غار حراء'
  },
];

module.exports = {
  command: 'سنة',
  description: '❓ لعبة أسئلة دينية سريعة',
usage: '.سنة',
  category: 'ألعاب',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.key.remoteJid;

    const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
    const { question, options, answer } = randomQuestion;

    const formattedQuestion = `🕌 *${question}*\n\n${options.map((opt, i) => `${i + 1}- ${opt}`).join('\n')}\n\n⏳ لديك 15 ثانية!`;

    await sock.sendMessage(chatId, {
      text: formattedQuestion,
    }, { quoted: msg });

    let answered = false;

    const onMessage = async ({ messages }) => {
      for (const m of messages) {
        const fromSameChat = m.key.remoteJid === chatId;
        const body = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
        const text = body.trim().toLowerCase();

        if (fromSameChat && !answered && (
          text === answer.toLowerCase() || text === `${options.indexOf(answer) + 1}`
        )) {
          answered = true;
          sock.ev.off('messages.upsert', onMessage);

          const name = m.pushName || 'مستخدم';
          const userJid = m.key.participant || m.key.remoteJid;

          addPoints(userJid, 5);

          await sock.sendMessage(chatId, {
            text: `✅ أحسنت يا *${name}*!\nالإجابة الصحيحة: *${answer}*\n🏅 تم منحك 5 نقاط!`,
          }, { quoted: m });
        }
      }
    };

    sock.ev.on('messages.upsert', onMessage);

    setTimeout(() => {
      if (!answered) {
        sock.ev.off('messages.upsert', onMessage);
        sock.sendMessage(chatId, {
          text: `⌛ انتهى الوقت!\nالإجابة الصحيحة كانت: *${answer}*`
        }, { quoted: msg });
      }
    }, 15000);
  }
};