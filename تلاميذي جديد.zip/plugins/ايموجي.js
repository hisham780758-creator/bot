const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

const animeEmojis = [
  { emojis: ['🍥', '🌀', '👊'], answer: 'ناروتو' },
  { emojis: ['👒', '🌊', '🍖'], answer: 'لوفي' },
  { emojis: ['🗡️', '💪', '🍷'], answer: 'زورو' },
  { emojis: ['💀', '🌑', '👁️‍🗨️'], answer: 'إيتاتشي' },
  { emojis: ['🐒', '🔥', '👊'], answer: 'غوكو' },
  { emojis: ['⚡', '👦', '🔪'], answer: 'كيلوا' },
  { emojis: ['🍡', '📚', '🥷'], answer: 'كاكاشي' },
  { emojis: ['🔍', '🍰', '🪑'], answer: 'إل' },
  { emojis: ['🌙', '📓', '🖋️'], answer: 'لايت' },
  { emojis: ['🔥', '🛡️', '🧬'], answer: 'إيرين' },
  { emojis: ['🔺', '🌩️', '🦅'], answer: 'ساسكي' },
  { emojis: ['🧪', '🧠', '⚙️'], answer: 'سينكو' },
  { emojis: ['😈', '🧥', '🔮'], answer: 'أيزن' },
  { emojis: ['🩸', '👹', '🎴'], answer: 'نيزوكو' },
  { emojis: ['🎯', '🎣', '🐻'], answer: 'غون' },
  { emojis: ['🕯️', '📿', '👓'], answer: 'كورابيكا' },
];

module.exports = {
  command: 'ايموجي',
  description: 'فعالية تخمين الشخصية من الإيموجيات',
usage: '.ايموجي',
  category: 'games',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هذا الأمر يعمل فقط داخل القروبات.*'
      }, { quoted: msg });
    }

    const entry = animeEmojis[Math.floor(Math.random() * animeEmojis.length)];
    const answer = entry.answer.trim().toLowerCase();
    const emojiList = entry.emojis.join(' ');
    let isAnswered = false;

    const startMessage = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🎭◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📜╹↵اسـم الفـعـالـية↯* \n*⧉┋※〔إيـمـوجـي〕※*\n\n` +
      `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔خـمّـن إسـم شـخـصـية الإنـمـي مـن الإيـمـوجـي〕※*\n\n` +
      `*┃╻🎯╹↵الإيـمـوجـيـات ↯*\n*⧉┋※〔 ${emojiList} 〕※*\n\n` +
      `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🎭◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
      `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 B̶O̶T̶ A̶S̶C̶A̶N̶O̶R̶ ٭*`;

    await sock.sendMessage(groupJid, { text: startMessage }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase().trim();
      if (!body) return;

      if (body === answer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant || m.key.remoteJid;
        const number = extractPureNumber(sender);

        let points = {};
        if (fs.existsSync(pointsFile)) {
          points = JSON.parse(fs.readFileSync(pointsFile));
        }

        points[number] = (points[number] || 0) + 10;
        fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${entry.answer} 」*\n\n` +
`*تـم مـنحـه الـنـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(() => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${entry.answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};