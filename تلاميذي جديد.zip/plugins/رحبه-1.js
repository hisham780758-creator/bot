const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');

const dataDir = path.join(__dirname, '..', 'data');
const rahbaFile = path.join(dataDir, 'rahbaState.json');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(rahbaFile)) fs.writeFileSync(rahbaFile, JSON.stringify({}));

const loadRahbaState = () => {
  try {
    return JSON.parse(fs.readFileSync(rahbaFile));
  } catch (err) {
    console.error("خطأ في قراءة ملف الترحيب:", err);
    return {};
  }
};

const saveRahbaState = (data) => {
  try {
    fs.writeFileSync(rahbaFile, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("خطأ في حفظ ملف الترحيب:", err);
  }
};

let listenerAttached = false;

module.exports = {
  command: 'رحبه',
  description: 'تشغيل / إيقاف الترحيب التلقائي عند دخول الأعضاء (خاص بالنخبة)',
usage: '.رحبه-1',
  category: 'نخبة',

  async execute(sock, m) {
    const groupId = m.key.remoteJid;
    const sender = m.key.participant || m.participant;

    if (!groupId.endsWith('@g.us')) {
      return sock.sendMessage(groupId, { text: '❌ هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: m });
    }

    if (!isElite(sender)) {
      return sock.sendMessage(groupId, { text: '🚫 هذا الأمر مخصص للنخبة فقط.' }, { quoted: m });
    }

    const state = loadRahbaState();

    if (state[groupId]) {
      delete state[groupId];
      saveRahbaState(state);
      return sock.sendMessage(groupId, { text: '⛔ تم إيقاف الترحيب.' }, { quoted: m });
    }

    state[groupId] = true;
    saveRahbaState(state);
    sock.sendMessage(groupId, { text: '✅ تم تفعيل الترحيب.' }, { quoted: m });

    if (listenerAttached) return;

    sock.ev.on('group-participants.update', async (update) => {
      const activeState = loadRahbaState();
      const isWelcoming = activeState[update.id];

      if (!isWelcoming || update.action !== 'add') return;

      for (const participant of update.participants) {
        const number = participant.split('@')[0];
        const metadata = await sock.groupMetadata(update.id);
        const membersCount = metadata.participants.length;

        const now = new Date();
        const time = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        const date = now.toLocaleDateString('ar-EG');

        let ppUrl = await sock.profilePictureUrl(participant, 'image').catch(() => null);
        if (!ppUrl) {
          ppUrl = await sock.profilePictureUrl(update.id, 'image').catch(() => null);
        }

        const welcomeMessage = `
*❛ ━━━━━━･❪ 𝒂𝒔𝒄𝒂𝒏𝒐𝒓 ❫ ･━━━━━━ ❜*
❒ *╭┈⊰* 🌷الــتــرحــيــب🌷 *⊰┈ ✦*
*┊˹📯˼┊ اهــلا بـك/ي*
┊˹🥷🏻˼┊ @${number}
┊📩 *اقرأ وصف المجموعة*

🕒 الوقت: ${time}
📅 التاريخ: ${date}
👥 عدد الأعضاء: ${membersCount}

*『مـرحـبـاً بـك بـيـن اخـوتـك』*
`;

        const media = ppUrl
          ? { image: { url: ppUrl }, caption: welcomeMessage }
          : { text: welcomeMessage };

        await sock.sendMessage(update.id, {
          ...media,
          mentions: [participant]
        });
      }
    });

    listenerAttached = true;
  }
};