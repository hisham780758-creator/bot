const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsFile));
    } catch {
        return {};
    }
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const cases = [
    {
        crime: "🕵️‍♂️ تم العثور على شخصية أنمي مشهورة مقتولة في غابة مهجورة!",
        suspects: ["إيتاشي", "لايت", "هيسوكا", "ليفاي"],
        killer: "لايت"
    },
    {
        crime: "💀 وُجدت شخصية ميتة في أحد الأبراج العالية بعد سقوطها الغامض.",
        suspects: ["كاكاشي", "لوفي", "إرين", "ماكوتو"],
        killer: "ماكوتو"
    },
    {
        crime: "🔪 قُتلت شخصية في مطبخ القصر باستخدام سكين!",
        suspects: ["ميكاسا", "هيناتا", "شينوبو", "أكازا"],
        killer: "شينوبو"
    },
    {
        crime: "🩸 جريمة غريبة حدثت في مهرجان أنمي... الضحية قُتلت وسط الحشود!",
        suspects: ["سايتاما", "زورو", "باجي", "إيتشيغو"],
        killer: "باجي"
    },
    {
        crime: "🎭 تم العثور على جثة في المسرح! والجميع كان يرتدي أقنعة.",
        suspects: ["كيليوا", "لاو", "شيسوي", "توغورو"],
        killer: "شيسوي"
    },
    {
        crime: "🕳️ جريمة في قطار سريع! أحد الركّاب اختفى فجأة ووجدت جثته!",
        suspects: ["جين", "كورابيكا", "ريوكا", "إينوسكي"],
        killer: "جين"
    },
    {
        crime: "🌊 تم اكتشاف جثة تطفو فوق سطح البحر قرب الجزيرة.",
        suspects: ["لوفي", "نامي", "سانجي", "أوروتشيمارو"],
        killer: "نامي"
    },
    {
        crime: "⚔️ تم قتل أحد المحاربين في غرفة التدريب!",
        suspects: ["زورو", "إيتاشي", "ريوك", "غوجو"],
        killer: "إيتاشي"
    },
    {
        crime: "👁️ جريمة وقعت في منزل غامض، وكاميرات المراقبة تعطلت فجأة.",
        suspects: ["كانا", "لايت", "كيلوا", "شينرا"],
        killer: "لايت"
    },
    {
        crime: "💣 انفجار ضخم أدى إلى مقتل شخصية رئيسية في اجتماع سري.",
        suspects: ["باين", "مادارا", "إيتشيغو", "توبي"],
        killer: "توبي"
    },
    {
        crime: "💔 تم تسميم مشروب أحد الشخصيات خلال حفلة.",
        suspects: ["ساكورا", "شينوبو", "هانجي", "نيكو روبين"],
        killer: "شينوبو"
    },
    {
        crime: "🧪 قُتلت شخصية في مختبر تجربة غامض.",
        suspects: ["فرانكي", "كوروسينسي", "ستين", "أوكتاغون"],
        killer: "كوروسينسي"
    },
    {
        crime: "🚗 حادث سيارة مميت، لكن تبين أنه مدبّر!",
        suspects: ["شين", "ران", "كونان", "كايتو كيد"],
        killer: "كايتو كيد"
    },
    {
        crime: "🔐 وُجدت جثة خلف باب مغلق من الداخل!",
        suspects: ["غون", "ليوريو", "هيسوكا", "ميرويم"],
        killer: "هيسوكا"
    },
    {
        crime: "🕸️ قُتلت شخصية في غابة العناكب، ولا أحد رأى شيئًا.",
        suspects: ["كورورو", "فيتان", "باكوغو", "شيسوي"],
        killer: "كورورو"
    }
];

module.exports = {
    command: 'جريمة',
    category: 'games',
    description: 'فعالية كشف القاتل',
usage: '.حل_القاتل',

    async execute(sock, msg) {
        const groupJid = msg.key.remoteJid;
        if (!groupJid.endsWith('@g.us')) {
            return sock.sendMessage(groupJid, {
                text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبات.*'
            }, { quoted: msg });
        }

        const selectedCase = cases[Math.floor(Math.random() * cases.length)];
        const crimeDescription = selectedCase.crime;
        const suspects = selectedCase.suspects.join("، ");
        const killerAnswer = selectedCase.killer.trim().toLowerCase();
        let isAnswered = false;

        const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
            `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔كـشـف الـقـاتـل〕※*\n\n` +
            `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔سـيـتـم إعـطـاء وصـف جـريـمة و بـعـض الـمـشـتـبـه بـهـم، وعـليـك مـعـرفـة الـقـاتـل〕※*\n\n` +
            `*┃╻🔪╹↵ الـجـريـمـة ↯*\n*⧉┋※〔 ${crimeDescription} 〕※*\n\n` +
            `*┃╻🕵️‍♂️╹↵ الـمـشـتـبـه بـهـم ↯*\n*⧉┋※〔 ${suspects} 〕※*\n\n` +
            `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
            `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝑩𝒐𝒕 𝑨𝒔𝒄𝒂𝒏𝒐𝒓 ٭*`;

        await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

        const listener = async (event) => {
            if (isAnswered) return;
            const m = event.messages[0];
            if (!m.message || m.key.remoteJid !== groupJid) return;
            const body = m.message?.conversation?.toLowerCase()?.trim();
            if (!body) return;

            if (body === killerAnswer) {
                isAnswered = true;
                sock.ev.off('messages.upsert', listener);

                const sender = m.key.participant;
                const number = extractPureNumber(sender);
                const pointsData = loadPoints();

                pointsData[number] = (pointsData[number] || 0) + 10;
                savePoints(pointsData);

                await sock.sendMessage(groupJid, {
                    text:
                        `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
                        `*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
                        `*┃╻🪻╹↵الـقـاتـل ↯*\n*❐ ↵「 ${selectedCase.killer} 」*\n\n` +
                        `*تـم مـنحـه الـنـقـاط* 🍁🪺`,
                    mentions: [sender]
                }, { quoted: m });
            }
        };

        sock.ev.on('messages.upsert', listener);

        setTimeout(async () => {
            sock.ev.off('messages.upsert', listener);
            if (!isAnswered) {
                await sock.sendMessage(groupJid, {
                    text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الـقـاتـل ↯*\n*❐ ↵「 ${selectedCase.killer} 」*`
                }, { quoted: msg });
            }
        }, 30000);
    }
};
