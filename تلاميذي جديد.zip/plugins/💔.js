const fs = require('fs');
const path = require('path');

module.exports = {
  command: '💔',
  description: 'يبعت رسالة ثابتة عن الخيانة + أغنية',
  usage: '.💔',
  category: 'fun',

  async execute(sock, msg) {
    try {
      const jid = msg.key.remoteJid;

      // الرسالة الثابتة
      const text = '💔 وهي تباً للجميع...\nالخيانة مالهاش رحمة، القلوب المكسورة مش هتنسى، والأمانة راحت مع الريح.';

      // ابعت الرسالة
      await sock.sendMessage(jid, { text }, { quoted: msg });

      // ابعت الأغنية من media/heartbreak.mp3
      const audioPath = path.join(process.cwd(), 'media', 'heartbreak.mp3');
      if (fs.existsSync(audioPath)) {
        const audioBuffer = fs.readFileSync(audioPath);
        await sock.sendMessage(
          jid,
          { audio: audioBuffer, mimetype: 'audio/mpeg', ptt: false }, // ptt:true لو تحبها فويس
          { quoted: msg }
        );
      } else {
        await sock.sendMessage(jid, { text: '⚠️ ملف media/heartbreak.mp3 مش موجود.' }, { quoted: msg });
      }
    } catch (err) {
      console.error('💔 command error:', err);
      await sock.sendMessage(msg.key.remoteJid, { text: `حصل خطأ:\n${err.message}` }, { quoted: msg });
    }
  }
};