const fs = require('fs');
const path = require('path');
const pointsFile = path.join(__dirname, '..', 'data', 'points.json');

const { extractPureNumber } = require('../haykala/elite');

const quotes = [
  { quote: "من لا يلتزم بالقوانين هو حثالة، لكن من يتخلى عن أصدقائه فهو أسوأ من الحثالة.", answer: "كاكاشي" },
  { quote: "سأصبح ملك القراصنة!", answer: "لوفي" },
  { quote: "أنا سأمحو كل من يعترض طريقي... حتى لو كان من العائلة.", answer: "ساسكي" },
  { quote: "الذين لا يعرفون الألم، لن يعرفوا السلام.", answer: "باين" },
  { quote: "أحببتكِ من كل قلبي... يوزوها!", answer: "إيتاتشي" },
  { quote: "أنا لست بطلاً، أنا مجرد أخ أكبر... قوي.", answer: "إيس" },
  { quote: "لا شيء يحدث بالصدفة، كل شيء قدر.", answer: "أوراهارا كيسكي" },
  { quote: "سأحمل عبء الكراهية وأمضي للأمام.", answer: "إيتاتشي" },
  { quote: "الموت ليس نهاية، بل مجرد بداية جديدة.", answer: "إيرين" },
  { quote: "الناس يزدادون قوة عندما يريدون حماية شيء مهم.", answer: "أكاي" }
];

module.exports = {
  command: 'مقولة',
  description: 'فعالية من قال المقولة – أنمي',
usage: '.مقولة',
  category: 'games',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, { text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروب.*' }, { quoted: msg });
    }

    const { quote, answer } = quotes[Math.floor(Math.random() * quotes.length)];
    let isAnswered = false;

    const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞💭◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻💬╹↵مـن قـال هـذه الـمـقـولة؟ ↯*\n*⧉┋※〔"${quote}"〕※*\n\n` +
      `*┃╻🕰️╹↵لديـكـم 30 ثـانـيـة للإجـابـة ↯*\n*⎔ ٠ ┈─ ━╼ • ◞💭◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
      `*٭ فـعـالـيـات بـوت إيـريـن*\n*٭𝐴𝑁𝐼𝑀𝐸 𝑄𝑈𝑂𝑇𝐸𝑆 𝐵𝑂𝑇 𝐸𝑅𝐸𝑁٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;

      const body = m.message?.conversation?.toLowerCase()?.trim();
      if (!body) return;

      if (body === answer.toLowerCase()) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);
        const sender = m.key.participant || m.key.remoteJid;
        const senderId = extractPureNumber(sender);

        let points = {};
        if (fs.existsSync(pointsFile)) {
          points = JSON.parse(fs.readFileSync(pointsFile));
        }
        points[senderId] = (points[senderId] || 0) + 1;
        fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n❐ ↵「@${senderId}」\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n❐ ↵「${answer}」\n\n` +
`*تـم مـنحـه الـنـقـاط*🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(() => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يُجِب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n❐ ↵「${answer}」`
        }, { quoted: msg });
      }
    }, 30000);
  }
};