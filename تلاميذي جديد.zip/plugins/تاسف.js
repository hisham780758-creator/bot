const { jidDecode } = require('@whiskeysockets/baileys');
const { eliteNumbers } = require('../haykala/elite.js');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  command: "تاسف",
  description: "يجبر عضو على قول 'اسف' خلال 30 ثانية أو يُطرد (نخبة فقط).",
usage: '.تاسف',
  category: "fun",
  async execute(sock, msg, args) {
    const groupJid = msg.key.remoteJid;
    const sender = jidDecode(msg.key.participant || msg.key.remoteJid)?.user || msg.key.participant?.split('@')[0];
    const senderLid = sender.split('@')[0];

    const mention = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

    if (!groupJid.endsWith("@g.us"))
      return sock.sendMessage(groupJid, { text: "❗ هذا الأمر يُستخدم داخل المجموعات فقط." }, { quoted: msg });

    if (!eliteNumbers.includes(senderLid))
      return sock.sendMessage(groupJid, {
        text: "❌ أمر أكبر من حجمك يا عاق\nأوامر أسيادك لا تقرب منها ☠️"
      }, { quoted: msg });

    if (!mention)
      return sock.sendMessage(groupJid, { text: "👤 منشن الشخص اللي لازم يعتذر." }, { quoted: msg });

    // نرسل الرسالة للمرة الأولى مع التوقيت 30
    let timeLeft = 30;
    const countdownMsg = await sock.sendMessage(groupJid, {
      text: `💢 <@${mention.split("@")[0]}>
عندك ${timeLeft} ثانية تقول *اسف* وإلا الطرد 😈`,
      mentions: [mention]
    });

    // نبدأ العد التنازلي ونحدث نفس الرسالة كل ثانية
    let saidSorry = false;

    const listener = async (raw) => {
      try {
        const m = raw.messages[0];
        const fromUser = m.key.participant || m.key.remoteJid;
        const content = m.message?.conversation || m.message?.extendedTextMessage?.text || "";

        if (fromUser === mention && content.toLowerCase().includes("اسف")) {
          saidSorry = true;
          sock.ev.off("messages.upsert", listener);
        }
      } catch (e) {}
    };

    sock.ev.on("messages.upsert", listener);

    while (timeLeft > 0 && !saidSorry) {
      await sleep(1000);
      timeLeft--;

      if (saidSorry) break;

      try {
        await sock.sendMessage(groupJid, {
          edit: countdownMsg.key,
          text: `💢 <@${mention.split("@")[0]}>
عندك ${timeLeft} ثانية تقول *اسف* وإلا الطرد 😈`,
          mentions: [mention]
        });
      } catch (e) {
        break;
      }
    }

    sock.ev.off("messages.upsert", listener);

    if (saidSorry) {
      await sock.sendMessage(groupJid, {
        text: `✅ <@${mention.split("@")[0]}> هربت من العقاب يا محظوظ 😎`,
        mentions: [mention]
      });
    } else {
      try {
        await sock.groupParticipantsUpdate(groupJid, [mention], "remove");
        await sock.sendMessage(groupJid, {
          text: `❌ <@${mention.split("@")[0]}> لم يعتذر... وتم الطرد! 💥`,
          mentions: [mention]
        });
      } catch (err) {
        await sock.sendMessage(groupJid, {
          text: "⚠️ فشل في الطرد، قد لا أمتلك الصلاحيات.",
        });
      }
    }
  }
};
