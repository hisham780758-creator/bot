const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

module.exports = {
  command: 'تح',
  description: 'تحويل الملصق إلى صورة',
  usage: '.صوره (بالرد على ملصق)',
  category: 'الوسائط',
  async execute(sock, m) {
    try {
      const contextInfo = m.message?.extendedTextMessage?.contextInfo;

      if (!contextInfo || !contextInfo.quotedMessage || !contextInfo.quotedMessage.stickerMessage) {
        return await sock.sendMessage(m.key.remoteJid, {
          text: '⚠️ يرجى الرد على ملصق لتحويله إلى صورة.'
        }, { quoted: m });
      }

      const stickerMsg = contextInfo.quotedMessage.stickerMessage;
      const stream = await downloadContentFromMessage(stickerMsg, 'sticker');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      if (!buffer.length) {
        return await sock.sendMessage(m.key.remoteJid, {
          text: '⚠️ فشل تحميل الملصق، حاول مجددًا.'
        }, { quoted: m });
      }

      const inputPath = path.join(__dirname, '../temp-sticker.webp');
      const outputPath = path.join(__dirname, '../temp-image.png');

      fs.writeFileSync(inputPath, buffer);

      exec(`ffmpeg -i "${inputPath}" "${outputPath}"`, async (error) => {
        if (error) {
          console.error('FFmpeg error:', error);
          return await sock.sendMessage(m.key.remoteJid, {
            text: '❌ حدث خطأ أثناء تحويل الملصق إلى صورة.'
          }, { quoted: m });
        }

        const imgBuffer = fs.readFileSync(outputPath);
        await sock.sendMessage(m.key.remoteJid, {
          image: imgBuffer,
          caption: '✅ تم تحويل الملصق إلى صورة.'
        }, { quoted: m });

        // تنظيف الملفات المؤقتة
        fs.unlinkSync(inputPath);
        fs.unlinkSync(outputPath);
      });

    } catch (err) {
      console.error('Error:', err);
      await sock.sendMessage(m.key.remoteJid, {
        text: '❌ حدث خطأ غير متوقع، حاول مرة أخرى.'
      }, { quoted: m });
    }
  }
};