module.exports = {
  command: "ضحكه",
  description: "يرسل 100 ايموجي ضحك 😂",
  usage: ".ضحكه",
  category: "fun",

  async execute(sock, msg) {
    const crazyLaugh = "😂".repeat(2000);

    await sock.sendMessage(msg.key.remoteJid, {
      text: crazyLaugh
    }, { quoted: msg });
  }
};