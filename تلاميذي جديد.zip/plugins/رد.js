module.exports = {
    command: 'رد',
    description: 'ظˆطµظپ رد',
    usage: '.رد',
    category: 'tools',

    async execute(sock, msg, args) {
        .. 
const customCommands = {
  "مارو": "👑عمك🔥",
  "برزيلي": "👟 بنعال عمك البرزيلي دخل السيرفر 😎",
  "سولو": "⚡ اعمامك",
  "مسا": "🌙 مسا النور على الرجالة الطيبة ✨",
  "مين": "👁️‍🗨️ أنت تسأل ومارو يجاوب 💀",
  "اسكا": "🫦 انت تقول متعرفش اسكانور احب اعرفك عليه هو المطور الاول لي و المسؤل عني", 
};

const handler = async (m, { command }) => {
  const text = customCommands[command];
  if (text) {
    await m.reply(text);
  }
};

handler.command = Object.keys(customCommands);
handler.help = ["أوامر مخصصة: " + Object.keys(customCommands).join(", ")];
handler.tags = ["fun"];

module.exports = handler;
    }
};
