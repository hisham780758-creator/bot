module.exports = {
  command: 'سكان',
  description: 'يعرض عدد سكان الدولة المطلوبة.',
usage: '.سكان',
  category: 'world',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    const fullText = msg.message?.conversation ||
                     msg.message?.extendedTextMessage?.text || '';

    const country = fullText.split(' ').slice(1).join(' ').trim();

    if (!country) {
      return sock.sendMessage(chatId, {
        text: '❗ يرجى كتابة اسم الدولة بعد الأمر.\nمثال: `.سكان اليابان`'
      }, { quoted: msg });
    }

    const populationData = {
      "مصر": "105 مليون نسمة",
      "السعودية": "36 مليون نسمة",
      "المغرب": "37 مليون نسمة",
      "الجزائر": "45 مليون نسمة",
      "تونس": "12 مليون نسمة",
      "فلسطين": "5.3 مليون نسمة",
      "سوريا": "22 مليون نسمة",
      "العراق": "43 مليون نسمة",
      "لبنان": "5.5 مليون نسمة",
      "الأردن": "11 مليون نسمة",
      "أمريكا": "336 مليون نسمة",
      "كندا": "39 مليون نسمة",
      "فرنسا": "68 مليون نسمة",
      "ألمانيا": "84 مليون نسمة",
      "تركيا": "85 مليون نسمة",
      "اليابان": "124 مليون نسمة",
      "الهند": "1.43 مليار نسمة",
      "الصين": "1.41 مليار نسمة",
      "كوريا الجنوبية": "52 مليون نسمة",
      "إيطاليا": "59 مليون نسمة",
      "إسبانيا": "47 مليون نسمة",
      "روسيا": "143 مليون نسمة",
      "البرازيل": "216 مليون نسمة",
      "الأرجنتين": "46 مليون نسمة",
      "نيجيريا": "223 مليون نسمة",
      "باكستان": "241 مليون نسمة",
      "إندونيسيا": "278 مليون نسمة"
    };

    const population = populationData[country];

    if (!population) {
      return sock.sendMessage(chatId, {
        text: `❌ لم يتم العثور على معلومات عدد السكان للدولة: *${country}*`
      }, { quoted: msg });
    }

    const form = `*𝐶𝑂𝑀𝑀𝐴𝑁𝐷 𝑊𝑂𝑅𝐿𝐷 🌍*\n\n` +
                 `*┃╻🧧╹↵ ※إسـم الـدولـة※↶*\n*「 ${country} 」*\n\n` +
                 `*┃╻👥╹↵ ※عـدد سـكـانـهـم※↶*\n*「 ${population} 」*\n\n` +
                 `> *˼‏❖˹↵ لـيلـة سـعـيـدة 🍷*`;

    await sock.sendMessage(chatId, { text: form }, { quoted: msg });
  }
};