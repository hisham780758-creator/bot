re('fs');
const path = require('path');

// تعديل هذا المسار حسب مجلد صورك
const imagesDir = path.join(__dirname, '../media/anime');

// قائمة الشخصيات
const characters = [
  { name: 'ناروتو', file: 'naruto.jpg' },
  { name: 'لوفي', file: 'luffy.jpg' },
  { name: 'إيتاتشي', file: 'itachi.jpg' },
  { name: 'ميكاسا', file: 'mikasa.jpg' },
  { name: 'غوجو', file: 'gojo.jpg' }
];

module.exports = {
  command: 'أحزر',
  description: 'فعالية تخمين شخصية أنمي من صورة',
usage: '.احزر',
category: 'tools',
  async execute(sock, m, args) {
    const chatId = m.key.remoteJid;

    // اختيار شخصية عشوائية
    const random = characters[Math.floor(Math.random() * characters.length)];
    const imageBuffer = fs.readFileSync(path.join(imagesDir, random.file));

    // إرسال الصورة
    await sock.sendMessage(chatId, { image: imageBuffer, caption: "🧠 من هذه الشخصية؟" });

    // الإجابة الصحيحة
    const answer = random.name;

    // الانتظار للرد
    const filter = (msg) => msg.key.remoteJid === chatId;
    const timeout = 30000;

    const listener = async ({ messages }) => {
      const replyMsg = messages[0];
      const reply = replyMsg?.message?.conversation?.trim();
      if (!reply) return;

      if (reply.includes(answer)) {
        await sock.sendMessage(chatId, { text: `✅ صحيح! هذه شخصية ${answer}` });
      } else {
        await sock.sendMessage(chatId, { text: `❌ خطأ! الجواب الصحيح هو ${answer}` });
      }

      sock.ev.off('messages.upsert', listener); // إزالة المستمع بعد أول رد
    };

    sock.ev.on('messages.upsert', listener);

    // إزالة المستمع بعد المهلة
    setTimeout(() => sock.ev.off('messages.upsert', listener), timeout);
  }
};