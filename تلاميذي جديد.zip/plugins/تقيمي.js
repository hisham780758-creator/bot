const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, '../data/bot-ratings.json');
const devJid = '201028489465@s.whatsapp.net';

if (!fs.existsSync(file)) fs.writeFileSync(file, '[]');

module.exports = {
  command: "تقيمك",
  description: "🌟 قيّم البوت بإدخال (نجمه، نجمتين، ثلاث نجوم...)",
  usage: ".تقييم [نجمه / ثلاث نجوم ...]",
category: 'tools',

  async execute(sock, msg) {
    const from = msg.key.remoteJid;
    const sender = msg.participant || msg.key.participant || msg.key.remoteJid;
    const name = msg.pushName || "عضو";
    const args = msg.args.join(" ").toLowerCase().trim();

    const map = {
      "نجمه": 1, "نجمتين": 2, "نجمتان": 2,
      "ثلاث نجوم": 3, "٣ نجوم": 3, "ثلاثة نجوم": 3,
      "٤ نجوم": 4, "اربع نجوم": 4, "أربع نجوم": 4,
      "خمسه نجوم": 5, "خمسة نجوم": 5, "٥ نجوم": 5,
      "1": 1, "2": 2, "3": 3, "4": 4, "5": 5
    };

    const stars = map[args];
    if (!stars || stars < 1 || stars > 5) {
      return await sock.sendMessage(from, {
        text: "❗ اكتب تقييم مثل:\n`نجمه` - `نجمتين` - `ثلاث نجوم` - `٤ نجوم` - `خمسه نجوم`"
      }, { quoted: msg });
    }

    const starDisplay = "⭐".repeat(stars);

    // حفظ التقييم في ملف
    const list = JSON.parse(fs.readFileSync(file));
    list.push({
      name,
      rating: stars,
      from: sender,
      date: new Date().toLocaleString("ar-EG")
    });
    fs.writeFileSync(file, JSON.stringify(list, null, 2));

    // استخراج اسم الجروب لو الرسالة من جروب
    let groupName = '';
    if (from.endsWith('@g.us')) {
      try {
        const metadata = await sock.groupMetadata(from);
        groupName = metadata.subject || 'جروب غير معروف';
      } catch {
        groupName = 'جروب غير معروف';
      }
    }

    // رسالة للمستخدم
    await sock.sendMessage(from, {
      text: `✨ *تم تسجيل تقييمك:*\n${starDisplay}\n\nشكراً لتقييمك لـ BATMAN BOT 🦦`
    }, { quoted: msg });

    // رسالة للمطور
    await sock.sendMessage(devJid, {
      text: `🌟 *تقييم جديد من • ${name}*\n\n` +
            `📬 من: wa.me/${sender.split('@')[0]}\n` +
            (groupName ? `👥 الجروب: ${groupName}\n` : '') +
            `⭐ عدد النجوم: ${stars}`
    });
  }
};