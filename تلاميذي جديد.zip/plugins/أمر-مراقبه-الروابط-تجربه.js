const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const dataDir = path.join(__dirname, '..', 'data');
const filePath = path.join(dataDir, 'groupLinkLock.json');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify({}), 'utf8');

const loadLockData = () => {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (err) {
    console.error('❌ فشل في قراءة ملف منع الروابط:', err);
    return {};
  }
};

const saveLockData = (data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('❌ فشل في حفظ ملف منع الروابط:', err);
  }
};

const decode = (jid) => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

const warnings = {};
let linkHandlerAttached = false;

module.exports = {
  command: 'قفل_روابط',
  description: '🔒 تفعيل أو إلغاء مراقبة الروابط. الطرد بعد 3 تحذيرات.',
usage: '.أمر-مراقبه-الروابط-تجربه',
  category: 'إداري',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    const sender = decode(msg.key.participant || msg.key.remoteJid);

    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, { text: '❌ هذا الأمر خاص بالمجموعات فقط.' }, { quoted: msg });
    }

    if (!isElite(sender.split('@')[0])) {
      return sock.sendMessage(groupJid, { text: '🚫 هذا الأمر للنخبة فقط.' }, { quoted: msg });
    }

    const lockData = loadLockData();

    if (lockData[groupJid]) {
      delete lockData[groupJid];
      saveLockData(lockData);
      return sock.sendMessage(groupJid, { text: '✅ تم إلغاء قفل الروابط.' }, { quoted: msg });
    }

    lockData[groupJid] = true;
    saveLockData(lockData);

    await sock.sendMessage(groupJid, { text: '🔒 تم تفعيل منع الروابط في هذه المجموعة.' }, { quoted: msg });

    if (linkHandlerAttached) return;

    sock.ev.on('messages.upsert', async ({ messages }) => {
      const active = loadLockData();
      for (let m of messages) {
        if (!m.message || m.key.fromMe) continue;

        const group = m.key.remoteJid;
        if (!active[group]) continue;

        const sender = m.key.participant || group;
        const msgType = Object.keys(m.message || {})[0];
        if (msgType !== 'conversation' && msgType !== 'extendedTextMessage') continue;

        const text = m.message.conversation || m.message.extendedTextMessage?.text || '';
        const containsLink = /(https?:\/\/[^\s]+)/i.test(text);

        if (containsLink) {
          warnings[sender] = (warnings[sender] || 0) + 1;

          if (warnings[sender] < 3) {
            await sock.sendMessage(group, {
              text: `⚠️ ممنوع إرسال الروابط!\nتحذير ${warnings[sender]}/3`,
              mentions: [sender]
            });
          } else {
            await sock.groupParticipantsUpdate(group, [sender], 'remove');
            await sock.sendMessage(group, {
              text: `❌ تم طرد @${sender.split('@')[0]} بعد 3 تحذيرات بسبب إرسال روابط.`,
              mentions: [sender]
            });
            delete warnings[sender];
          }

          try {
            await sock.sendMessage(group, {
              delete: {
                remoteJid: group,
                fromMe: false,
                id: m.key.id,
                participant: sender
              }
            });
          } catch (err) {
            console.error('فشل في حذف الرسالة:', err.message);
          }
        }
      }
    });

    linkHandlerAttached = true;
  }
};