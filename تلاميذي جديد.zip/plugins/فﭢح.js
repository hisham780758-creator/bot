const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');
const fs = require('fs');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'open',
    description: 'فتح المجموعة والسماح للأعضاء بإرسال الرسائل',
    usage: '.فتح',
    category: 'special',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || groupJid);
            const senderLid = sender.split('@')[0];

            if (!groupJid.endsWith('@g.us'))
                return await sock.sendMessage(groupJid, { text: '❗ هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: msg });

            if (!eliteNumbers.includes(senderLid))
                return await sock.sendMessage(groupJid, { text: '❗ لا تملك صلاحية استخدام هذا الأمر.' }, { quoted: msg });

            // فتح القروب
            await sock.groupSettingUpdate(groupJid, 'not_announcement');

            // إرسال الرسالة أولاً
            await sock.sendMessage(groupJid, {
                text: '*تــم فَــتْــح الــقــروب بــنــجــاح ⁽🍷₎*'
            }, { quoted: msg });

            // إرسال الأغنية في رسالة منفصلة
            await sock.sendMessage(groupJid, {
                audio: fs.readFileSync('./media/open.mp3'),
                mimetype: 'audio/mpeg',
                ptt: false
            });

        } catch (error) {
            console.error('❌ خطأ في أمر فتح:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تنفيذ الأمر:\n\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};