const fs = require('fs');
const path = require('path');

const dbDir = path.join(__dirname, '..', 'db');
const dbFile = path.join(dbDir, 'marriages.json');

function loadMarriages() {
  try {
    return JSON.parse(fs.readFileSync(dbFile));
  } catch {
    return {};
  }
}

module.exports = {
  command: ['زوجاتي'],
  category: 'مرح',
  description: 'عرض قائمة الزوجات',
  usage: '.زوجاتي',

  async execute(sock, msg) {
    const sender = msg.sender || msg.key.participant || msg.key.remoteJid || '';
    const chatId = msg.key.remoteJid;

    const marriages = loadMarriages();

    const wives = marriages[sender] || [];

    if (wives.length === 0) {
      await sock.sendMessage(chatId, {
        text: '🙄 لا يوجد لديك زوجات حالياً.',
      }, { quoted: msg });
      return;
    }

    // تجهيز القائمة
    let wivesList = wives.map((wife, i) => `👰 الزوجة ${i + 1}: @${wife.split('@')[0]}`).join('\n');

    await sock.sendMessage(chatId, {
      text: `
💍 *قائمة زوجاتك* 💍

${wivesList}
      `,
      mentions: [sender, ...wives]
    }, { quoted: msg });
  }
};