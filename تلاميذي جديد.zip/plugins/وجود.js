const fs = require('fs');
const { join } = require('path');

module.exports = {
  command: "وجود",
  description: "يشغل أغنية من مجلد sounds مع صورة من media إن وُجدت.",
usage: '.وجود',
  category: "fun",
  async execute(sock, msg, args) {
    const groupJid = msg.key.remoteJid;

    if (!args[0]) {
      return sock.sendMessage(groupJid, {
        text: "🎵 اكتب اسم الأغنية بعد الأمر:\nمثال: .وجود ميغومي"
      }, { quoted: msg });
    }

    const songName = args.join(' ').trim();
    const audioPath = join(process.cwd(), 'sounds', `${songName}.mp3`);
    const imagePath = join(process.cwd(), 'media', `${songName}.jpg`); // 🔁 هنا التعديل الوحيد

    if (!fs.existsSync(audioPath)) {
      return sock.sendMessage(groupJid, {
        text: `❌ لم يتم العثور على الأغنية: *${songName}.mp3*`
      }, { quoted: msg });
    }

    try {
      const audioBuffer = fs.readFileSync(audioPath);

      if (fs.existsSync(imagePath)) {
        const imageBuffer = fs.readFileSync(imagePath);
        await sock.sendMessage(groupJid, {
          audio: audioBuffer,
          mimetype: 'audio/mpeg',
          ptt: false,
          contextInfo: {
            externalAdReply: {
              title: songName,
              body: "🎶 تشغيل بواسطة البوت",
              thumbnail: imageBuffer,
              mediaType: 2,
              showAdAttribution: false,
              sourceUrl: ""
            }
          }
        }, { quoted: msg });

      } else {
        await sock.sendMessage(groupJid, {
          audio: audioBuffer,
          mimetype: 'audio/mpeg',
          ptt: false
        }, { quoted: msg });
      }

    } catch (err) {
      console.error("❌ خطأ:", err);
      await sock.sendMessage(groupJid, {
        text: "⚠️ حصل خطأ أثناء إرسال الأغنية."
      }, { quoted: msg });
    }
  }
};