const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'ترحيب',
  description: '⌯︙يرحب بعضو جديد بترحيب محفّز مع منشن ولقب متعدد الكلمات وصورة بروفايل',
  category: 'fun',
  usage: '.ترحيب [اللقب] @العضو',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;

    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '❌ هذا الأمر يعمل فقط في القروبات.'
      }, { quoted: msg });
    }

    const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
    const args = body.trim().split(' ').slice(1);

    const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!mentionedJid || args.length < 2) {
      return sock.sendMessage(groupJid, {
        text: '❗ اكتـب اللقـب قـبـل المـنـشـن.\nمثال: `.ترحيب قائد الظلال @123456`'
      }, { quoted: msg });
    }

    const userTag = mentionedJid.split('@')[0];

    // استخراج اللقب (كل الكلمات قبل المنشن)
    const mentionIndex = args.findIndex(arg => arg.startsWith('@'));
    const titleParts = args.slice(0, mentionIndex);
    const title = titleParts.join(' ');

    const welcomeMsg = `
⚜️ نــرحــب بـكـل فــخــر بـانـضــمــامـك إلـيــنـا...

🔸 اللقب: 『 ${title} 』
🎖️ المنشن: @${userTag}

🛡️ أهـلًا وسـهـلًا بـك فـي نـقـابـتـنـا، حيـث الـولاء قـيـمـة، والتـضـحـيـة شـرف، والـرفـاق روحٌ واحـدة.

🔥 وجودك ليس مجرّد رقم، بل إضافة حقيقية لقوة النقابة وشرفٌ لنا أن تسير معنا في نفس الطريق.

🪻 نتـمـنـى لـك رحـلـة مـلـيئـة بـالإنـجـازات، والمـهـام المشـرفـة، والـنـجـاحـات التـي تـجـعـل اسمـك يُـذكـر بـفـخـر.

🤝 لا تتردد في التفاعل، المبادرة، وترك بصمتك المميزة، فالمكان مكانك... والرفاق إخوتك.

🎯 أهـلًا بـالـبـطـل الجـديـد... ولـنـصـنـع التـاريـخ سويـًـا!

📜 تابع الصحيفة الرسمية:
『 لا يوجد صحيفه مختاره من قبل المطور 』
`;

    // تحميل صورة البروفايل أو صورة افتراضية
    let imageBuffer;
    try {
      const profilePicUrl = await sock.profilePictureUrl(mentionedJid, 'image');
      const response = await axios.get(profilePicUrl, { responseType: 'arraybuffer' });
      imageBuffer = Buffer.from(response.data, 'binary');
    } catch (error) {
      const fallbackImage = path.join(__dirname, '../media/default.jpg');
      imageBuffer = fs.readFileSync(fallbackImage);
    }

    // إرسال الصورة مع الرسالة
    await sock.sendMessage(groupJid, {
      image: imageBuffer,
      caption: welcomeMsg,
      mentions: [mentionedJid]
    }, { quoted: msg });
  }
};