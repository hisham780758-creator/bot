const { isElite } = require('../haykala/elite');
module.exports = {
  command: ['قطتي'],
  description: 'امنشن أو اعمل ريبلاي لشخص وخليه يقول "مياو" قبل الطرد.',
usage: '.قطه',
  category: 'المجموعة',

  async execute(sock, msg, args) {
    const groupJid = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.participant || msg.key.remoteJid;

    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '❌ هذا الأمر يعمل فقط داخل المجموعات.',
      }, { quoted: msg });
    }

    const senderNumber = senderJid.split('@')[0];
    if (!isElite(senderNumber)) {
      return sock.sendMessage(groupJid, {
        text: '❌ هذا الأمر مخصص للنخبة فقط.',
      }, { quoted: msg });
    }

    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.participant;
    const target = mentioned[0] || quoted;

    if (!target) {
      return sock.sendMessage(groupJid, {
        text: '*امنشن أو رد على الشخص اللي عايزه يكون عبدك ااقصد قطتك 🫦.*',
      }, { quoted: msg });
    }

    const targetNumber = target.split('@')[0];
    const developerNumber = '201107287277@s.whatsapp.net';
    if (target === developerNumber) {
      return sock.sendMessage(groupJid, {
        text: '*❌ تحاول تطرد المطور؟ مستحيل يا قطتي 🫦*',
        mentions: [developerNumber],
      }, { quoted: msg });
    }

    let countdown = 30;
    let hasMeowed = false;

    const countdownMsg = await sock.sendMessage(groupJid, {
      text: ` @${targetNumber} قول "مياو" قبل ${countdown} ثانية وإلا سيتم طردك برا!`,
      mentions: [target],
    });

    const messageListener = async (newMsg) => {
      try {
        const message = newMsg.messages[0];
        if (!message || !message.message) return;

        const from = message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;

        if (from === groupJid && sender === target) {
          const body =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            '';

          if (body.trim().includes('مياو')) {
            hasMeowed = true;

            await sock.sendMessage(groupJid, {
              text: ` قطه مطيعه اسمع كلام سيدك شانكس المره الجايه... @${targetNumber}، تم العفو عنك .`,
              mentions: [target],
            });

            sock.ev.off('messages.upsert', messageListener);
          }
        }
      } catch (err) {
        console.error('خطأ أثناء المراقبة:', err);
      }
    };

    sock.ev.on('messages.upsert', messageListener);

    const interval = setInterval(async () => {
      if (hasMeowed) {
        clearInterval(interval);
        return;
      }

      countdown--;

      if (countdown > 0) {
        try {
          await sock.sendMessage(groupJid, {
            edit: countdownMsg.key,
            text: ` @${targetNumber} قول "مياو" قبل ${countdown} ثانية أو يتم طردك زي العبد بلا فائده 🫦🤙.`,
            mentions: [target],
          });
        } catch (err) {
          console.log('فشل تعديل العد التنازلي:', err);
        }
      } else {
        clearInterval(interval);
        sock.ev.off('messages.upsert', messageListener);

        if (!hasMeowed) {
          try {
            await sock.groupParticipantsUpdate(groupJid, [target], 'remove');
            await sock.sendMessage(groupJid, {
              text: `🚫 تم طرد @${targetNumber} لأنه رفض يكون قطة شانكس يستحق  اللي اخده 🫦🤙.`,
              mentions: [target],
            });
          } catch (err) {
            await sock.sendMessage(groupJid, {
              text: '❌ لم أتمكن من تنفيذ عملية الطرد. تأكد أنني مشرف.',
            });
          }
        }
      }
    }, 1000);
  },
};