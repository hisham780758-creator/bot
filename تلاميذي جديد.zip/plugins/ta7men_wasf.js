const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '..', 'data', 'points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
  try {
    return JSON.parse(fs.readFileSync(pointsFile));
  } catch {
    return {};
  }
}

function savePoints(points) {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const animeHints = [
  { hint: "فتى يمتلك وحشًا داخل جسده ويُقاتل ليصبح الهوكاجي", answer: "ناروتو" },
  { hint: "قرصان يرتدي قبعة قش، يسعى ليصبح ملك القراصنة", answer: "ون بيس" },
  { hint: "أناس يعيشون خلف جدران ضخمة لحماية أنفسهم من العمالقة", answer: "هجوم العمالقة" },
  { hint: "شاب عبقري يجد دفترًا يمكنه قتل أي شخص بكتابة اسمه", answer: "ديث نوت" },
  { hint: "فتى فقد والدته بسبب مخلوقات شيطانية، ينضم لفيلق خاص لقتلهم", answer: "قاتل الشياطين" },
];

module.exports = {
  command: 'تخمين_وصف',
  description: 'فعالية تخمين اسم أنمي من الوصف',
usage: '.ta7men_wasf',
  category: 'games',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هـذا الأمـر يعمـل فـقـط فـي القـروبات.*'
      }, { quoted: msg });
    }

    const selected = animeHints[Math.floor(Math.random() * animeHints.length)];
    const correctAnswer = selected.answer.toLowerCase();
    let isAnswered = false;

    const startMessage = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*⎔ ٠ ┈─ ━╼ • ◞📖◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔تـخـمـيـن الأنـمـي مـن الـوصـف〕※*\n\n` +
      `*┃╻🧠╹↵الـوصـف ↯*\n*⧉┋※〔 ${selected.hint} 〕※*\n\n` +
      `*┃╻⏳╹↵الـوقـت ↯*\n*⧉┋※〔 30 ثـانـيـة 〕※*\n*⎔ ٠ ┈─ ━╼ • ◞🎐◜ • ╾━ ─┈‏ ٠ ⎔*`;

    await sock.sendMessage(groupJid, { text: startMessage }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;

      const body = m.message?.conversation?.toLowerCase().trim();
      if (!body) return;

      if (body === correctAnswer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = loadPoints();

        pointsData[number] = (pointsData[number] || 0) + 10;
        savePoints(pointsData);

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*\n\n` +
`*تـم مـنحـه 10 نـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(() => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};