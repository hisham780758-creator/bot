const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'رحبب',
  description: '⌯︙يرحب بعضو جديد بترحيب محفّز مع منشن ولقب متعدد الكلمات وصورة بروفايل',
  category: 'fun',
  usage: '.ترحيب [اللقب] @العضو',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;

    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '❌ هذا الأمر يعمل فقط في القروبات.'
      }, { quoted: msg });
    }

    const body = msg.message?.extendedTextMessage?.text || msg.message?.conversation || '';
    const args = body.trim().split(' ').slice(1);

    const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (!mentionedJid || args.length < 2) {
      return sock.sendMessage(groupJid, {
        text: '❗ اكتـب اللقـب قـبـل المـنـشـن.\nمثال: `.ترحيب قائد الظلال @123456`'
      }, { quoted: msg });
    }

    const userTag = mentionedJid.split('@')[0];

    // استخراج اللقب (كل الكلمات قبل المنشن)
    const mentionIndex = args.findIndex(arg => arg.startsWith('@'));
    const titleParts = args.slice(0, mentionIndex);
    const title = titleParts.join(' ');

    const welcomeMsg = `
⚜️ نــرحــب بـكـل فــخــر بـانـضــمــامـك إلـيــنـا...

🔸 اللقب: 『 ${title} 』
🎖️ المنشن: @${userTag}
منور/ه يا مز/ه في جروبنا 
`;

    // تحميل صورة البروفايل أو صورة افتراضية
    let imageBuffer;
    try {
      const profilePicUrl = await sock.profilePictureUrl(mentionedJid, 'image');
      const response = await axios.get(profilePicUrl, { responseType: 'arraybuffer' });
      imageBuffer = Buffer.from(response.data, 'binary');
    } catch (error) {
      const fallbackImage = path.join(__dirname, '../media/default.jpg');
      imageBuffer = fs.readFileSync(fallbackImage);
    }

    // إرسال الصورة مع الرسالة
    await sock.sendMessage(groupJid, {
      image: imageBuffer,
      caption: welcomeMsg,
      mentions: [mentionedJid]
    }, { quoted: msg });
  }
};