const fs = require('fs');
const path = require('path');

const translationsPath = path.join(__dirname, '../data/translations.json');

let translations = {};
try {
  translations = JSON.parse(fs.readFileSync(translationsPath, 'utf8'));
} catch (error) {
  console.error('خطأ في تحميل ملف الترجمة:', error);
}

module.exports = {
  command: ['ترمجه', 'ترجمة'],
  description: 'ترجمة من الدارجة المغربية إلى العربية الفصحى',
usage: '.ترجمه',
category: 'tools',
  
  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;

    if (!args || args.length === 0) {
      return await sock.sendMessage(chatId, { text: '❌ اكتب الجملة باللهجة المغربية بعد الأمر.' }, { quoted: msg });
    }

    const input = args.join(' ');
    const words = input.split(' ');

    const translatedWords = words.map(word => {
      return translations[word.toLowerCase()] || word;
    });

    const translatedSentence = translatedWords.join(' ');

    await sock.sendMessage(chatId, { text: `🔄 الترجمة: ${translatedSentence}` }, { quoted: msg });
  }
};