const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
  try {
    return JSON.parse(fs.readFileSync(pointsFile));
  } catch {
    return {};
  }
}

function savePoints(points) {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const capitals = [
  { country: 'اليابان', capital: 'طوكيو' },
  { country: 'السعودية', capital: 'الرياض' },
  { country: 'مصر', capital: 'القاهرة' },
  { country: 'تركيا', capital: 'أنقرة' },
  { country: 'كوريا الجنوبية', capital: 'سيول' },
  { country: 'الجزائر', capital: 'الجزائر' },
  { country: 'المغرب', capital: 'الرباط' },
  { country: 'سوريا', capital: 'دمشق' },
  { country: 'الإمارات', capital: 'أبو ظبي' },
  { country: 'العراق', capital: 'بغداد' },
  { country: 'قطر', capital: 'الدوحة' },
  { country: 'الأردن', capital: 'عمّان' },
  { country: 'السودان', capital: 'الخرطوم' },
  { country: 'عمان', capital: 'مسقط' },
  { country: 'لبنان', capital: 'بيروت' },
  { country: 'البرازيل', capital: 'برازيليا' },
  { country: 'فرنسا', capital: 'باريس' },
  { country: 'ألمانيا', capital: 'برلين' },
  { country: 'الصين', capital: 'بكين' },
  { country: 'روسيا', capital: 'موسكو' },
  { country: 'الولايات المتحدة', capital: 'واشنطن' },
  { country: 'المملكة المتحدة', capital: 'لندن' },
  { country: 'الهند', capital: 'نيودلهي' },
  { country: 'إيطاليا', capital: 'روما' },
  { country: 'كندا', capital: 'أوتاوا' },
];

module.exports = {
  command: 'عاصمة',
  category: 'games',
  description: 'فعالية معرفة عاصمة الدولة',
usage: '.عاصمة',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبات.*'
      }, { quoted: msg });
    }

    const selected = capitals[Math.floor(Math.random() * capitals.length)];
    const country = selected.country;
    const answer = selected.capital.trim().toLowerCase();
    let isAnswered = false;

    const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔عـاصـمـة〕※*\n\n` +
      `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔سـيـتـم إعـطـاء اسـم دولـة، وعـليك مـعـرفـة عـاصـمـتـهـا〕※*\n\n` +
      `*┃╻🌍╹↵ الـدولـة ↯*\n*⧉┋※〔 ${country} 〕※*\n\n` +
      `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
      `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇 Ascanor ٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase()?.trim();
      if (!body) return;

      if (body === answer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = loadPoints();

        pointsData[number] = (pointsData[number] || 0) + 10;
        savePoints(pointsData);

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.capital} 」*\n\n` +
`*تـم مـنحـه الـنـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(async () => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        await sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.capital} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};