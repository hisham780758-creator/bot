const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');

const dataDir = path.join(__dirname, '..', 'data');
const goodbyeFile = path.join(dataDir, 'goodbyeState.json');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(goodbyeFile)) fs.writeFileSync(goodbyeFile, JSON.stringify({}));

const loadGoodbyeState = () => {
  try {
    return JSON.parse(fs.readFileSync(goodbyeFile));
  } catch (err) {
    console.error("خطأ في قراءة ملف الوداع:", err);
    return {};
  }
};

const saveGoodbyeState = (data) => {
  try {
    fs.writeFileSync(goodbyeFile, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error("خطأ في حفظ ملف الوداع:", err);
  }
};

let listenerAttached = false;

module.exports = {
  command: 'وداع',
  description: 'تشغيل / إيقاف رسائل الوداع التلقائية عند خروج الأعضاء أو طردهم (خاص بالنخبة)',
usage: '.وداع',
  category: 'نخبة',

  async execute(sock, m) {
    const groupId = m.key.remoteJid;
    const sender = m.key.participant || m.participant;

    if (!groupId.endsWith('@g.us')) {
      return sock.sendMessage(groupId, { text: '❌ هذا الأمر يعمل فقط داخل المجموعات.' }, { quoted: m });
    }

    if (!isElite(sender)) {
      return sock.sendMessage(groupId, { text: '🚫 هذا الأمر مخصص للنخبة فقط.' }, { quoted: m });
    }

    const state = loadGoodbyeState();

    if (state[groupId]) {
      delete state[groupId];
      saveGoodbyeState(state);
      return sock.sendMessage(groupId, { text: '⛔ تم إيقاف الوداع.' }, { quoted: m });
    }

    state[groupId] = true;
    saveGoodbyeState(state);
    sock.sendMessage(groupId, { text: '✅ تم تفعيل الوداع.' }, { quoted: m });

    if (listenerAttached) return;

    sock.ev.on('group-participants.update', async (update) => {
      const activeState = loadGoodbyeState();
      const isGoodbye = activeState[update.id];

      if (!isGoodbye || update.action !== 'remove') return;

      for (const participant of update.participants) {
        const number = participant.split('@')[0];

        // محاولة جلب صورة البروفايل
        let ppUrl = await sock.profilePictureUrl(participant, 'image').catch(() => null);
        if (!ppUrl) {
          ppUrl = await sock.profilePictureUrl(update.id, 'image').catch(() => null);
        }

        const goodbyeMsg = `
طززز @${number} 👋
تخرج يجي غيرك عشرة 😏
`;

        const media = ppUrl
          ? { image: { url: ppUrl }, caption: goodbyeMsg }
          : { text: goodbyeMsg };

        await sock.sendMessage(update.id, {
          ...media,
          mentions: [participant]
        });
      }
    });

    listenerAttached = true;
  }
};