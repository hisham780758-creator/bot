module.exports = {
  name: 'تجربة',
  command: ['تجربة'],
  category: 'tools',
  description: '⌯︙اختبار دعم القوائم والأزرار',
usage: '.testMenu',
  hidden: false,

  async execute(sock, msg) {
    try {
      // ====== تجربة القائمة (List Message) ======
      await sock.sendMessage(msg.key.remoteJid, {
        text: "🚀 رسالة تجربة (قائمة)",
        footer: "لو ظهرت لك قائمة تحت فهذا يعني أن القوائم شغالة ✅",
        title: "📌 قائمة تجريبية",
        buttonText: "اضغط هنا لعرض القائمة 👇",
        sections: [
          {
            title: "✨ قسم تجريبي",
            rows: [
              { title: "الخيار الأول", rowId: "اختيار1", description: "هذا مجرد خيار للتجربة" },
              { title: "الخيار الثاني", rowId: "اختيار2", description: "خيار ثاني للتجربة" },
              { title: "الخيار الثالث", rowId: "اختيار3", description: "خيار ثالث للتجربة" }
            ]
          }
        ]
      }, { quoted: msg });

      // ====== تجربة الأزرار (Buttons) ======
      await sock.sendMessage(msg.key.remoteJid, {
        text: "🚀 رسالة تجربة (أزرار)",
        footer: "لو ظهرت لك أزرار تحت فهذا يعني أن الأزرار شغالة ✅",
        buttons: [
          { buttonId: "btn1", buttonText: { displayText: "🌟 زر أول" }, type: 1 },
          { buttonId: "btn2", buttonText: { displayText: "🔥 زر ثاني" }, type: 1 },
          { buttonId: "btn3", buttonText: { displayText: "🍀 زر ثالث" }, type: 1 }
        ],
        headerType: 1
      }, { quoted: msg });

    } catch (e) {
      console.error("❌ خطأ بالتجربة:", e);
      await sock.sendMessage(msg.key.remoteJid, { text: "❌ صار خطأ، احتمال نسختك من Baileys ما تدعم القوائم/الأزرار." }, { quoted: msg });
    }
  }
};