const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'تحميل',
  description: 'تحميل فيديو أو صوت من يوتيوب، تيك توك، أو إنستغرام.',
  usage: '.تحميل فيديو [الرابط] أو .تحميل صوت [الرابط]',
  category: 'ذكاء',

  async execute(sock, msg, args) {
    // التوثيق الوهمي
    const fakeOfficial = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "120363025246999999@g.us",
        id: "BAE5F7C88C7D8A3D3F1A3A",
      },
      message: {
        videoMessage: {
          title: "𝑨 • S V2...",
          seconds: "99999",
          gifPlayback: true,
          caption: "بّےــوُت𝒂𝒔𝒄𝒂𖤍",
          jpegThumbnail: Buffer.alloc(0)
        }
      }
    };

    const chatId = msg.key.remoteJid;

    let commandText = msg.message?.extendedTextMessage?.text || '';
    if (commandText && commandText.startsWith('.تحميل')) {
      const commandParts = commandText.split(' ');
      if (commandParts.length < 3) {
        return await sock.sendMessage(chatId, {
          text: `⚠️ *| الصيغة غير صحيحة!*\n\n🎯 مثال:\n\`.تحميل فيديو https://youtube.com/xyz\``
        }, { quoted: fakeOfficial });
      }
      args = [commandParts[1].toLowerCase(), commandParts.slice(2).join(' ').trim()];
    }

    if (!args || args.length < 2) {
      return await sock.sendMessage(chatId, {
        text: `❌ *| الصيغة ناقصة!*\n\nاستخدم:\n\`.تحميل [فيديو|صوت] [الرابط]` 
      }, { quoted: fakeOfficial });
    }

    const [format, url] = [args[0].toLowerCase(), args[1].trim()];
    if (!url.startsWith('http')) {
      return await sock.sendMessage(chatId, {
        text: `❌ *| الرابط غير صالح!*\n\nأرسل رابط مباشر من يوتيوب أو إنستغرام أو تيك توك.`
      }, { quoted: fakeOfficial });
    }

    const timestamp = Date.now();
    const tempDir = './temp';
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const videoPath = path.join(tempDir, `${timestamp}.mp4`);
    const audioPath = path.join(tempDir, `${timestamp}.mp3`);

    await sock.sendMessage(chatId, {
      text: `⏳ *| جاري تحميل الملف...*\n━━━━━━━━━━━━━━\n🎬 النوع: *${format}*\n🔗 الرابط: ${url}`,
    }, { quoted: fakeOfficial });

    const cleanupFile = (filePath) => {
      if (fs.existsSync(filePath)) {
        fs.unlink(filePath, (err) => {
          if (err) console.error(`❌ فشل في حذف الملف ${filePath}:`, err.message);
        });
      }
    };

    const errorMsg = (type) => `❌ *| فشل تحميل ${type}!* \n\n📌 تأكد أن الرابط لا يحتاج تسجيل دخول.\n🔁 جرب إعادة المحاولة بعد تحديث yt-dlp.`;

    if (format === 'فيديو') {
      exec(`yt-dlp -f mp4 -o "${videoPath}" "${url}"`, async (errDownload) => {
        if (errDownload || !fs.existsSync(videoPath)) {
          console.error('[ERROR] تحميل الفيديو:', errDownload?.message);
          cleanupFile(videoPath);
          return await sock.sendMessage(chatId, {
            text: errorMsg('الفيديو'),
            contextInfo: {
              externalAdReply: {
                title: 'فشل تحميل الفيديو 🎥',
                body: 'ربما تحتاج تحديث yt-dlp',
                thumbnailUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
                sourceUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
                mediaType: 1,
                renderLargerThumbnail: true,
                showAdAttribution: true
              }
            }
          }, { quoted: fakeOfficial });
        }

        try {
          await sock.sendMessage(chatId, {
            video: { url: videoPath },
            caption: `🎥 *| تم تحميل الفيديو بنجاح!*\n\n🔗 المصدر: ${url}`,
          }, { quoted: fakeOfficial });
        } finally {
          cleanupFile(videoPath);
        }
      });
    } else if (format === 'صوت') {
      exec(`yt-dlp -x --audio-format mp3 -o "${audioPath}" "${url}"`, async (errDownload) => {
        if (errDownload || !fs.existsSync(audioPath)) {
          console.error('[ERROR] تحميل الصوت:', errDownload?.message);
          cleanupFile(audioPath);
          return await sock.sendMessage(chatId, {
            text: errorMsg('الصوت'),
            contextInfo: {
              externalAdReply: {
                title: 'فشل تحميل الصوت 🎵',
                body: 'قد يكون الرابط محمي أو غير مدعوم',
                thumbnailUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
                sourceUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
                mediaType: 1,
                renderLargerThumbnail: true,
                showAdAttribution: true
              }
            }
          }, { quoted: fakeOfficial });
        }

        try {
          await sock.sendMessage(chatId, {
            audio: { url: audioPath },
            mimetype: 'audio/mpeg',
          }, { quoted: fakeOfficial });
        } finally {
          cleanupFile(audioPath);
        }
      });
    } else {
      return await sock.sendMessage(chatId, {
        text: `❗ *| النوع غير معروف!*\nاختر بين: "فيديو" أو "صوت"`
      }, { quoted: fakeOfficial });
    }
  }
};