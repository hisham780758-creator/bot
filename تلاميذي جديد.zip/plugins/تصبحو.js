module.exports = {
    command: 'سلام',
description: 'وصف تصبحو',
usage: '.تصبحو',
category: 'tools',
    async execute(sock, m) {
        const chatId = m.key.remoteJid;

        await sock.sendMessage(chatId, { text: `تروح وتيجي بي السلامه ❤️‍🩹!` });
    }
};