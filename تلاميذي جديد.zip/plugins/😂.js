const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports = {
  command: "😂",
  description: "رد  على الضحكه ",
  usage: ".😂",
  category: "ترفيه",

  async execute(sock, msg) {
    try {
      let imageBuffer = null;

      try {
        const senderJid = msg.key.participant || msg.key.remoteJid;
        const pfpUrl = await sock.profilePictureUrl(senderJid, "image");
        if (pfpUrl) {
          const res = await axios.get(pfpUrl, { responseType: "arraybuffer" });
          imageBuffer = Buffer.from(res.data, "binary");
        }
      } catch (e) {
        // تجاهل الخطأ لو فشل جلب صورة البروفايل
      }

      if (!imageBuffer) {
        const fallbackPath = path.join(process.cwd(), "image.jpeg");
        if (fs.existsSync(fallbackPath)) {
          imageBuffer = fs.readFileSync(fallbackPath);
        }
      }

      const replies = [
        "دوم الضحكه ي حب🐦‍⬛💗",
        "تدوم الضحكه العسل دي يا عسل 😉",
        "تضحك علي ايه ضحكني معاك😂",
        "اخخخخ ي الضحكه الجميله دي بس الله بدومها🐤💗",
        "يويلي علي الضحكه ادوب انا ادوب😻",
        "دامت أن شاء الله حب الضحكه العسل دي🫦"
      ];

      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      await sock.sendMessage(msg.key.remoteJid, {
        text: randomReply,
        contextInfo: {
          externalAdReply: {
            title: "رد على 'الضحكه' 😂",
            body: "اوف الضحكه 😉دي",
            thumbnail: imageBuffer,
            mediaType: 1,
            sourceUrl: "https://t.me/Sanji_Bot_Channel",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر "احا":', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `حصل خطأ:\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};