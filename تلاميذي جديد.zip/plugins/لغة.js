module.exports = {
  command: 'لغة',
  description: 'يعرض اللغة الرسمية وراية أي دولة.',
usage: '.لغة',
  category: 'world',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    const fullText = msg.message?.conversation ||
                     msg.message?.extendedTextMessage?.text || '';

    const country = fullText.split(' ').slice(1).join(' ').trim();

    if (!country) {
      return sock.sendMessage(chatId, {
        text: '❗ يرجى كتابة اسم الدولة بعد الأمر.\nمثال: `.لغة اليابان`'
      }, { quoted: msg });
    }

    const countries = {
      "اليابان": { language: "اليابانية", flag: "🇯🇵" },
      "مصر": { language: "العربية", flag: "🇪🇬" },
      "السعودية": { language: "العربية", flag: "🇸🇦" },
      "فرنسا": { language: "الفرنسية", flag: "🇫🇷" },
      "ألمانيا": { language: "الألمانية", flag: "🇩🇪" },
      "إيطاليا": { language: "الإيطالية", flag: "🇮🇹" },
      "أمريكا": { language: "الإنجليزية", flag: "🇺🇸" },
      "روسيا": { language: "الروسية", flag: "🇷🇺" },
      "الصين": { language: "الصينية", flag: "🇨🇳" },
      "الهند": { language: "الهندية", flag: "🇮🇳" },
      "البرازيل": { language: "البرتغالية", flag: "🇧🇷" },
      "كوريا الجنوبية": { language: "الكورية", flag: "🇰🇷" },
      "تركيا": { language: "التركية", flag: "🇹🇷" },
      "إسبانيا": { language: "الإسبانية", flag: "🇪🇸" },
      "الأرجنتين": { language: "الإسبانية", flag: "🇦🇷" },
      "المغرب": { language: "العربية", flag: "🇲🇦" },
      "الجزائر": { language: "العربية", flag: "🇩🇿" },
      "العراق": { language: "العربية", flag: "🇮🇶" },
      "الأردن": { language: "العربية", flag: "🇯🇴" },
      "لبنان": { language: "العربية", flag: "🇱🇧" },
      "تونس": { language: "العربية", flag: "🇹🇳" },
      "فلسطين": { language: "العربية", flag: "🇵🇸" },
      "أفغانستان": { language: "البشتو / الدارية", flag: "🇦🇫" },
      "باكستان": { language: "الأردية", flag: "🇵🇰" },
      "أندونيسيا": { language: "الإندونيسية", flag: "🇮🇩" },
      "نيجيريا": { language: "الإنجليزية", flag: "🇳🇬" },
      "السويد": { language: "السويدية", flag: "🇸🇪" },
      "النرويج": { language: "النرويجية", flag: "🇳🇴" },
      "الدانمارك": { language: "الدانماركية", flag: "🇩🇰" },
      "هولندا": { language: "الهولندية", flag: "🇳🇱" },
      "كندا": { language: "الإنجليزية / الفرنسية", flag: "🇨🇦" },
    };

    const info = countries[country];

    if (!info) {
      return sock.sendMessage(chatId, {
        text: `❌ لم يتم العثور على معلومات الدولة: *${country}*`
      }, { quoted: msg });
    }

    const form = `*𝐶𝑂𝑀𝑀𝐴𝑁𝐷 𝑊𝑂𝑅𝐿𝐷 🌍*\n\n` +
                 `*┃╻🧧╹↵ ※إسـم الـدولـة※↶*\n*「 ${country} 」*\n\n` +
                 `*┃╻🪭╹↵ ※لغـتـهـم※↶*\n*「 ${info.language} 」*\n\n` +
                 `*┃╻📯╹↵ ※رايـتـهـم※↶*\n*「 ${info.flag} 」*\n\n` +
                 `> *˼‏❖˹↵ لـيلـة سـعـيـدة 🍷*`;

    await sock.sendMessage(chatId, { text: form }, { quoted: msg });
  }
};