const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// دالة لتحويل WebP إلى PNG
async function webp2png(webpBuffer) {
    // هنا تضمن دالة التحويل الفعلية
    // يمكنك استخدام مكتبة مثل sharp أو محول آخر
    return webpBuffer; // مؤقتاً نرجع نفس البافر
}

module.exports = {
    command: 'ملصق',
    description: 'تحويل الملصق إلى صورة',
    usage: '.ملصق',
    category: 'tools',

    async execute(sock, msg, args) {
        // التوثيق الوهمي
        const fakeOfficial = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "120363025246999999@g.us",
                id: "BAE5F7C88C7D8A3D3F1A3A",
            },
            message: {
                videoMessage: {
                    title: "𝑨 • S V2...",
                    seconds: "99999",
                    gifPlayback: true,
                    caption: "بّےــوُت𝒂𝒔𝒄𝒂𖤍",
                    jpegThumbnail: Buffer.alloc(0)
                }
            }
        };

        try {
            const notStickerMessage = `✳️ قم بالرد على ملصق بـ:\n\n *.ملصق*`;

            if (!msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                return await sock.sendMessage(msg.key.remoteJid, {
                    text: notStickerMessage
                }, { quoted: fakeOfficial });
            }

            const quotedMsg = msg.message.extendedTextMessage.contextInfo;
            const quotedMessage = quotedMsg.quotedMessage;

            if (!quotedMessage.stickerMessage) {
                return await sock.sendMessage(msg.key.remoteJid, {
                    text: notStickerMessage
                }, { quoted: fakeOfficial });
            }

            // تحميل الملصق
            const stream = await downloadContentFromMessage(
                { message: quotedMessage }, 
                'sticker'
            );
            
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // تحويل WebP إلى PNG
            const pngBuffer = await webp2png(buffer);

            // حفظ الصورة مؤقتاً
            const tempPath = path.join(__dirname, '../temp', `sticker_${Date.now()}.png`);
            fs.writeFileSync(tempPath, pngBuffer);

            // إرسال الصورة
            await sock.sendMessage(msg.key.remoteJid, {
                image: fs.readFileSync(tempPath),
                caption: '*⊏─๋︩︪─๋︩︪─๋︩︪─๋︩︪─═͜⊐❪🍬❫⊏═─๋︩︪─๋︩︪─๋︩︪─๋︩︪─๋︩︪─⊐*\n*｢🍨｣⇇تـم تـنـفـيـذ طـلـبـك*\n*⊏─๋︩︪─๋︩︪─๋︩︪─๋︩︪─═͜⊐❪🍬❫⊏═─๋︩︪─๋︩︪─๋︩︪─๋︩︪─๋︩︪─⊐*'
            }, { quoted: fakeOfficial });

            // حذف الملف المؤقت
            fs.unlinkSync(tempPath);

        } catch (error) {
            console.error('❌ Error in ملصق command:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ أثناء تحويل الملصق:\n${error.message}`
            }, { quoted: fakeOfficial });
        }
    }
};
