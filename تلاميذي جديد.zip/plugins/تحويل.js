const bank = require('../akatsuki/bank.js');

module.exports = {
  command: 'تحويل',
  description: 'تحويل نقاط لحساب آخر',
  usage: '.تحويل <اسم_الحساب> <عدد_النقاط>',
  category: 'الاقتصاد',

  async execute(sock, msg) {
    const id = msg.key.participant || msg.key.remoteJid;
    const account = bank.getAccount(id);

    const body = msg.message?.conversation ||
                 msg.message?.extendedTextMessage?.text || '';
    const args = body.trim().split(/\s+/).slice(1);

    if (!account) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ *| ليس لديك حساب بنكي*\n\nقم بإنشاء حساب باستخدام:\n\`.حساب اسمك\``
      }, { quoted: msg });
    }

    if (!args || args.length === 0) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `⚠️ *| الصيغة غير صحيحة!*\n\n🎯 مثال:\n\`.تحويل رامي 150\`\n\n💡 يمكنك ترك عدد النقاط وسيتم تحويل جميع رصيدك.`
      }, { quoted: msg });
    }

    const [targetName, amount] = args;
    const result = bank.transferPoints(id, targetName, amount);

    let text;
    switch (result) {
      case 'not_found':
        text = `❌ *| الحساب غير موجود!*\n\nتحقق من أن اسم الحساب صحيح، أو أن لديك حساب بنكي.`;
        break;
      case 'invalid_amount':
        text = `🚫 *| عدد النقاط غير صالح!*\n\n💡 تأكد من كتابة رقم صالح بعد اسم الحساب.`;
        break;
      case 'not_enough':
        text = `💸 *| لا تملك نقاط كافية!*\n\n💰 تأكد أن رصيدك يغطي المبلغ المراد تحويله.`;
        break;
      case true:
        text = `✅ *| تم التحويل بنجاح!*\n\n📤 تم إرسال النقاط إلى الحساب:\n「 *${targetName}* 」`;
        break;
      default:
        text = `⚠️ *| حدث خطأ أثناء تنفيذ التحويل.*\n\n🔁 حاول مرة أخرى لاحقًا.`;
    }

    await sock.sendMessage(msg.key.remoteJid, {
      text: `╭─━━━━━━❪💰❫━━━━━━─╮
*| نظام تحويل النقاط |*

${text}

╰─━━━━━━❪🏦❫━━━━━━─╯\n\u200E`,
      contextInfo: {
        externalAdReply: {
          title: 'تحويل بنكي عبر البوت 🏦',
          body: 'ارسل نقاطك لأي حساب بسهولة 💸',
          thumbnailUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
          sourceUrl: 'https://whatsapp.com/channel/0029VbAuG5h2ZjCvTamnRq1o',
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: true
        }
      }
    }, { quoted: msg });
  }
};