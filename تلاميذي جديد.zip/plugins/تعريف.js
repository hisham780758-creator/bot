const countries = {
  "مصر": "مصر هي دولة عربية تقع في شمال أفريقيا، وتشتهر بأهرامات الجيزة ونهر النيل.",
  "اليابان": "اليابان دولة تقع في شرق آسيا، تشتهر بثقافتها الفريدة وتقدمها التكنولوجي.",
  // أضف المزيد
};

module.exports = {
  command: 'تعريف',
  category: 'world',
  description: 'يعطيك تعريفًا عن الدولة',
usage: '.تعريف',

  async execute(sock, msg) {
    const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
    const parts = body.trim().split(/\s+/);
    const input = parts.slice(1).join(' ').toLowerCase();

    if (!input) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: '❗ يرجى كتابة اسم الدولة بعد الأمر.\nمثال: `.تعريف اليابان`'
      }, { quoted: msg });
    }

    const country = Object.keys(countries).find(name => name.toLowerCase() === input);

    if (!country) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ لم يتم العثور على تعريف للدولة: *${input}*`
      }, { quoted: msg });
    }

    const info = countries[country];

    const response = `*𝐶𝑂𝑀𝑀𝐴𝑁𝐷 𝑊𝑂𝑅𝐿𝐷 🌍*\n\n` +
      `*┃╻🌎╹↵ ※إسـم الـدولـة※↶*\n*「${country}」*\n\n` +
      `*┃╻📖╹↵ ※الـتـعـريـف※↶*\n*「${info}」*\n\n` +
      `> *˼‏❖˹↵ لـيلـة سـعـيـدة 🍷*`;

    await sock.sendMessage(msg.key.remoteJid, { text: response }, { quoted: msg });
  }
};