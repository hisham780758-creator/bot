const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { jidNormalizedUser } = require('@whiskeysockets/baileys'); // لو تحتاج لتطبيع الجيد

module.exports = {
  command: "دزو",
  description: "رد ساخر على كلمة دز مع تفاعل ومنشن",
  usage: ".دز",
  category: "general",

  async execute(sock, msg) {
    try {
      // جلب معرف الدردش أو الجروب
      const chatId = msg.key.remoteJid;
      // جلب المرسل (participant أو remoteJid)
      const senderJidRaw = msg.key.participant || msg.key.remoteJid;
      const senderJid = jidNormalizedUser(senderJidRaw); // لضمان تطبيع الجيد

      // جلب صورة البروفايل إن وجدت
      let imageBuffer = null;
      try {
        const pfpUrl = await sock.profilePictureUrl(senderJid, "image");
        if (pfpUrl) {
          const res = await axios.get(pfpUrl, { responseType: "arraybuffer" });
          imageBuffer = Buffer.from(res.data, "binary");
        }
      } catch (e) {
        // تجاهل لو فشل جلب الصورة
      }

      // fallback لو ما في صورة بروفايل
      if (!imageBuffer) {
        const fallbackPath = path.join(process.cwd(), "image.jpeg");
        if (fs.existsSync(fallbackPath)) {
          imageBuffer = fs.readFileSync(fallbackPath);
        }
      }

      // ردود جاهزة
      const replies = [
        "متدز انت يـ عم! ولا عشان أنا عمّك؟ 😒",
        "َدز دز وخلاص؟ متدز بعيد عننا كده 💨",
        "هَش انت يـ عم، اتكلم مصري وقول هش🗿",
        "َدز على راسك! فاكر نفسك فوق القانون؟ 🤨",
        "دَز؟ دز على باب بيتكو بالمرة 🧹",
        "شكلك فاضي يا عم، روح بقى نام  😴",
        "َدز إيه؟ دز نفسك و نام بدري لأن العيال الصغيره تنام بدري🐦‍⬛🤙",
        "دَز؟ دز انت ي عن و العب بعيد عن عمك 😉"
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      // أولاً: أرسل رد فعل (تفاعل) على الرسالة بإيموجي 🤨
      await sock.sendMessage(chatId, {
        react: {
          text: "🤨",
          key: msg.key
        }
      });

      // ثانياً: أرسل رد مع المنشن
      await sock.sendMessage(chatId, {
        text: `@${senderJid.split('@')[0]}، ${randomReply}`,
        mentions: [senderJid],
        contextInfo: {
          externalAdReply: {
            title: "رد على 'دز' 🤖",
            body: "إهدى كده ي ريس ✋",
            thumbnail: imageBuffer,
            mediaType: 1,
            sourceUrl: "https://t.me/KINGSLO1",
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ خطأ في أمر "دز":', error);
      await sock.sendMessage(msg.key.remoteJid, {
        text: `حصل خطأ:\n${error.message || error.toString()}`
      }, { quoted: msg });
    }
  }
};