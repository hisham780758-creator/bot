
... 
const { jidDecode } = require('@whiskeysockets/baileys');
const { isElite } = require('../haykala/elite.js');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    command: 'حذف',
    description: 'حذف رسالة معينة في المجموعة (للنخبة فقط)',
    usage: '.حذف (بالرد على الرسالة)',
    category: 'tools',

    async execute(sock, msg) {
        // التوثيق الوهمي بـ ASCA
        const fakeOfficial = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "120363025246999999@g.us",
                id: "BAE5F7C88C7D8A3D3F1A3A",
            },
            message: {
                videoMessage: {
                    title: "𝑨 • S V2...",
                    seconds: "99999",
                    gifPlayback: true,
                    caption: "بّےــوُت𝒂𝒔𝒄𝒂𖤍",
                    jpegThumbnail: Buffer.alloc(0)
                }
            }
        };

        const chatId = msg.key.remoteJid;
        const sender = decode(msg.key.participant || chatId);
        const senderLid = sender.split('@')[0];

        // رد تفاعل 🛸 أولاً
        await sock.sendMessage(chatId, {
            react: { text: "🛸", key: msg.key }
        });

        // التحقق من النخبة فقط (بدون شرط المشرف)
        if (!isElite(senderLid)) {
            await sock.sendMessage(chatId, {
                react: { text: "❌", key: msg.key }
            });
            
            return await sock.sendMessage(chatId, {
                text: '❌ *لا تملك صلاحية استخدام هذا الأمر.*\n\nهذا الأمر مخصص للنخبة فقط.'
            }, { quoted: fakeOfficial });
        }

        // التحقق من أن الأمر في مجموعة
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, {
                react: { text: "❌", key: msg.key }
            });
            
            return await sock.sendMessage(chatId, {
                text: '❌ هذا الأمر يعمل فقط داخل المجموعات.'
            }, { quoted: fakeOfficial });
        }

        // التحقق من وجود رد
        const quoted = msg.message?.extendedTextMessage?.contextInfo;
        if (!quoted || !quoted.stanzaId || !quoted.participant) {
            return await sock.sendMessage(chatId, {
                text: '❌ *رد على رسالة* لحذفها.\n\nاستخدم: `.حذف` (بالرد على الرسالة المطلوبة)'
            }, { quoted: fakeOfficial });
        }

        try {
            // التحقق من أن البوت مشرف فقط
            const groupMetadata = await sock.groupMetadata(chatId);
            const botParticipant = groupMetadata.participants.find(p => p.id === decode(sock.user.id));
            const isBotAdmin = botParticipant && (botParticipant.admin === 'admin' || botParticipant.admin === 'superadmin');
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, {
                    react: { text: "❌", key: msg.key }
                });
                
                return await sock.sendMessage(chatId, {
                    text: '❌ *أنا لست مشرفاً في المجموعة.*\n\nيجب أن أكون مشرفاً لحذف رسائل الآخرين.\n\n🔧 *الحل:* ارفعني مشرف في المجموعة.'
                }, { quoted: fakeOfficial });
            }

            // حذف رسالة الرد (المقتبسة)
            await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: quoted.participant === decode(sock.user.id),
                    id: quoted.stanzaId,
                    participant: quoted.participant
                }
            });

            // حذف رسالة الأمر نفسه
            await sock.sendMessage(chatId, {
                delete: {
                    remoteJid: chatId,
                    fromMe: msg.key.fromMe,
                    id: msg.key.id,
                    participant: msg.key.participant || chatId
                }
            });

            // تأكيد نجاح (رسالة مؤقتة تختفي بعد 3 ثواني)
            const successMsg = await sock.sendMessage(chatId, {
                text: '✅ *تم حذف الرسالة بنجاح.*'
            }, { quoted: fakeOfficial });

            // حذف رسالة التأكيد بعد 3 ثواني
            setTimeout(async () => {
                try {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: true,
                            id: successMsg.key.id
                        }
                    });
                } catch (e) {
                    console.log('⚠️ فشل حذف رسالة التأكيد:', e.message);
                }
            }, 3000);

        } catch (err) {
            console.error('❌ فشل حذف الرسالة:', err);
            
            // علامة X حمراء عند الخطأ
            await sock.sendMessage(chatId, {
                react: { text: "❌", key: msg.key }
            });
            
            let errorMsg = '❌ *فشل حذف الرسالة.*';
            
            if (err.message.includes('not authorized') || err.message.includes('not an admin')) {
                errorMsg = '❌ *فشل حذف الرسالة.*\n\n⚠️ *أنا لست مشرفاً في المجموعة.*\n\n🔧 *الحل:* ارفعني مشرف في المجموعة.';
            } else if (err.message.includes('Message not found')) {
                errorMsg = '❌ *فشل حذف الرسالة.*\n\n⚠️ *الرسالة غير موجودة أو منتهية الصلاحية.*';
            } else if (err.message.includes('message to delete not found')) {
                errorMsg = '❌ *فشل حذف الرسالة.*\n\n⚠️ *الرسالة منتهية الصلاحية للحذف (أقدم من 60 دقيقة).*';
            } else {
                errorMsg += `\n\n${err.message}`;
            }
            
            await sock.sendMessage(chatId, {
                text: errorMsg
            }, { quoted: fakeOfficial });
        }
    }
};