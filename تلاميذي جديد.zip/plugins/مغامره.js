const fs = require('fs');
const path = require('path');

global.adventureSessions = global.adventureSessions || {};

module.exports = {
  command: 'مغامرة',
  category: 'ألعاب',
  usage: '.مغامرة',
  description: 'لعبة مغامرة تفاعلية تبدأ باختيار باب للهروب 🧠',

  async execute(sock, msg, args) {
    const from = msg.chat;
    const sender = msg.sender;
    const body = msg.body?.trim();

    // لو فيه جلسة قائمة (يعني المستخدم بيرد مش بيبدأ)
    if (global.adventureSessions[sender]?.step === 'level1' && global.adventureSessions[sender].chat === from) {
      delete global.adventureSessions[sender];

      if (!['1', '2', '3'].includes(body)) {
        return await sock.sendMessage(from, { text: '❌ اكتب رقم صحيح من 1 إلى 3 فقط.' });
      }

      if (body === '1') {
        return await sock.sendMessage(from, { text: '☠️ دخلت على وحش مفترس وانتهت حياتك.\n🔁 اكتب `.مغامرة` تبدأ من جديد.' });
      }

      if (body === '2') {
        return await sock.sendMessage(from, { text: '🌊 دخلت على نفق مائي وركبت قارب.\n🚣‍♂️ *أحسنت! انتقلت للمستوى الثاني.*\n\n(انتظر التحديث القادم 🧠)' });
      }

      if (body === '3') {
        return await sock.sendMessage(from, { text: '🔑 لقيت مفتاح ذهبي داخل صندوق مخفي!\n🧠 ممكن يفيدك في مستوى قادم.\n\n(انتظر التحديث القادم 🗺️)' });
      }
    }

    // لو مفيش جلسة: ابدأ اللعبة
    global.adventureSessions[sender] = {
      step: 'level1',
      chat: from,
    };

    // تحميل الصورة
    const imgPath = path.join(__dirname, '../resources/room_doors.jpg');
    let imgBuffer;

    try {
      imgBuffer = fs.readFileSync(imgPath);
    } catch (e) {
      return sock.sendMessage(from, { text: '❌ الصورة room_doors.jpg غير موجودة في resources' });
    }

    await sock.sendMessage(from, {
      image: imgBuffer,
      caption: `🎮 *مغامرة الهروب - المستوى الأول*\n\nتستيقظ في غرفة مظلمة وتجد أمامك ثلاث أبواب:\n\n🚪 1. باب أحمر مكتوب عليه "خطر"\n🚪 2. باب أزرق في صوت موية وراه\n🚪 3. باب خشب قديم فيه شق نور\n\n🗝️ *اكتب رقم الباب اللي هتدخله (1 / 2 / 3)*`
    });
  }
};