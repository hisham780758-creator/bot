const fs = require('fs');

module.exports = {
  command: 'سرقة_قروب',
  description: 'يسرق صورة القروب ويرسلها كصورة',
usage: '.قروب',
  category: 'tools',

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid;

    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, {
        text: '❌ هذا الأمر يعمل فقط داخل القروبات.'
      }, { quoted: msg });
    }

    try {
      const metadata = await sock.groupMetadata(chatId);
      const groupName = metadata.subject || 'قروب';

      let profilePicUrl;
      try {
        profilePicUrl = await sock.profilePictureUrl(chatId, 'image');
      } catch {
        profilePicUrl = 'https://i.ibb.co/7JQrJJx/avatar-contact.png'; // صورة بديلة إذا ما في بروفايل
      }

      await sock.sendMessage(chatId, {
        react: { text: '🖼️', key: msg.key }
      });

      await sock.sendMessage(chatId, {
        image: { url: profilePicUrl },
        caption: `*📸 تـم سـرقـة صـورة القـروب 「${groupName}」 بنجاح!*`
      }, { quoted: msg });

    } catch (err) {
      console.error('خطأ في أمر سرقة_قروب:', err);
      await sock.sendMessage(chatId, {
        text: '⚠️ حدث خطأ أثناء محاولة جلب صورة القروب.'
      }, { quoted: msg });
    }
  }
};