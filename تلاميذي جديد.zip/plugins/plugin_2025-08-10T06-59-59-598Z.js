const fs = require('fs');
const { join } = require('path');
const { eliteNumbers } = require('../haykala/elite.js');
const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';
const configPath = join(process.cwd(), 'reaction_toggle.json');

// قائمة الريأكشنات
const reactions = [
  '❤️', '😂', '🔥', '😎', '🥶', '💯', '👍', '👀', '😈', '🧸', '🇲🇦', '✨', '👏',
  '😎', '😮‍💨', '🇪🇬', '🧠', '👻', '💀', '☠️', '🔱', '🌝', '🤖', '🙃', '🇵🇸',
  '😵‍💫', '🤓', '🇱🇾', '😸', '😼', '🤡', '🥱', '🫦', '🍷', '❄', '👄', '👁️‍🗨️'
];

if (!fs.existsSync(configPath)) {
    fs.writeFileSync(configPath, JSON.stringify({ status: false }));
}

module.exports = {
    command: 'رياكت',
    description: 'تشغيل أو إيقاف الريأكشن التلقائي على رسائل النخبة',
    usage: '.رياكت',
    category: 'DEVELOPER',

    async execute(sock, msg) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || msg.key.remoteJid);
            const senderLid = sender.split('@')[0];

            if (!eliteNumbers.includes(senderLid)) {
                return await sock.sendMessage(groupJid, {
                    text: '❗ هذا الأمر مخصص فقط للنخبة.'
                }, { quoted: msg });
            }

            // تبديل الحالة
            const config = JSON.parse(fs.readFileSync(configPath));
            config.status = !config.status;
            fs.writeFileSync(configPath, JSON.stringify(config));

            await sock.sendMessage(groupJid, {
                text: `✅ تم ${config.status ? 'تشغيل' : 'إيقاف'} الريأكشن التلقائي على رسائل النخبة.`
            }, { quoted: msg });

            // إذا تم التفعيل، ابدأ المراقبة المباشرة دون الحاجة للهندلر
            if (config.status) {
                sock.ev.on('messages.upsert', async ({ messages }) => {
                    const m = messages[0];
                    if (!m.message || !m.key || !m.key.remoteJid.endsWith('@g.us')) return;

                    const sender = decode(m.key.participant || m.key.remoteJid);
                    const senderLid = sender.split('@')[0];

                    // تحقق أن الريأكشن مفعّل كل مرة (لمنع الريأكشن بعد الإيقاف)
                    const confCheck = JSON.parse(fs.readFileSync(configPath));
                    if (!confCheck.status) return;
                    if (!eliteNumbers.includes(senderLid)) return;

                    const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];

                    await sock.sendMessage(m.key.remoteJid, {
                        react: {
                            text: randomReaction,
                            key: m.key
                        }
                    }).catch(() => {});
                });
            }

        } catch (err) {
            console.error('❌ خطأ في أمر ريكت:', err);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ حدث خطأ:\n\n${err.message || err.toString()}`
            }, { quoted: msg });
        }
    }
};