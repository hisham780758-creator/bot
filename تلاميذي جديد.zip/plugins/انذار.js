const fs = require('fs');
const path = require('path');

const WARNINGS_FILE = path.join(__dirname, '../data/warnings.json');

function loadWarnings() {
  if (!fs.existsSync(WARNINGS_FILE)) {
    fs.writeFileSync(WARNINGS_FILE, JSON.stringify({}));
  }
  return JSON.parse(fs.readFileSync(WARNINGS_FILE));
}

function saveWarnings(data) {
  fs.writeFileSync(WARNINGS_FILE, JSON.stringify(data, null, 2));
}

module.exports = {
  command: 'انذار',
  category: 'admin',
  description: 'إعطاء إنذار لأحد أعضاء المجموعة (للمشرفين فقط).',
  usage: '.انذار',

  async execute(sock, msg, args = []) {
    // التوثيق الوهمي
    const fakeOfficial = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "120363025246999999@g.us",
        id: "BAE5F7C88C7D8A3D3F1A3A",
      },
      message: {
        videoMessage: {
          title: "𝑨 • S V2...",
          seconds: "99999",
          gifPlayback: true,
          caption: "بّےــوُت𝒂𝒔𝒄𝒂𖤍",
          jpegThumbnail: Buffer.alloc(0)
        }
      }
    };

    const chatId = msg.key.remoteJid;

    await sock.sendMessage(chatId, {
      react: {
        text: "✒️",
        key: msg.key
      }
    });

    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ هذا الأمر يعمل فقط في المجموعات.' }, { quoted: fakeOfficial });
    }

    let groupMetadata;
    try {
      groupMetadata = await sock.groupMetadata(chatId);
    } catch (e) {
      return sock.sendMessage(chatId, { text: '❌ لم أتمكن من جلب بيانات المجموعة.' }, { quoted: fakeOfficial });
    }

    const sender = msg.key.participant || msg.participant || msg.key.remoteJid;

    const senderObj = groupMetadata.participants.find(p => p.id === sender);
    if (!senderObj || (senderObj.admin !== 'admin' && senderObj.admin !== 'superadmin')) {
      return sock.sendMessage(chatId, { text: '❌ يجب أن تكون مشرفًا لتنفيذ هذا الأمر.' }, { quoted: fakeOfficial });
    }

    // استخراج السبب من بين / / أو "بدون سبب"
    const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
    const reasonMatch = text.match(/\/(.*?)\//);
    const reason = (reasonMatch && reasonMatch[1].trim()) ? reasonMatch[1].trim() : 'بدون سبب';

    // تحديد الهدف (منشن أو رد)
    let target;
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
    const contextParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

    if (mentioned?.length > 0) {
      target = mentioned[0];
    } else if (contextParticipant) {
      target = contextParticipant;
    } else {
      return sock.sendMessage(chatId, { text: '❌ يجب منشن العضو أو الرد عليه.' }, { quoted: fakeOfficial });
    }

    const targetObj = groupMetadata.participants.find(p => p.id === target);
    if (!targetObj) {
      return sock.sendMessage(chatId, { text: '❌ العضو غير موجود في المجموعة.' }, { quoted: fakeOfficial });
    }

    if (targetObj.admin === 'admin' || targetObj.admin === 'superadmin') {
      return sock.sendMessage(chatId, { text: '❌ لا يمكنك إعطاء إنذار للمشرفين أو المسؤولين.' }, { quoted: fakeOfficial });
    }

    let warnings = loadWarnings();
    if (!warnings[chatId]) warnings[chatId] = {};
    if (!warnings[chatId][target]) warnings[chatId][target] = 0;

    warnings[chatId][target]++;
    saveWarnings(warnings);

    const count = warnings[chatId][target];

    const warnMsg = `⚠️ تم إعطائك إنذارًا\n📌 السبب: ${reason}\n⚠️ عدد الإنذارات: ${count} / 3`;

    await sock.sendMessage(chatId, {
      text: warnMsg,
      mentions: [target]
    }, { quoted: fakeOfficial });

    if (count >= 3) {
      await sock.sendMessage(chatId, {
        text: `🚫 تم طرد @${target.split('@')[0]} بسبب تجاوز 3 إنذارات.`,
        mentions: [target]
      }, { quoted: fakeOfficial });

      try {
        await sock.groupParticipantsUpdate(chatId, [target], 'remove');
        warnings[chatId][target] = 0;
        saveWarnings(warnings);
      } catch (err) {
        await sock.sendMessage(chatId, { text: `❌ فشل طرد العضو: ${err.message}` }, { quoted: fakeOfficial });
      }
    }
  }
};