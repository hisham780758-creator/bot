const axios = require('axios');

module.exports = {
  command: 'اخبار_الانمي',
  description: 'أخبار الأنمي',
  usage: '.اخبار_الانمي',
  category: 'anime',
  async execute(sock, msg) {
    try {
      const response = await axios.get('https:                                                                                                   
      const news = response.data;
      const newsList = news.map(item => `*${item.title}*\n${item.description}\n${item.link}`).join('//api.example.com/anime-news'); // استبدل الرابط برابط API أخبار الأنمي
      const news = response.data;
      const newsList = news.map(item => `*${item.title}*\n${item.description}\n${item.link}`).join('\n\n');
      await sock.sendMessage(msg.key.remoteJid, { text: `*أخبار الأنمي:*\n\n${newsList}` }, { quoted: msg });
    } catch (error) {
      console.error('❌ Error executing اخبار_الانمي:', error);
      await sock.sendMessage(msg.key.remoteJid, { text: `*حدث خطأ أثناء جلب الأخبار*` }, { quoted: msg });
    }
  }
};