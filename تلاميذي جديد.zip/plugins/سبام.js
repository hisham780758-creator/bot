module.exports = {
    command: "سباممم",
    description: "منشن كل أعضاء الجروب بعدد محدد",
    usage: ".سباممنشن <عدد>",
    category: "tools",

    async execute(sock, msg, args) {
        try {
            const groupJid = msg.key.remoteJid;
            const count = parseInt(args[0]) || 1;

            if (!msg.key.fromMe && !msg.key.participant) {
                return sock.sendMessage(groupJid, { text: "هذا الأمر للجروبات فقط!" });
            }

            if (count > 20) return sock.sendMessage(groupJid, { text: "الحد الأقصى للسبام 20 مرة ⚠️" });

            // جلب معلومات الجروب
            const metadata = await sock.groupMetadata(groupJid);
            const participants = metadata.participants.map(p => p.id);

            for (let i = 0; i < count; i++) {
                await sock.sendMessage(groupJid, {
                    text: `منشن جماعي للجميع! (${i+1})`,
                    mentions: participants
                });
                await new Promise(r => setTimeout(r, 2000)); // تأخير 2 ثانية
            }

        } catch (error) {
            console.log("خطأ:", error);
            await sock.sendMessage(msg.key.remoteJid, { text: "حدث خطأ أثناء تنفيذ الأمر 😅" });
        }
    }
};