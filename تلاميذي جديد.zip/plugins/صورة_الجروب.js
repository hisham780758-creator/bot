const fs = require('fs');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { isElite } = require('../haykala/elite.js');

module.exports = {
    command: 'تغير_صورة',
    description: 'تغيير صورة الجروب (خاص بالنخبة)',
    usage: '.تغير_صورة (أرسل صورة أو رد على صورة)',
    category: 'special',

    async execute(sock, msg) {
        const chatId = msg.key.remoteJid;
        const senderJid = msg.key.participant || msg.key.remoteJid;
        const senderNumber = senderJid.split('@')[0];

        // 🎀 تفاعل على الرسالة
        await sock.sendMessage(chatId, {
            react: {
                text: "🎀",
                key: msg.key
            }
        });

        // صلاحية النخبة
        if (!isElite(senderNumber)) {
            return await sock.sendMessage(chatId, {
                text: '❌ هذا الأمر متاح فقط لأعضاء النخبة!'
            }, { quoted: msg });
        }

        // جلب صورة مرسلة أو مقتبسة
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const imageMessage = quoted?.imageMessage || msg.message?.imageMessage;

        if (!imageMessage) {
            return await sock.sendMessage(chatId, {
                text: '❌ أرسل صورة أو رد على صورة لاستخدامها كصورة جديدة للجروب.'
            }, { quoted: msg });
        }

        try {
            // تحميل الصورة
            const imageBuffer = await downloadMediaMessage(
                {
                    message: { imageMessage },
                    key: msg.key
                },
                'buffer',
                {},
                { logger: console, reuploadRequest: sock.updateMediaMessage }
            );

            // تغيير صورة الجروب
            await sock.updateProfilePicture(chatId, imageBuffer);

            await sock.sendMessage(chatId, {
                text: '✅ تم تغيير صورة المجموعة بنجاح.'
            }, { quoted: msg });

        } catch (error) {
            console.error('❌ خطأ أثناء تغيير صورة المجموعة:', error);
            await sock.sendMessage(chatId, {
                text: '❌ فشل تغيير صورة المجموعة. تأكد أني أدمن وأن الصورة مدعومة.'
            }, { quoted: msg });
        }
    }
};