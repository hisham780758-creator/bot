h
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

const tempDir = '/storage/emulated/0/.bot3/tmp';
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

module.exports = {
  command: ['ايدت'],
  category: 'tools',
  description: 'تحميل إيدت (فيديو قصير) من يوتيوب حسب كلمة مفتاحية أو رابط',
usage: '.ايدت',
  status: 'on',
  hidden: false,
  version: '1.0',

  async execute(sock, msg) {
    try {
      const messageText = (
        msg.message?.conversation ||
        msg.message?.extendedTextMessage?.text ||
        msg.message?.imageMessage?.caption ||
        msg.message?.videoMessage?.caption ||
        ''
      ).trim();

      let query = messageText.replace(/^[.,،]?(ايدت)\s*/i, '').trim();

      if (!query) {
        return await sock.sendMessage(msg.key.remoteJid, {
          text: "❌ من فضلك أرسل كلمة للبحث أو رابط يوتيوب بعد الأمر.\nمثال:\n.ايدت ناروتو\nأو\n.ايدت https://youtube.com/..."
        }, { quoted: msg });
      }

      await sock.sendMessage(msg.key.remoteJid, {
        text: '🎬 جاري البحث عن الإيدت وتحميل الفيديو...'
      }, { quoted: msg });

      // 1. نجيب رابط الفيديو
      exec(`yt-dlp "ytsearch1:${query}" --print "%(webpage_url)s"`, (err, stdout, stderr) => {
        if (err || !stdout) {
          console.error('yt-dlp search error:', stderr);
          return sock.sendMessage(msg.key.remoteJid, {
            text: `❌ لم يتم العثور على نتيجة لكلمة: *${query}*`
          }, { quoted: msg });
        }

        const videoUrl = stdout.trim();

        // 2. نحمل الفيديو
        const outputTemplate = path.join(tempDir, 'video.%(ext)s');
        const ytCommand = `yt-dlp -f "mp4[height<=720]" -o "${outputTemplate}" "${videoUrl}"`;

        exec(ytCommand, async (error, stdout2, stderr2) => {
          if (error) {
            console.error('yt-dlp download error:', stderr2);
            return await sock.sendMessage(msg.key.remoteJid, {
              text: '❌ حدث خطأ أثناء تحميل الفيديو.'
            }, { quoted: msg });
          }

          const files = fs.readdirSync(tempDir);
          const videoFile = files.find(f => f.endsWith('.mp4'));

          if (!videoFile) {
            return await sock.sendMessage(msg.key.remoteJid, {
              text: `❌ لم يتم العثور على الفيديو المطلوب.`
            }, { quoted: msg });
          }

          const filePath = path.join(tempDir, videoFile);
          const videoBuffer = fs.readFileSync(filePath);

          await sock.sendMessage(msg.key.remoteJid, {
            video: videoBuffer,
            mimetype: 'video/mp4',
            caption: `🎬 تم تحميل الإيدت: *${query}*\n🔗 الرابط: ${videoUrl}`
          }, { quoted: msg });

          fs.unlinkSync(filePath);
        });
      });

    } catch (err) {
      console.error('Edit command error:', err);
      await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ حدث خطأ أثناء تنفيذ الأمر.'
      }, { quoted: msg });
    }
  }
};