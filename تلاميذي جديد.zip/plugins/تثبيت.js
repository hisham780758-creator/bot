module.exports = {
  command: 'تثبيت',
  description: 'تثبيت أو إلغاء تثبيت رسالة عن طريق الرد',
usage: '.تثبيت',
  category: 'عام',
  async execute(sock, m) {
    const chatId = m.key.remoteJid;
    const sender = m.key.participant || m.participant || m.key.remoteJid;

    const body = m.message?.extendedTextMessage?.text || m.message?.conversation || '';
    const args = body.trim().split(/\s+/).slice(1);
    const action = args[0]?.toLowerCase();

    const context = m.message?.extendedTextMessage?.contextInfo;
    const quotedMessage = context?.quotedMessage;
    const quotedParticipant = context?.participant;
    const quotedId = context?.stanzaId;

    if (!quotedMessage || !quotedParticipant || !quotedId) {
      return sock.sendMessage(chatId, {
        text: "📌 يجب الرد على رسالة لتثبيتها أو إلغاء التثبيت."
      }, { quoted: m });
    }

    const isCancel = action === 'الغاء';
    const responseText = isCancel ? '❎ تم إلغاء تثبيت الرسالة.' : '✅ تم تثبيت الرسالة.';

    await sock.sendMessage(chatId, { text: responseText }, {
      quoted: {
        key: {
          remoteJid: chatId,
          id: quotedId,
          fromMe: false,
          participant: quotedParticipant,
        },
        message: quotedMessage, // ضروري جدا!
      }
    });
  }
};