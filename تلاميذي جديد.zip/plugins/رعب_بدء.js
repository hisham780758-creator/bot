const fs = require('fs');
const path = require('path');

module.exports = {
  command: ['رعب_بدء'],
  category: 'games',
  description: '🚪 بداية مغامرة الرعب',
usage: '.رعب_بدء',

  async execute(sock, msg) {
    const from = msg.key.remoteJid;
    const image = fs.readFileSync(path.join(__dirname, '../media/dark_room.jpg'));

    const text = `
🌑 *أهلاً بك في مغامرة البقاء المرعبة...*

استيقظت في غرفة مظلمة، لا نوافذ ولا أبواب واضحة...

🔘 *خياراتك:*
1. /رعب_تفتيش — فتّش الغرفة.
2. /رعب_فتح — حاول فتح الباب الصدئ.
`;

    await sock.sendMessage(from, {
      image,
      caption: text
    }, { quoted: msg });
  }
};