const fs = require('fs');
const path = require('path');
const pointsFile = path.join(__dirname, '../data/ranks.json');
let points = {};

// تحميل النقاط من الملف إذا كان موجود
if (fs.existsSync(pointsFile)) {
  points = JSON.parse(fs.readFileSync(pointsFile));
}

// حفظ النقاط
function savePoints() {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

module.exports = {
  command: "حبار",
  category: "game",
  description: "لعبة الحبار المتكررة: توقف أو تقدم",
usage: '.حبار',

  async execute(sock, m) {
    const chatId = m.key.remoteJid;
    if (!chatId.endsWith('@g.us')) {
      return sock.sendMessage(chatId, { text: '❌ هذا الأمر يعمل فقط في المجموعات.' }, { quoted: m });
    }

    let gameActive = true;

    async function startRound() {
      const options = ["تقدم", "توقف"];
      const correctAnswer = options[Math.floor(Math.random() * options.length)];

      await sock.sendMessage(chatId, {
        text: `🦑 *جولة جديدة من لعبة الحبار!*\n🚦 *توقف أو تقدم؟*\n\n⏳ لديك 30 ثانية!`,
      }, { quoted: m });

      const handler = async ({ messages }) => {
        const msg = messages[0];
        const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
        const from = msg.key.remoteJid;
        if (from !== chatId || !gameActive) return;

        if (body?.trim().toLowerCase() === "انهاء") {
          clearTimeout(timer);
          sock.ev.off('messages.upsert', handler);
          gameActive = false;
          await sock.sendMessage(chatId, { text: "🛑 تم إنهاء لعبة الحبار." }, { quoted: msg });
          return;
        }

        if (body?.trim() === correctAnswer) {
          const sender = msg.key.participant || msg.key.remoteJid;
          if (!points[sender]) points[sender] = 0;
          points[sender] += 1;
          savePoints();

          clearTimeout(timer);
          sock.ev.off('messages.upsert', handler);

          await sock.sendMessage(chatId, {
            text: `🎉 صحيح! الإجابة هي *${correctAnswer}*\n🏆 الفائز: @${sender.split('@')[0]}\n🧮 نقاطك: *${points[sender]}*\n\n🔁 جاري بدء الجولة التالية...`,
            mentions: [sender]
          }, { quoted: msg });

          setTimeout(startRound, 3000); // بدء جولة جديدة بعد 3 ثوانٍ
        }
      };

      sock.ev.on('messages.upsert', handler);

      const timer = setTimeout(() => {
        sock.ev.off('messages.upsert', handler);
        if (gameActive) {
          sock.sendMessage(chatId, {
            text: `⌛ انتهى الوقت!\n❌ الإجابة الصحيحة كانت: *${correctAnswer}*\n🔁 جاري بدء الجولة التالية...`
          }, { quoted: m });
          setTimeout(startRound, 3000);
        }
      }, 30000);
    }

    await sock.sendMessage(chatId, {
      text: `🟢 بدأت لعبة الحبار!\n🚨 للانسحاب، أرسل: *انهاء*\n🎮 حظًا موفقًا!`,
    }, { quoted: m });

    startRound();
  }
};