const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
  try {
    return JSON.parse(fs.readFileSync(pointsFile));
  } catch {
    return {};
  }
}

function savePoints(points) {
  fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const flags = [
  { emoji: '🇯🇵', answer: 'اليابان' },
  { emoji: '🇸🇦', answer: 'السعودية' },
  { emoji: '🇾🇪', answer: 'اليمن' },
  { emoji: '🇪🇬', answer: 'مصر' },
  { emoji: '🇹🇷', answer: 'تركيا' },
  { emoji: '🇰🇷', answer: 'كوريا الجنوبية' },
  { emoji: '🇩🇿', answer: 'الجزائر' },
  { emoji: '🇲🇦', answer: 'المغرب' },
  { emoji: '🇸🇾', answer: 'سوريا' },
  { emoji: '🇦🇪', answer: 'الامارات' },
  { emoji: '🇮🇶', answer: 'العراق' },
  { emoji: '🇶🇦', answer: 'قطر' },
  { emoji: '🇯🇴', answer: 'الاردن' },
  { emoji: '🇸🇩', answer: 'السودان' },
  { emoji: '🇴🇲', answer: 'عمان' },
  { emoji: '🇱🇧', answer: 'لبنان' },
  { emoji: '🇧🇷', answer: 'البرازيل' },
  { emoji: '🇫🇷', answer: 'فرنسا' },
  { emoji: '🇩🇪', answer: 'ألمانيا' },
  { emoji: '🇨🇳', answer: 'الصين' },
  { emoji: '🇷🇺', answer: 'روسيا' },
  { emoji: '🇺🇸', answer: 'الولايات المتحدة' },
  { emoji: '🇬🇧', answer: 'المملكه المتحدة' },
  { emoji: '🇮🇳', answer: 'الهند' },
  { emoji: '🇮🇹', answer: 'ايطاليا' },
  { emoji: '🇨🇦', answer: 'كندا' },
];

module.exports = {
  command: 'علم',
  category: 'games',
  description: 'فعالية معرفة علم الدولة',
usage: '.علم',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبات.*'
      }, { quoted: msg });
    }

    const selected = flags[Math.floor(Math.random() * flags.length)];
    const answer = selected.answer.trim().toLowerCase();
    const flagEmoji = selected.emoji;
    let isAnswered = false;

    const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏳️◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔عـلـم〕※*\n\n` +
      `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔سيتم عرض علم، والمطلوب معرفة الدولة التي ينتمي لها〕※*\n\n` +
      `*┃╻🎌╹↵العـلـم ↯*\n*⧉┋※〔 ${flagEmoji} 〕※*\n\n` +
      `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏳️◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
      `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇 Ascanor ٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase()?.trim();
      if (!body) return;

      if (body === answer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = loadPoints();

        pointsData[number] = (pointsData[number] || 0) + 10;
        savePoints(pointsData);

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*\n\n` +
`*تـم مـنحـه الـنـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(async () => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        await sock.sendMessage(groupJid, {
          text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${selected.answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};