const fs = require('fs');

module.exports = {
  name: 'شاتي',
  command: ['شاتي'],
  category: 'أدوات',
  description: 'ينشئ رابط شات واتساب مع رقم المستخدم ويعرض صورة الجروب.',
usage: '.شاتي',
  args: ['[النص الاختياري]'],
  execute: async (sock, m, args = []) => {
    try {
      await sock.sendMessage(m.key.remoteJid, { text: '*جــــاري انــــشــاء اللـــينك الـخـاص بــك🎀*' }, { quoted: m });

      await new Promise(resolve => setTimeout(resolve, 3000));

      const senderJid = m.key.participant || m.participant || m.key.remoteJid;
      const userNumber = senderJid.split('@')[0];
      let messageText = args.length > 0 ? args.join('+') : '';
      const chatLink = `https://wa.me/${userNumber}${messageText ? `?text=${messageText}` : ''}`;

      let profilePicUrl;
      try {
        profilePicUrl = await sock.profilePictureUrl(m.key.remoteJid, 'image');
      } catch {
        profilePicUrl = 'https://telegra.ph/file/3874ad592fdd3c849fb40.jpg'; // صورة افتراضية
      }

      const sectionsText = `*┏┅ ━━━━━━━━━━━━━━━ ┅ ━┓*\n` +
        `*⛓️ لينك شاتك:*\n` +
        `> ${chatLink}\n\n` +
        `> لو عايز تضيف كلام تلقائي مع اللينك، اكتب 𓊉.شاتي𓊈 وبعدها الكلام الي عايزه ❄️♥\n` +
        `*┗┅ ━━━━━━━━━━━━━━━ ┅ ━┛*\n\n` +
        `> *  > 𝑲𝑰𝑵𝑮🫦 < *`;

      await sock.sendMessage(
        m.key.remoteJid,
        {
          image: { url: profilePicUrl },
          caption: sectionsText,
          contextInfo: {
            externalAdReply: {
              mediaUrl: chatLink,
              mediaType: 2,
              description: 'رابط شات واتساب الخاص بك',
              title: '𝑲𝑰𝑵𝑮 𝑺𝑶𝑳𝑶 ⚡',
              body: 'تم إنشاؤه لك يا نجم 🌟',
              thumbnailUrl: 'https://telegra.ph/file/3874ad592fdd3c849fb40.jpg',
              sourceUrl: chatLink
            }
          }
        },
        { quoted: m }
      );

    } catch (error) {
      console.error("❌ خطأ أثناء إنشاء رابط الشات:", error);
      await sock.sendMessage(m.key.remoteJid, { text: '❌ حدث