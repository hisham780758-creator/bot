const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '../data/points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

function loadPoints() {
    try {
        return JSON.parse(fs.readFileSync(pointsFile));
    } catch {
        return {};
    }
}

function savePoints(points) {
    fs.writeFileSync(pointsFile, JSON.stringify(points, null, 2));
}

const riddles = [
    { question: "شيء كلما أخذت منه كبر، فما هو؟", answer:"الحفره" },
    { question: "شيء لا يمشي إلا بالضرب، فما هو؟", answer: "المسمار" },
    { question: "شيء تذبحه وتبكي عليه، فما هو؟", answer: "البصل" },
    { question: "ما هو الشيء الذي لديه عين واحدة ولا يرى؟", answer: "الإبرة" },
    { question: "شيء كلما زاد نقص، فما هو؟", answer: "العمر" },
    { question: "شيء إذا أكل كذب، وإذا جاع صدق، فما هو؟", answer: "الساعة" },
    { question: "يمشي بدون قدمين، ويبكي بدون عينين، فما هو؟", answer: "السحاب" },
    { question: "شيء موجود في السماء وإذا أضفت له حرف أصبح في الأرض؟", answer: "نجم" },
    { question: "بيت ليس فيه أبواب ولا نوافذ، فما هو؟", answer: "البيت الشعري" },
    { question: "شيء له أسنان ولا يعض، فما هو؟", answer: "المشط" },
    { question: "شيء نراه في الليل ثلاث مرات وفي النهار مرة؟", answer: "حرف اللام" },
    { question: "شيء لا يبتل حتى لو دخل الماء، فما هو؟", answer: "الظل" },
    { question: "شيء له رقبة ولا رأس، فما هو؟", answer: "الزجاجة" },
    { question: "ما هو الشيء الذي لا يمكن كسره؟", answer: "المبتدأ" },
    { question: "يسمع بلا أذن ويتكلم بلا لسان، فما هو؟", answer: "الهاتف" },
    { question: "شيء يُؤخذ منك قبل أن يُعطى لك؟", answer: "الصورة" },
    { question: "شيء تشتريه لتأكله لكن لا تأكله؟", answer: "الصحن" },
    { question: "يوصلك من البيت إلى العمل دون أن يتحرك؟", answer: "الطريق" },
    { question: "ما هو الشيء الذي ينبض بلا قلب؟", answer: "الساعة" },
    { question: "شيء لا يدخل إلا إذا ضربته؟", answer: "المسمار" },
    { question: "ما هو الشيء الذي إذا وضعته في الثلاجة لا يبرد؟", answer: "الفلفل الحار" },
    { question: "شيء لا يُؤكل في الفطور؟", answer: "الغداء" },
    { question: "كلما زاد غلاؤه قل حجمه؟", answer: "العقل" },
    { question: "شيء يقرصك ولا تراه؟", answer: "الجوع" },
    { question: "له أوراق وليس نبات، له جلد وليس حيوان، ما هو؟", answer: "الكتاب" },
    { question: "شيء إذا تركته يطير، وإذا قبضت عليه يموت؟", answer: "النَفَس" },
    { question: "أين البحر الذي لا ماء فيه؟", answer: "على الخريطة" },
    { question: "شيء لا يمشي إلا على رأسه؟", answer: "القلم" },
    { question: "شيء إن سقط على الرأس بقوة لا يجرح؟", answer: "المطر" },
    { question: "له يد ولا يستطيع التصفيق؟", answer: "الساعة" },
    { question: "شيء لديه أرجل ولكن لا يمشي؟", answer: "الكرسي" },
    { question: "شيء إذا تكلمت معه يرد عليك دون أن تراه؟", answer: "الصدى" },
    { question: "ما هو الشيء الذي تذبحه وتبكي عليه؟", answer: "البصل" },
    { question: "شيء كلما كثر لدينا غلا، وإذا قل رخص؟", answer: "العقل" },
    { question: "شيء لا يرى ولا يسمع وإذا تكلم الكل يسمع؟", answer: "الرعد" },
    { question: "شيء تملكه ويستخدمه الآخرون أكثر منك؟", answer: "اسمك" },
    { question: "طائر يلد ولا يبيض، فما هو؟", answer: "الخفاش" },
    { question: "شيء إذا أضفت له الماء صغر؟", answer: "الحفرة" },
    { question: "شيء يشرب ولا يأكل؟", answer: "النار" },
    { question: "شيء إذا سقط لا يسمع له صوت؟", answer: "الريشة" },
    { question: "له رأس ولا عقل، فما هو؟", answer: "الدبوس" },
    { question: "شيء تجده في القرن مرة وفي الدقيقة مرتين ولا تجده في الساعة؟", answer: "حرف القاف" },
    { question: "ما هو الشيء الذي يكتب ولا يقرأ؟", answer: "القلم" },
    { question: "كل شيء له نهاية، ما هو الشيء الذي ليس له نهاية؟", answer: "الدائرة" },
    { question: "شيء إذا أردت أن تستخدمه ترميه؟", answer: "شبكة الصيد" },
    { question: "شيء تستطيع أن تكسره دون أن تلمسه؟", answer: "الوعد" },
    { question: "رقم إذا ضربته بنفسه ثم أضفت إليه نفسه كان الناتج 30؟", answer: "5" },
    { question: "من هو الذي يرى عدوه وصديقه بعين واحدة؟", answer: "الأعور" },
    { question: "ما هو الشيء الذي يجري ولا يمشي؟", answer: "النهر" },
    { question: "ما هو الشيء الذي يخترق الزجاج ولا يكسره؟", answer: "الضوء" }
];

module.exports = {
    command: 'لغز',
    category: 'games',
    description: 'فعالية ألغاز',
usage: '.حل_لغز',

    async execute(sock, msg) {
        const groupJid = msg.key.remoteJid;
        if (!groupJid.endsWith('@g.us')) {
            return sock.sendMessage(groupJid, {
                text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبات.*'
            }, { quoted: msg });
        }

        const selectedRiddle = riddles[Math.floor(Math.random() * riddles.length)];
        const question = selectedRiddle.question;
        const answer = selectedRiddle.answer.trim().toLowerCase();
        let isAnswered = false;

        const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
            `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔ألـغـاز〕※*\n\n` +
            `*┃╻🍁╹↵ شـرح الـفـعالـية ↯*\n*⧉┋※〔سـيـتـم إعـطـاء لـغـز، وعـليك مـعـرفـة الـحـل〕※*\n\n` +
            `*┃╻❓╹↵ الـلـغـز ↯*\n*⧉┋※〔 ${question} 〕※*\n\n` +
            `*┃╻💣╹↵لـديكـم 30 ثـانـيـة للإجـابـة ↯*\n*‏⎔ ٠ ┈─ ━╼ • ◞🏙️◜ • ╾━ ─┈‏ ٠ ⎔*\n` +
            `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇  A̶S̶C̶A̶N̶O̶R̶ ٭*`;

        await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

        const listener = async (event) => {
            if (isAnswered) return;
            const m = event.messages[0];
            if (!m.message || m.key.remoteJid !== groupJid) return;
            const body = m.message?.conversation?.toLowerCase()?.trim();
            if (!body) return;

            if (body === answer) {
                isAnswered = true;
                sock.ev.off('messages.upsert', listener);

                const sender = m.key.participant;
                const number = extractPureNumber(sender);
                const pointsData = loadPoints();

                pointsData[number] = (pointsData[number] || 0) + 10;
                savePoints(pointsData);

                await sock.sendMessage(groupJid, {
                    text:
                        `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n` +
                        `*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
                        `*┃╻🪻╹↵الـحـل ↯*\n*❐ ↵「 ${selectedRiddle.answer} 」*\n\n` +
                        `*تـم مـنحـه الـنـقـاط* 🍁🪺`,
                    mentions: [sender]
                }, { quoted: m });
            }
        };

        sock.ev.on('messages.upsert', listener);

        setTimeout(async () => {
            sock.ev.off('messages.upsert', listener);
            if (!isAnswered) {
                await sock.sendMessage(groupJid, {
                    text: `*⧉┋٭ انـتـهـت الـفـعالـيـة ٭*\n\n*❐ ↵ لم يجب أحد في الوقت المحدد.*\n*┃╻🪻╹↵الـحـل ↯*\n*❐ ↵「 ${selectedRiddle.answer} 」*`
                }, { quoted: msg });
            }
        }, 30000);
    }
};
