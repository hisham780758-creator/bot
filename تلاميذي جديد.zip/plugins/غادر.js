// دالة التحقق من النخبة
function isEliteUser(userId) {
    const { eliteNumbers } = require('../haykala/elite-features.js');
    const cleanNumber = userId.replace(/[^0-9]/g, '');
    return Object.values(eliteNumbers).some(rank => 
        rank.includes(cleanNumber)
    );
}

const { eliteNumbers } = require('../haykala/elite.js');

module.exports = {
    command: 'غادر',
    description: 'مغادرة المجموعة',
    usage: '.غادر',
    category: 'group',

    async execute(sock, msg) {
        const jid = msg.key.remoteJid;
        const sender = msg.key.participant || jid;
        const senderNum = sender.split('@')[0];

        // التحقق من الصلاحية (مصحح) ✅
        if (!isEliteUser(senderNum)) {
            return await sock.sendMessage(jid, {
                text: '❗ لا تملك صلاحية استخدام هذا الأمر.'
            }, { quoted: msg });
        }

        // بقية الكود...
    }
};