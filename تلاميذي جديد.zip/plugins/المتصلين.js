module.exports = {
    command: 'المتصلين',
    description: 'ظˆطµظپ المتصلين',
    usage: '.المتصلين',
    category: 'tools',

    async execute(sock, msg, args) {
        let handler = async (m, { conn, args }) => {
  try {
    // تحديد جروب الهدف: لو فيه باراميتر يحدد الجروب، لو لا يستعمل الجروب الحالي
    let chatId = args?.[0]?.match(/\d+\-\d+@g.us/) ? args[0] : m.chat;

    // جلب جميع الرسائل في الجروب (اذا متوفرة)
    const messages = conn.chats[chatId]?.messages || {};

    // استخراج جميع المرسلين من الرسائل (keys.participant) بدون تكرار
    const participants = Object.values(messages)
      .map(msg => msg.key.participant)
      .filter((v, i, arr) => arr.indexOf(v) === i);

    // ترتيب الأعضاء أبجدياً حسب رقم الجوال (قبل @)
    const sorted = participants.sort((a, b) => a.split('@')[0].localeCompare(b.split('@')[0]));

    // صياغة القائمة للنص مع منشن للأعضاء
    const listText = sorted.length > 0
      ? sorted.map((jid, i) => `*${i + 1}.* @${jid.split('@')[0]}`).join('\n')
      : 'لا يوجد مستخدمين على الانترنت في هذا الوقت.';

    // ارسال رد تفاعل (react) للإشارة للرسالة
    await conn.sendMessage(m.chat, { react: { text: '🌐', key: m.key } });

    // ارسال رسالة تحتوي القائمة مع منشن الأعضاء
    await conn.reply(m.chat, `*🌐 قائمة المتصلين بالانترنت الآن:*\n${listText}`, m, {
      contextInfo: { mentionedJid: sorted }
    });

  } catch (error) {
    console.error(error);
  }
};

handler.help = ['المتصلين'];
handler.tags = ['group'];
handler.command = /^(المتصلين)$/i;
handler.group = true;
handler.botAdmin = false;
handler.admin = false;

export default handler;
    }
};
