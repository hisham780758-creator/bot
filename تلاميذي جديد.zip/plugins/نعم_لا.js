const fs = require('fs');
const path = require('path');
const { extractPureNumber } = require('../haykala/elite');

const pointsFile = path.join(__dirname, '..', 'data', 'points.json');
if (!fs.existsSync(pointsFile)) fs.writeFileSync(pointsFile, '{}', 'utf8');

const yesNoQuestions = [
  { question: "هل غوكو أقوى من فيجيتا؟", answer: "نعم" },
  { question: "هل ون بيس انتهى؟", answer: "لا" },
  { question: "هل يمكن للإنسان العيش بدون ماء؟", answer: "لا" },
  { question: "هل الأرض تدور حول الشمس؟", answer: "نعم" },
  { question: "هل ناروتو والد بوروتو؟", answer: "نعم" },
  { question: "هل ليفاي من أنمي ناروتو؟", answer: "لا" },
  { question: "هل كاكاشي يستخدم الشارينغان؟", answer: "نعم" },
  { question: "هل السمك يعيش في الصحراء؟", answer: "لا" },
  { question: "هل يوجد أنمي اسمه 'هجوم العمالقة'؟", answer: "نعم" },
  { question: "هل القمر مصنوع من الجبنة؟", answer: "لا" }
];

module.exports = {
  command: 'نعم_لا',
  category: 'games',
  description: 'فعالية أسئلة نعم أو لا - أجب بسرعة وبشكل صحيح',
usage: '.نعم_لا',

  async execute(sock, msg) {
    const groupJid = msg.key.remoteJid;
    if (!groupJid.endsWith('@g.us')) {
      return sock.sendMessage(groupJid, {
        text: '*❌ هـذا الأمـر يـعـمـل فـقـط داخـل الـقـروبـات.*'
      }, { quoted: msg });
    }

    const item = yesNoQuestions[Math.floor(Math.random() * yesNoQuestions.length)];
    const correctAnswer = item.answer.toLowerCase().trim();

    const message = `*فـعـالـيـة الـيـوم : ˼‏🎐˹*\n*‏⎔ ٠ ┈─ ━╼ • ◞🎯◜ • ╾━ ─┈‏ ٠ ⎔*\n\n` +
      `*┃╻📜╹↵اسـم الفـعـالـية↯*\n*⧉┋※〔نـعـم أو لا〕※*\n\n` +
      `*┃╻🧠╹↵السـؤال ↯*\n*⧉┋※〔 ${item.question} 〕※*\n\n` +
      `*┃╻⏰╹↵لـديـكـم 30 ثـانـيـة للإجـابـة ↯*\n` +
      `*📌 أجب فقط بـ 「 نعم 」 أو 「 لا 」!*\n\n` +
      `*٭ فـعـالـيـات بـوت إيـريـن ٭*\n*٭𝐺𝐴𝑀𝐸𝑆 𝐵𝑂𝑇 𝐸𝑅𝐸𝑁 ٭*`;

    await sock.sendMessage(groupJid, { text: message }, { quoted: msg });

    let isAnswered = false;

    const listener = async (event) => {
      if (isAnswered) return;
      const m = event.messages[0];
      if (!m.message || m.key.remoteJid !== groupJid) return;
      const body = m.message?.conversation?.toLowerCase().trim();
      if (!body) return;

      if (body === correctAnswer) {
        isAnswered = true;
        sock.ev.off('messages.upsert', listener);

        const sender = m.key.participant;
        const number = extractPureNumber(sender);
        const pointsData = JSON.parse(fs.readFileSync(pointsFile));
        pointsData[number] = (pointsData[number] || 0) + 10;
        fs.writeFileSync(pointsFile, JSON.stringify(pointsData, null, 2));

        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n` +
`*┃╻💐╹↵الـفـائـز ↯*\n*❐ ↵「 @${number} 」*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${item.answer} 」*\n\n` +
`*تـم مـنحـه الـنـقـاط* 🍁🪺`,
          mentions: [sender]
        }, { quoted: m });
      }
    };

    sock.ev.on('messages.upsert', listener);

    setTimeout(async () => {
      sock.ev.off('messages.upsert', listener);
      if (!isAnswered) {
        await sock.sendMessage(groupJid, {
          text:
`*⧉┋٭ انـتـهـت الـفـعالـية ٭*\n\n` +
`*❐ ↵ لم يـجـب أحـد بـشـكـل صـحـيـح.*\n` +
`*┃╻🪻╹↵الإجـابـة ↯*\n*❐ ↵「 ${item.answer} 」*`
        }, { quoted: msg });
      }
    }, 30000);
  }
};