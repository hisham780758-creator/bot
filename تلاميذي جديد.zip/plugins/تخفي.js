const fs = require('fs');
const path = require('path');
const { isElite } = require('../haykala/elite.js');
const { jidNormalizedUser } = require('@whiskeysockets/baileys');

// 1. إعدادات الملفات
const DEFAULT_IMG_NAME = 'incognito.jpg';
const DEFAULT_HIDE_NAME = process.env.HIDE_NAME || 'مجهول 🫦🔱';
const DEFAULT_IMG_PATH = path.join(__dirname, '../media/', DEFAULT_IMG_NAME);
const ORIGINAL_PROFILE_FILE = path.join(__dirname, '../media/original_profile.json');

// 2. تحميل أو حفظ الاسم الأصلي
let originalProfile = { name: '𝒎𝒐𝒉𝒎𝒂𝒎𝒅' }; // القيمة الافتراضية

// محاولة تحميل البيانات المحفوظة
if (fs.existsSync(ORIGINAL_PROFILE_FILE)) {
  try {
    originalProfile = JSON.parse(fs.readFileSync(ORIGINAL_PROFILE_FILE, 'utf-8'));
  } catch (e) {
    console.error('فشل تحميل ملف الملف الشخصي الأصلي:', e);
  }
}

module.exports = {
  command: "تخفي",
  description: "تفعيل/إلغاء وضع التخفي (تبديل اسم وصورة البروفايل)",
usage: '.تخفي',
  category: "admin",

  async execute(sock, msg, args, store) {
    const chatId = msg.key.remoteJid;
    const senderJid = msg.participant || msg.key.participant || msg.key.remoteJid;

    if (!isElite(senderJid)) {
      return sock.sendMessage(chatId, {
        text: `🚫 يا @${senderJid.split("@")[0]}, هذا الأمر مخصص للنخبة فقط.`,
        mentions: [senderJid]
      }, { quoted: msg });
    }

    const meJid = jidNormalizedUser(
      sock.user?.id || 
      sock.user?.jid || 
      (sock.authState?.creds?.me?.id || sock.authState?.creds?.me?.jid)
    );

    if (!meJid) {
      await sock.sendMessage(chatId, { text: "❌ تعذر تحديد حساب البوت!" }, { quoted: msg });
      return;
    }

    const results = [];
    const isCurrentlyHidden = originalProfile.isHidden;

    if (isCurrentlyHidden) {
      // إلغاء التخفي - استعادة الاسم الأصلي
      try {
        await sock.updateProfileName(originalProfile.name);
        results.push(`✅ تم استعادة الاسم الأصلي: ${originalProfile.name}`);
        originalProfile.isHidden = false;
      } catch (e) {
        results.push(`❌ فشل استعادة الاسم الأصلي: ${e.message}`);
      }
    } else {
      // تفعيل التخفي - حفظ الاسم الحالي وتغييره
      if (!fs.existsSync(DEFAULT_IMG_PATH)) {
        await sock.sendMessage(chatId, {
          text: `⚠️ الملف المطلوب غير موجود:\n${DEFAULT_IMG_PATH}\n\n` +
                `- ضع الصورة هنا: /media/${DEFAULT_IMG_NAME}\n` +
                `- أو غير اسم الملف في الكود`
        }, { quoted: msg });
        return;
      }

      try {
        // إذا كان الاسم غير محفوظ بعد، نحفظه
        if (!originalProfile.nameSaved) {
          const currentName = sock.user?.name || '𝒎𝒐𝒉𝒎𝒂𝒎𝒅';
          originalProfile.name = currentName;
          originalProfile.nameSaved = true;
          results.push(`💾 تم حفظ الاسم الأصلي: ${currentName}`);
        }
        
        await sock.updateProfileName(DEFAULT_HIDE_NAME);
        results.push(`✅ تم تغيير الاسم إلى: ${DEFAULT_HIDE_NAME}`);
        originalProfile.isHidden = true;
      } catch (e) {
        results.push(`❌ فشل تغيير الاسم: ${e.message}`);
      }

      // تغيير الصورة
      try {
        const imgBuffer = fs.readFileSync(DEFAULT_IMG_PATH);
        await sock.updateProfilePicture(meJid, imgBuffer);
        results.push(`✅ تم تغيير الصورة: ${DEFAULT_IMG_NAME}`);
      } catch (e) {
        results.push(`❌ فشل تغيير الصورة:\n${e.message}`);
      }
    }

    // حفظ حالة التخفي الحالية في الملف
    try {
      fs.writeFileSync(ORIGINAL_PROFILE_FILE, JSON.stringify(originalProfile, null, 2));
    } catch (e) {
      console.error('فشل حفظ ملف الملف الشخصي:', e);
      results.push('⚠️ تم تنفيذ الأمر ولكن لم يتم حفظ الإعدادات للجلسات القادمة');
    }

    // إرسال النتائج
    await sock.sendMessage(chatId, {
      text: `🎭 نتيجة العملية:\n${results.join('\n')}`
    }, { quoted: msg });

    try { await sock.sendMessage(chatId, { delete: msg.key }); } catch {}
  }
};