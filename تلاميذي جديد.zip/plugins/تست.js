وبتيه
const fs = require('fs');

module.exports = {
  command: 'تست',
  description: 'رد فخم عند كتابة "تست"',
usage: '.تست',
category: 'tools',
  group: true,

  async execute(sock, msg) {
    const videoPath = 'image.mp4';

    // تحقق من وجود الفيديو
    if (!fs.existsSync(videoPath)) {
      return await sock.sendMessage(msg.key.remoteJid, {
        text: '⚠️ لم يتم العثور على الفيديو image.mp4.',
      }, { quoted: msg });
    }

    // أرسل الفيديو مع الرسالة
    await sock.sendMessage(msg.key.remoteJid, {
      video: fs.readFileSync(videoPath),
      caption: `*نحن لا نتعب… نحن ننتظࢪ…*\n*نصنـ؏ المشهد، نضبط الأضاءة، ونتࢪڪك تدخل المشهد لحالك..🚯*`,
    }, { quoted: msg });
  }
};
